<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — data\mappings\LIFEX_DALIA

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `lifex_dalia_db (2).json-19-12`
- `lifex_dalia_db.json-19-12`
