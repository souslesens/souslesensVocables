<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\icons\CommonIcons

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `AbortIcon.png`
- `add-icon.png`
- `ArrowLateralPanel.png`
- `ArrowLateralPanelShow.png`
- `ArrowMenuBar.png`
- `ArrowMenuBarShow.png`
- `ClassesIcon.png`
- `ClassesIconWhite.png`
- `ClearAllIcon.png`
- `ClearLastIcon.png`
- `ContainerIcon.png`
- `ContainerIconWhite.png`
- `CopyIcon.png`
- `CreateTriplesIcon.png`
- `CSVIcon.png`
- `DeleteAllKGcreatorTriplesIcon.png`
- `DeleteCurrentFileTriplesIcon.png`
- `DeletefiletriplesIcon.png`
- `EditIcon.png`
- `Erase.png`
- `ExpandIcon.png`
- `export.png`
- `Filtre.png`
- `Import.png`
- `IndexGraphIcon.png`
- `load.png`
- `MigrateOldMappingsIcon.png`
- `MinusIcon.png`
- `ModelIcon.png`
- `OnlyLastIcon.png`
- `ParentIcon.png`
- `PropertiesIcon.png`
- `propertiesIconWhite.png`
- `Query.png`
- `RecreateGraphIcon.png`
- `ResetIcon.png`
- `save.png`
- `SearchIcon.png`
- `settings.png`
- `show_children.png`
- `show_main_classes.png`
- `show_parents.png`
- `show_relations.png`
- `slsvLogo-miniature.png`
- `slsvLogo.png`
- `SourceIcon.png`
- `TestSelectedMappingIcon.png`
- `TextSelectedIcon.png`
- `TopClassesIcon.png`
- `UnionIcon.png`
- `ViewSampleTripleIcon.png`
- `WhiteBoardIcon.png`
