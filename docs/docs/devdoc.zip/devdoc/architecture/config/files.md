<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — config

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `blenderSources.json`
- `databases.json`
- `mainConfig.json`
- `mainConfig.json.bak`
- `plugins.json`
- `pluginsConfig.json`
- `profiles_1727448423280_backup.json`
- `profiles_1727686414001_backup.json`
- `profiles_1732868017964_backup.json`
- `profiles_1738574006434_backup.json`
- `profiles.json`
- `profiles.json.bak`
- `sources_1732868018250_backup.json`
- `sources_1738574006893_backup.json`
- `sources_1741001686101_backup.json`
- `sources_1742574953267_backup.json`
- `sources_1742804710496_backup.json`
- `sources_1742827337090_backup.json`
- `sources_1742827494037_backup.json`
- `sources_1742827607028_backup.json`
- `sources_1744212533057_backup.json`
- `sources_1748855058829_backup.json`
- `sources_1749654776200_backup.json`
- `sources_1756723202806_backup.json`
- `sources.json`
- `sources.json.bak`
