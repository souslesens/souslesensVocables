<!-- AUTO-GENERATED: do not edit by hand -->
# api\v1\paths\admin

[⬅️ Retour](../index.md)

## Dossiers

- [databases](databases/index.md)
- [ontology](ontology/index.md)
- [plugins](plugins/index.md)
- [profiles](profiles/index.md)
- [sources](sources/index.md)
- [users](users/index.md)

## Fichiers

- [Voir la liste des fichiers](files.md)
