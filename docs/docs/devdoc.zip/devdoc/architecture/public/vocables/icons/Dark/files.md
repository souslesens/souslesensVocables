<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\icons\Dark

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `Admin-Dark.png`
- `caret-right-Dark.png`
- `ClassesIcon-Dark.png`
- `ConfigEditor-Dark.png`
- `Container-Dark.png`
- `ContainerIcon-Dark.png`
- `CrossIcon-Dark.png`
- `DeleteIcon-Dark.png`
- `Graphmanagement-Dark.png`
- `Kgcreator-Dark.png`
- `Kgquery-Dark.png`
- `lineageLogo-Dark.png`
- `MoreOptionsIcon-Dark.png`
- `Ontocreator-Dark.png`
- `PreviousIcon-Dark.png`
- `PropertiesIcon-Dark.png`
- `ResetIcon-Dark.png`
- `SaveIcon-Dark.png`
- `SearchIcon-Dark.png`
- `SelectionAllIcon-Dark.png`
- `SelectionIcon-Dark.png`
- `SPARQL-Dark.png`
- `Timeline-Dark.png`
- `WhiteboardIcon-Dark.png`
