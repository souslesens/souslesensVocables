<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — scripts

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `create_user_in_db.sh`
- `docker-init-db.sh`
- `fix-fileNameUpperLowerCaseProblem.js`
- `generate-global-architecture.mjs`
- `get_default_local_graphs.js`
- `init_configs.js`
- `init_directories.sh`
- `post_release.js`
- `run-migrations.sh`
- `sanitizeDB.js`
- `test_config_template.js`
