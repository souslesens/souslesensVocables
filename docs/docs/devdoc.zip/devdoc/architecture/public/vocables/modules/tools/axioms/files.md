<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\modules\tools\axioms

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `axiom_activeLegend.js`
- `axiom_editor.js`
- `axiomExtractor.js`
- `axioms_graph.js`
- `axioms_manager.js`
- `axioms_suggestions.js`
- `nodeInfosAxioms.js`
