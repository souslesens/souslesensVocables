<!-- AUTO-GENERATED: do not edit by hand -->
# api\v1\paths\admin\databases

[⬅️ Retour](../index.md)

## Dossiers

- [test](test/index.md)

## Fichiers

- [Voir la liste des fichiers](files.md)
