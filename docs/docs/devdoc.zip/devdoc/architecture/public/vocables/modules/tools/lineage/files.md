<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\modules\tools\lineage

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `lineage_axioms.js`
- `lineage_combine.js`
- `lineage_common.js`
- `lineage_createRelation.js`
- `lineage_createResource.js`
- `lineage_createSLSVsource.js`
- `lineage_decoration.js`
- `lineage_dictionary.js`
- `lineage_graphPaths.js`
- `lineage_graphTraversal.js`
- `lineage_nodeCentricGraph.js`
- `lineage_properties.js`
- `lineage_reasoner.js`
- `lineage_relationFilter.js`
- `lineage_relationIndividualsFilter.js`
- `lineage_relations.js`
- `lineage_rules.js`
- `lineage_selection.js`
- `lineage_similars.js`
- `lineage_sources.js`
- `lineage_whiteboard.js`
