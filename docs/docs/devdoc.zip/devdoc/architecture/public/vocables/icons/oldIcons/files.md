<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\icons\oldIcons

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `activity.png`
- `aspect.png`
- `c.png`
- `caret-down.png`
- `caret-right.png`
- `class.png`
- `class2.png`
- `collection.png`
- `concept.png`
- `default.png`
- `importedClass.png`
- `object.png`
- `ontology.png`
- `property.png`
- `restriction.png`
- `search.png`
- `set_minus.png`
- `set_union.png`
- `slideRight.png`
- `slsvfavicon.png`
- `souslesensIcon.png`
- `table.png`
- `thesaurus.png`
- `tool.png`
