<!-- AUTO-GENERATED: do not edit by hand -->
# model

[⬅️ Retour](../index.md)

## Dossiers

- [__mocks__](__mocks__/index.md)

## Fichiers

- [Voir la liste des fichiers](files.md)
