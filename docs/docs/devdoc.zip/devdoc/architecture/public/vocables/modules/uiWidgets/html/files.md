<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\modules\uiWidgets\html

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `bot.html`
- `dateWidget.html`
- `ganttWidget.html`
- `importDialog.html`
- `jsTreeWidget.html`
- `nodeInfosWidget.html`
- `nodeRelationsWidget.html`
- `predicatesSelectorWidgetDialog.html`
- `rangeWidget.html`
- `savedQueriesWidget.html`
- `sourceSelector.html`
- `userDataWidget.html`
