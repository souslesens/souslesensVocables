<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — api

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `README.md`
