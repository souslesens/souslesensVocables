<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\modules\tools\lineage\html\selection

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `lineage_selection_decorateClassDialog.html`
- `lineage_selection_decorateDialog.html`
- `lineage_selection_mergeNodesDialog.html`
- `lineageSelectionDialog.html`
