<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\modules\search

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `elasticSearchProxy.js`
- `searchUtil.js`
