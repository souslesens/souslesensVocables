<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\js\external\jquery\colorPicker\css

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `bootstrap-colorpicker-plus.css`
- `bootstrap-colorpicker-plus.min.css`
- `bootstrap-colorpicker.css`
- `bootstrap-colorpicker.min.css`
