<!-- AUTO-GENERATED: do not edit by hand -->
# public\vocables\icons

[⬅️ Retour](../index.md)

## Dossiers

- [BluishViolet](BluishViolet/index.md)
- [CFIHOS](CFIHOS/index.md)
- [CommonIcons](CommonIcons/index.md)
- [Dark](Dark/index.md)
- [DeepOffShore](DeepOffShore/index.md)
- [Draft (  unvalidated icons )](Draft (  unvalidated icons )/index.md)
- [Figcolors](Figcolors/index.md)
- [IOGP](IOGP/index.md)
- [JstreeIcons](JstreeIcons/index.md)
- [KGA](KGA/index.md)
- [Ocean](Ocean/index.md)
- [oldIcons](oldIcons/index.md)
- [SeaBreeze](SeaBreeze/index.md)
- [Spatial](Spatial/index.md)
- [TotalEnergies](TotalEnergies/index.md)

## Fichiers

- [Voir la liste des fichiers](files.md)
