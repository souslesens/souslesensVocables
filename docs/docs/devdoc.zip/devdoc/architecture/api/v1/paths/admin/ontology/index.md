<!-- AUTO-GENERATED: do not edit by hand -->
# api\v1\paths\admin\ontology

[⬅️ Retour](../index.md)

## Dossiers

_Aucun sous-dossier._

## Fichiers

- [Voir la liste des fichiers](files.md)
