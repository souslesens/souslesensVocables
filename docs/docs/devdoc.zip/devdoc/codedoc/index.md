# Code documentation

The following docs is generated from Javascript docstrings.

```{toctree}
:maxdepth: 2
mappingmodeler.md
jsdoc.md
```
