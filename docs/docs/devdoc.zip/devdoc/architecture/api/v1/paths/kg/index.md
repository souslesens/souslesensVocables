<!-- AUTO-GENERATED: do not edit by hand -->
# api\v1\paths\kg

[⬅️ Retour](../index.md)

## Dossiers

- [assets](assets/index.md)
- [mappings](mappings/index.md)

## Fichiers

- [Voir la liste des fichiers](files.md)
