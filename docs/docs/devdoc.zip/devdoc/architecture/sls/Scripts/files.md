<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — sls\Scripts

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `activate`
- `activate.bat`
- `Activate.ps1`
- `deactivate.bat`
- `pip.exe`
- `pip3.9.exe`
- `pip3.exe`
- `python.exe`
- `pythonw.exe`
