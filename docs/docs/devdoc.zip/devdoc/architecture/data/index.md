<!-- AUTO-GENERATED: do not edit by hand -->
# data

[⬅️ Retour](../index.md)

## Dossiers

- [annotator](annotator/index.md)
- [classIcons](classIcons/index.md)
- [CSV](CSV/index.md)
- [dictionaries](dictionaries/index.md)
- [graphs](graphs/index.md)
- [mappings](mappings/index.md)
- [shacl](shacl/index.md)
- [uploaded_rdf_data](uploaded_rdf_data/index.md)

## Fichiers

- [Voir la liste des fichiers](files.md)
