<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\icons\Figcolors

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `Admin-Figcolors.png`
- `caret-right-Figcolors.png`
- `ClassesIcon-Figcolors.png`
- `ConfigEditor-Figcolors.png`
- `Container-FigColors.png`
- `ContainerIcon-Figcolors.png`
- `CrossIcon-FigColors.png`
- `DeleteIcon-FigColors.png`
- `Graphmanagement-Figcolors.png`
- `Kgcreator-FigColors.png`
- `Kgquery-FigColors.png`
- `lineageLogo-FigColors.png`
- `MoreOptionsIcon-FigColors.png`
- `Ontocreator-Figcolors.png`
- `PreviousIcon-FigColors.png`
- `PropertiesIcon-Figcolors.png`
- `ResetIcon-FigColors.png`
- `SaveIcon-FigColors.png`
- `SearchIcon-FigColors.png`
- `SelectionAllIcon-FigColors.png`
- `SelectionIcon-FigColors.png`
- `SPARQL-Figcolors.png`
- `Timeline-Figcolors.png`
- `WhiteboardIcon-Figcolors.png`
