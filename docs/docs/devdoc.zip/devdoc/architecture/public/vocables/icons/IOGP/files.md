<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\icons\IOGP

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `Admin-IOGP.png`
- `caret-right-IOGP.png`
- `ClassesIcon-IOGP.png`
- `ConfigEditor-IOGP.png`
- `Container-IOGP.png`
- `ContainerIcon-IOGP.png`
- `CrossIcon-IOGP.png`
- `DeleteIcon-IOGP.png`
- `Graphmanagement-IOGP.png`
- `IOGPLogo.png`
- `Kgcreator-IOGP.png`
- `Kgquery-IOGP.png`
- `lineageLogo-IOGP.png`
- `MoreOptionsIcon-IOGP.png`
- `Ontocreator-IOGP.png`
- `PreviousIcon-IOGP.png`
- `PropertiesIcon-IOGP.png`
- `ResetIcon-IOGP.png`
- `SaveIcon-IOGP.png`
- `SearchIcon-IOGP.png`
- `SelectionAllIcon-IOGP.png`
- `SelectionIcon-IOGP.png`
- `SPARQL-IOGP.png`
- `Timeline-IOGP.png`
- `WhiteboardIcon-IOGP.png`
