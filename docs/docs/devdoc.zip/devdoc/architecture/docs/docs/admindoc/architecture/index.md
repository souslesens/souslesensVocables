<!-- AUTO-GENERATED: do not edit by hand -->
# docs\docs\admindoc\architecture

[⬅️ Retour](../index.md)

## Dossiers

- [images](images/index.md)

## Fichiers

- [Voir la liste des fichiers](files.md)
