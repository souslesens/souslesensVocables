<!-- AUTO-GENERATED: do not edit by hand -->
# api\v1\paths\users\data

[⬅️ Retour](../index.md)

## Dossiers

- [{id}]({id}/index.md)

## Fichiers

- [Voir la liste des fichiers](files.md)
