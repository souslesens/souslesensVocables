<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\modules\tools\lineage\html

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `AddNodeEdgeButtons.html`
- `axiomEditor.html`
- `classesTab.html`
- `containersTab.html`
- `lateralPanel.html`
- `lineage_decorateDialog.html`
- `lineage_reasoner.html`
- `lineage_rulesDialog.html`
- `lineage_shortestPathDialog.html`
- `lineageAddEdgeDialog.html`
- `lineageDictionary.html`
- `lineageSimilarsDialog.html`
- `lineageSimilarsSaveDialog.html`
- `parentContainers.html`
- `propertiesTab.html`
- `queryDialog.html`
- `relationsDialog.html`
- `sourcesDiv.html`
- `whiteBoardButtons.html`
- `whiteboardTab.html`
