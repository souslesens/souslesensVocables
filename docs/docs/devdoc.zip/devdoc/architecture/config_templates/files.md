<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — config_templates

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `databases.json.default`
- `mainConfig.json.default`
- `plugins.json.default`
- `pluginsConfig.json.default`
- `readme.txt`
- `sources.json.default`
