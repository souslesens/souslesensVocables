<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\images

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `browse.png`
- `circulargraph.png`
- `description.png`
- `evaluate.png`
- `match.png`
- `souslesensVocables.gif`
- `souslesensVocables.png`
- `souslesensVocables2.png`
- `souslesensVocablesold.png`
- `taxonomy.png`
- `waitAnimated.gif`
