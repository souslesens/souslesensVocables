<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\modules\tools\mappingModeler

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `dataSourcesManager.js`
- `mappingColumnsGraph.js`
- `mappingModeler.js`
- `mappingModelerRelations.js`
- `mappingsDetails.js`
- `mappingTransform.js`
- `tripleFactory.js`
- `uiController.js`
