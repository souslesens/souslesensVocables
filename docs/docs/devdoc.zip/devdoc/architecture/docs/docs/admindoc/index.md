<!-- AUTO-GENERATED: do not edit by hand -->
# docs\docs\admindoc

[⬅️ Retour](../index.md)

## Dossiers

- [architecture](architecture/index.md)
- [configuration](configuration/index.md)
- [installation](installation/index.md)
- [migrations](migrations/index.md)

## Fichiers

- [Voir la liste des fichiers](files.md)
