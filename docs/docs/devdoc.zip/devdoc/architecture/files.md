<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — Project root

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `.dockerignore`
- `.gitattributes`
- `.gitignore`
- `.gitlab-ci.yml`
- `.prettierignore`
- `.prettierrc.yaml`
- `app.js`
- `CHANGELOG.md`
- `CONTRIBUTING.md`
- `docker-compose.dev.yaml`
- `docker-compose.test.yaml`
- `docker-compose.yaml`
- `Dockerfile`
- `entrypoint.sh`
- `env.template`
- `eslint.config.mjs`
- `jest.config.js`
- `licence.txt`
- `LICENSE`
- `nodemon.json`
- `package-lock.json`
- `package.json`
- `README.md`
- `release-new.sh`
- `tsconfig.json`
