<!-- AUTO-GENERATED: do not edit by hand -->
# api\v1\paths

[⬅️ Retour](../index.md)

## Dossiers

- [admin](admin/index.md)
- [annotator](annotator/index.md)
- [auth](auth/index.md)
- [axioms](axioms/index.md)
- [data](data/index.md)
- [databases](databases/index.md)
- [elasticsearch](elasticsearch/index.md)
- [graphStore](graphStore/index.md)
- [kg](kg/index.md)
- [pluginController](pluginController/index.md)
- [rdf](rdf/index.md)
- [sources](sources/index.md)
- [sparql](sparql/index.md)
- [users](users/index.md)

## Fichiers

- [Voir la liste des fichiers](files.md)
