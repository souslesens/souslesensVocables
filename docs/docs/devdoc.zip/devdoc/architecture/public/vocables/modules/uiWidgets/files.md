<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\modules\uiWidgets

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `dateWidget.js`
- `FOL2graphWidget.js`
- `ganttWidget.js`
- `graphDecorationWidget.js`
- `importFileWidget.js`
- `individualValuefilterWidget.js`
- `jstreeWidget.js`
- `legendWidget.js`
- `mergeNodes.js`
- `nodeInfosWidget.js`
- `nodeRelationsWidget.js`
- `popupMenuWidget.js`
- `predicatesSelectorWidget.js`
- `promptedSelectWidget.js`
- `savedQueriesWidget.js`
- `searchWidget.js`
- `simpleListFilterWidget.js`
- `simpleListSelectorWidget.js`
- `sourceSelectorWidget.js`
- `userDataWidget.js`
