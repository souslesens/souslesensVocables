<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\icons

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `activity.png`
- `aspect.png`
- `attribute.png`
- `bo.png`
- `c.png`
- `class.png`
- `class2.png`
- `collection.png`
- `concept.png`
- `containers.png`
- `datablock.png`
- `datacontainer.png`
- `default.png`
- `disciplines.png`
- `enumeration.png`
- `importedClass.png`
- `individual.png`
- `JqueryClose.png`
- `lineageLogo-BluePurple.png`
- `object.png`
- `ontology.png`
- `Parameter.png`
- `properties.png`
- `property.png`
- `restriction.png`
- `souslesensIcon.png`
- `table.png`
- `thesaurus.png`
- `tool.png`
