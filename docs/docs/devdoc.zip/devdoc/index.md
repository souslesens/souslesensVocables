# Developper documentation

How to install a development instance and to contribute to the code.

```{toctree}
:maxdepth: 3
contribute-to-development.md
codedoc/index.md
devdoc/architecture/index
```
