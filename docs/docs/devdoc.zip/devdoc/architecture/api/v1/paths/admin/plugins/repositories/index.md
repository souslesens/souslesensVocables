<!-- AUTO-GENERATED: do not edit by hand -->
# api\v1\paths\admin\plugins\repositories

[⬅️ Retour](../index.md)

## Dossiers

- [fetch](fetch/index.md)
- [plugins](plugins/index.md)
- [repository](repository/index.md)
- [tags](tags/index.md)

## Fichiers

_Aucun fichier._
