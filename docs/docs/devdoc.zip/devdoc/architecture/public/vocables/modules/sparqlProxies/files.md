<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\modules\sparqlProxies

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `sparql_common.js`
- `sparql_generic.js`
- `sparql_OWL.js`
- `sparql_proxy.js`
- `sparql_SKOS.js`
- `test_sparql.js`
