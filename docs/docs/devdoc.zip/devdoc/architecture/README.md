<!-- AUTO-GENERATED -->
# Architecture globale

Point d’entrée : [index.md](./index.md)
