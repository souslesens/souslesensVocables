<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — docs\sls\Scripts

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `activate`
- `activate.bat`
- `activate.fish`
- `Activate.ps1`
- `deactivate.bat`
- `pip.exe`
- `pip3.13.exe`
- `pip3.exe`
- `python.exe`
- `pythonw.exe`
