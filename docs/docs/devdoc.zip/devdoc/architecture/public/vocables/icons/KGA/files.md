<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\icons\KGA

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `Admin-KGA.png`
- `caret-right-KGA.png`
- `ClassesIcon-KGA.png`
- `ConfigEditor-KGA.png`
- `Container-KGA.png`
- `ContainerIcon-KGA.png`
- `CrossIcon-KGA.png`
- `DeleteIcon-KGA.png`
- `Graphmanagement-KGA.png`
- `KGALogoXXXX.png`
- `Kgcreator-KGA.png`
- `Kgquery-KGA.png`
- `lineageLogo-KGA.png`
- `MoreOptionsIcon-KGA.png`
- `Ontocreator-KGA.png`
- `PreviousIcon-KGA.png`
- `PropertiesIcon-KGA.png`
- `ResetIcon-KGA.png`
- `SaveIcon-KGA.png`
- `SearchIcon-KGA.png`
- `SelectionAllIcon-KGA.png`
- `SelectionIcon-KGA.png`
- `SPARQL-KGA.png`
- `Timeline-KGA.png`
- `WhiteboardIcon-KGA.png`
