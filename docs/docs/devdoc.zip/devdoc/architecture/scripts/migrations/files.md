<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — scripts\migrations

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `migration_2.0.0_postgresql.js`
- `migration_2.1.0_postgresql.js`
- `migration_2.16.0_config_auth.js`
- `migration_2.18.0_rename_user_management.js`
- `migration_2.22.0_add_tokens.js`
- `migration_2.3.0_add_baseUri_in_sources.js`
- `migration_2.3.0_config_userData.js`
- `migration_2.3.0_Profiles.js`
- `migration_2.3.0_userData.js`
- `migration_2.3.0_UsersData.js`
- `migration_2.8.0_add_modification_date_to_UsersData.js`
- `migration_2.8.0_add_readwrite_to_UsersData.js`
