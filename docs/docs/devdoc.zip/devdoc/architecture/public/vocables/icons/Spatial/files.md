<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\icons\Spatial

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `Admin-Spatial.png`
- `caret-right-Spatial.png`
- `ClassesIcon-Spatial.png`
- `ConfigEditor-Spatial.png`
- `Container-Spatial.png`
- `ContainerIcon-Spatial.png`
- `CrossIcon-Spatial.png`
- `DeleteIcon-Spatial.png`
- `Graphmanagement-Spatial.png`
- `Kgcreator-Spatial.png`
- `Kgquery-Spatial.png`
- `lineageLogo-Spatial.png`
- `MoreOptionsIcon-Spatial.png`
- `Ontocreator-Spatial.png`
- `PreviousIcon-Spatial.png`
- `PropertiesIcon-Spatial.png`
- `ResetIcon-Spatial.png`
- `SaveIcon-Spatial.png`
- `SearchIcon-Spatial.png`
- `SelectionAllIcon-Spatial.png`
- `SelectionIcon-Spatial.png`
- `SPARQL-Spatial.png`
- `Timeline-Spatial.png`
- `WhiteboardIcon-Spatial.png`
