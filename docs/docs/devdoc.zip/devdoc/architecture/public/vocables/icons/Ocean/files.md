<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\icons\Ocean

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `Admin-Ocean.png`
- `caret-right-Ocean.png`
- `ClassesIcon-Ocean.png`
- `ConfigEditor-Ocean.png`
- `Container-Ocean.png`
- `ContainerIcon-Ocean.png`
- `CrossIcon-Ocean.png`
- `DeleteIcon-Ocean.png`
- `Graphmanagement-Ocean.png`
- `Kgcreator-Ocean.png`
- `Kgquery-Ocean.png`
- `lineageLogo-Ocean.png`
- `MoreOptionsIcon-Ocean.png`
- `Ontocreator-Ocean.png`
- `PreviousIcon-Ocean.png`
- `PropertiesIcon-Ocean.png`
- `ResetIcon-Ocean.png`
- `SaveIcon-Ocean.png`
- `SearchIcon-Ocean.png`
- `SelectionAllIcon-Ocean.png`
- `SelectionIcon-Ocean.png`
- `SPARQL-Ocean.png`
- `Timeline-Ocean.png`
- `WhiteboardIcon-Ocean.png`
