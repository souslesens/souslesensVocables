<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\modules\tools\standardizer

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `standardizer_central.html`
- `standardizer_left.html`
- `standardizer_right.html`
- `Standardizer.js`
