<!-- AUTO-GENERATED: do not edit by hand -->
# Project root

## Dossiers

- [api](api/index.md)
- [bin](bin/index.md)
- [config](config/index.md)
- [config_templates](config_templates/index.md)
- [data](data/index.md)
- [mainapp](mainapp/index.md)
- [model](model/index.md)
- [plugins](plugins/index.md)
- [public](public/index.md)
- [scripts](scripts/index.md)

## Fichiers

- [Voir la liste des fichiers](files.md)
