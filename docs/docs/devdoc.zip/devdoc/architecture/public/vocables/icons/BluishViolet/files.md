<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\icons\BluishViolet

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `Admin-bluishViolet.png`
- `caret-right-BluishViolet.png`
- `ClassesIcon-BluishViolet.png`
- `ConfigEditor-bluishViolet.png`
- `ContainerIcon-BluishViolet.png`
- `CrossIcon-bluishViolet.png`
- `DeleteIcon-bluishViolet.png`
- `Graphmanagement-bluishViolet.png`
- `Kgcreator-bluishViolet.png`
- `Kgquery-bluishViolet.png`
- `lineageLogo-bluishViolet.png`
- `MoreOptionsIcon-bluishViolet.png`
- `Ontocreator-bluishViolet.png`
- `PreviousIcon-bluishViolet.png`
- `PropertiesIcon-BluishViolet.png`
- `ResetIcon-bluishViolet.png`
- `SaveIcon-bluishViolet.png`
- `SearchIcon-bluishViolet.png`
- `SelectionAllIcon-bluishViolet.png`
- `SelectionIcon-bluishViolet.png`
- `SPARQL-bluishViolet.png`
- `Timeline-bluishViolet.png`
- `WhiteboardIcon-BluishViolet.png`
