<!-- AUTO-GENERATED: do not edit by hand -->
# public\vocables\modules\tools

[⬅️ Retour](../index.md)

## Dossiers

- [admin](admin/index.md)
- [axioms](axioms/index.md)
- [browse](browse/index.md)
- [containers](containers/index.md)
- [DownloadGraphModal](DownloadGraphModal/index.md)
- [EditSourceDialog](EditSourceDialog/index.md)
- [KGcreator](KGcreator/index.md)
- [KGquery](KGquery/index.md)
- [lineage](lineage/index.md)
- [mappingModeler](mappingModeler/index.md)
- [MetaDataDialog](MetaDataDialog/index.md)
- [SPARQL](SPARQL/index.md)
- [SQLquery](SQLquery/index.md)
- [standardizer](standardizer/index.md)
- [UploadGraphModal](UploadGraphModal/index.md)
- [weaver](weaver/index.md)

## Fichiers

- [Voir la liste des fichiers](files.md)
