<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\modules\bots

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `_botEngineClass.js`
- `_commonBotFunctions.js`
- `_nonObjectPropertyFilterWorklow.js`
- `createAxiomResource_bot.js`
- `createResource_bot.js`
- `createRestriction_bot.js`
- `createSLSVsource_bot.js`
- `graphPaths_bot.js`
- `KGcreator_bot.js`
- `KGquery_annotations_bot.js`
- `KGquery_composite_graph_bot.js`
- `KGquery_filter_bot.js`
- `manchesterSyntaxWidget.js`
- `mappingModeler_bot.js`
- `mappingModeler_lookups_bot.js`
- `nodeRelations_bot.js`
- `shareUserData_bot.js`
- `similars_bot.js`
- `sparqlQuery_bot.js`
