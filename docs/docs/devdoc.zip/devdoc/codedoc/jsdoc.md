
> souslesensvocables@2.23.1 tools:jsdoc2md
> jsdoc2md --configure docs/jsdoc/jsdoc.json  --template docs/jsdoc/jsdoc.hbs  --no-cache

# JSDOCS

## Modules

<dl>
<dt><a href="#module_Lineage_axioms">Lineage_axioms</a></dt>
<dd><p>Module for managing and visualizing ontological axioms in the lineage graph.
Provides functionality for:</p>
<ul>
<li>Visualizing classes with their associated axioms</li>
<li>Drawing axiom relationships in the graph</li>
<li>Supporting different types of axioms</li>
<li>Testing axiom functionality</li>
<li>Managing axiom metadata and visualization</li>
</ul>
</dd>
<dt><a href="#module_Lineage_combine">Lineage_combine</a></dt>
<dd><p>Module for combining and merging multiple ontology sources in the lineage graph.
Provides functionality for:</p>
<ul>
<li>Adding multiple ontology sources to the graph</li>
<li>Merging nodes from different sources</li>
<li>Managing source visibility and grouping</li>
<li>Handling node hierarchies during merges</li>
<li>Supporting different merge modes and depths</li>
<li>Preserving ontological restrictions during merges</li>
</ul>
</dd>
<dt><a href="#module_Lineage_common">Lineage_common</a></dt>
<dd><p>Common utility functions for the lineage system.
Provides functionality for:</p>
<ul>
<li>Managing clipboard operations with nodes</li>
<li>Node deletion and manipulation</li>
<li>Copy/paste operations between nodes</li>
<li>Managing ontology imports</li>
<li>Basic node operations and validations</li>
</ul>
</dd>
<dt><a href="#module_Lineage_createRelation">Lineage_createRelation</a></dt>
<dd><p>Module for creating and managing relationships between ontology nodes.
Provides functionality for:</p>
<ul>
<li>Creating new relationships between nodes in the ontology</li>
<li>Managing relationship types and properties</li>
<li>Validating relationship constraints</li>
<li>Supporting different types of ontological relationships</li>
<li>Managing relationship metadata and restrictions</li>
<li>Integrating with the ontology model system</li>
</ul>
</dd>
<dt><a href="#module_Lineage_createResource">Lineage_createResource</a></dt>
<dd><p>Module for creating new resources (classes, named individuals) in the ontology.
Provides functionality for:</p>
<ul>
<li>Creating new classes and named individuals</li>
<li>Generating and managing RDF triples</li>
<li>Handling resource URIs and labels</li>
<li>Managing resource relationships and hierarchies</li>
<li>Supporting metadata and provenance information</li>
<li>Validating resource creation inputs</li>
</ul>
</dd>
<dt><a href="#module_Lineage_createSLSVsource">Lineage_createSLSVsource</a></dt>
<dd><p>Module for creating new SLSV (Sous Le Sens Vocables) sources in the system.
Provides functionality for:</p>
<ul>
<li>Creating and configuring new ontology sources</li>
<li>Managing source metadata and configuration</li>
<li>Handling source imports and dependencies</li>
<li>Managing user permissions and ownership</li>
<li>Supporting source validation and persistence</li>
<li>Integrating with the SLSV bot system</li>
</ul>
</dd>
<dt><a href="#module_Lineage_decoration">Lineage_decoration</a></dt>
<dd><p>Module for managing visual decorations and styling of nodes in the lineage graph.
Provides functionality for:</p>
<ul>
<li>Managing node colors and styles based on ontology classes</li>
<li>Handling legends and visual indicators</li>
<li>Supporting different decoration schemes (upper ontology, custom)</li>
<li>Managing predefined color schemes</li>
<li>Handling node shapes and icons</li>
<li>Supporting dynamic visual updates</li>
</ul>
</dd>
<dt><a href="#module_Lineage_dictionary">Lineage_dictionary</a></dt>
<dd><p>Module for managing ontology dictionaries and term mappings.
Provides functionality for:</p>
<ul>
<li>Managing term mappings between different ontology sources</li>
<li>Supporting dictionary-based operations and queries</li>
<li>Handling domain and range source relationships</li>
<li>Managing dictionary filters and constraints</li>
<li>Supporting dictionary visualization and navigation</li>
<li>Handling dictionary metadata and timestamps</li>
<li>Supporting dictionary-based search and filtering</li>
</ul>
</dd>
<dt><a href="#module_Lineage_graphTraversal">Lineage_graphTraversal</a></dt>
<dd><p>Module for managing the shortest path search between nodes in the Lineage graph.</p>
</dd>
<dt><a href="#module_Lineage_properties">Lineage_properties</a></dt>
<dd><p>Module for managing ontology properties and their relationships.
Provides functionality for:</p>
<ul>
<li>Managing object and data properties</li>
<li>Visualizing property hierarchies</li>
<li>Handling property restrictions and constraints</li>
<li>Supporting property domains and ranges</li>
<li>Managing property metadata and visualization</li>
<li>Supporting property tree operations</li>
<li>Handling property-based graph operations</li>
</ul>
</dd>
<dt><a href="#module_Lineage_reasoner">Lineage_reasoner</a></dt>
<dd><p>Module for performing reasoning operations on ontologies.
Provides functionality for:</p>
<ul>
<li>Running inference operations on ontologies</li>
<li>Checking ontology consistency</li>
<li>Detecting unsatisfiable classes</li>
<li>Managing inference rules and predicates</li>
<li>Visualizing reasoning results</li>
<li>Supporting different reasoning operations</li>
<li>Handling reasoning errors and results</li>
</ul>
</dd>
<dt><a href="#module_Lineage_relationFilter">Lineage_relationFilter</a></dt>
<dd><p>Module for filtering and managing relationships between ontology nodes.
Provides functionality for:</p>
<ul>
<li>Creating and applying filters on node relationships</li>
<li>Managing property restrictions and constraints</li>
<li>Supporting different filter types (string, date, number)</li>
<li>Handling domain and range filters</li>
<li>Managing filter roles (subject/object)</li>
<li>Supporting complex filter conditions</li>
<li>Validating filter inputs</li>
</ul>
</dd>
<dt><a href="#module_Lineage_relationIndividualsFilter">Lineage_relationIndividualsFilter</a></dt>
<dd><p>Module for managing filters on individuals in ontology relationships.
Provides functionality for:</p>
<ul>
<li>Filtering individuals based on class membership</li>
<li>Supporting date-based filtering of individuals</li>
<li>Managing advanced search criteria for individuals</li>
<li>Handling individual selection and filtering UI</li>
<li>Supporting range and domain filtering</li>
<li>Managing filter persistence and application</li>
<li>Supporting multiple filter types and combinations</li>
<li>Coordinating with relation visualization</li>
</ul>
</dd>
<dt><a href="#module_Lineage_relations">Lineage_relations</a></dt>
<dd><p>Module for managing and visualizing relationships between nodes in the lineage graph.
Provides functionality for:</p>
<ul>
<li>Drawing and filtering relationships between nodes</li>
<li>Managing property trees and their visualization</li>
<li>Handling relationship queries and filters</li>
<li>Managing relationship colors and visual styles</li>
<li>Supporting different types of relationships (hierarchical, semantic, etc.)</li>
</ul>
</dd>
<dt><a href="#module_Lineage_rules">Lineage_rules</a></dt>
<dd><p>Module for managing ontological rules and constraints.
Provides functionality for:</p>
<ul>
<li>Creating and managing ontology rules</li>
<li>Handling premises and conclusions</li>
<li>Supporting rule-based reasoning</li>
<li>Managing rule components and relationships</li>
<li>Supporting rule validation and execution</li>
<li>Handling rule visualization and editing</li>
<li>Managing rule-based constraints</li>
</ul>
</dd>
<dt><a href="#module_Lineage_selection">Lineage_selection</a></dt>
<dd><p>Module for managing node selection in the lineage graph.
Provides functionality for:</p>
<ul>
<li>Selecting and deselecting nodes</li>
<li>Managing multiple node selections</li>
<li>Visualizing selected nodes</li>
<li>Supporting keyboard modifiers for selection</li>
<li>Handling selection events and actions</li>
<li>Managing selection trees and hierarchies</li>
<li>Supporting selection-based operations</li>
</ul>
</dd>
<dt><a href="#module_Lineage_similars">Lineage_similars</a></dt>
<dd><p>Module for finding and visualizing similar nodes across different ontology sources.
Provides functionality for:</p>
<ul>
<li>Finding nodes with similar labels or properties</li>
<li>Comparing nodes across different sources</li>
<li>Visualizing similar nodes in the graph</li>
<li>Supporting exact and fuzzy matching</li>
<li>Managing source-specific similarity searches</li>
<li>Handling node selection and comparison</li>
<li>Supporting interactive similarity exploration</li>
</ul>
</dd>
<dt><a href="#module_Lineage_sources">Lineage_sources</a></dt>
<dd><p>Module for managing ontology sources in the lineage system.
Provides functionality for:</p>
<ul>
<li>Loading and initializing ontology sources</li>
<li>Managing source selection and activation</li>
<li>Handling source-specific UI elements and themes</li>
<li>Supporting source imports and dependencies</li>
<li>Managing source metadata and configurations</li>
<li>Coordinating source-related operations with other modules</li>
<li>Supporting source validation and persistence</li>
</ul>
</dd>
<dt><a href="#module_Lineage_whiteboard">Lineage_whiteboard</a></dt>
<dd></dd>
<dt><a href="#module_KGquery">KGquery</a></dt>
<dd><p>KGquery Module
Module for querying and visualizing knowledge graphs.
Provides functionality to build and execute queries on knowledge graphs.</p>
</dd>
<dt><a href="#module_KGquery">KGquery</a></dt>
<dd><p>KGquery Module
Module for querying and visualizing knowledge graphs.
Provides functionality to build and execute queries on knowledge graphs.</p>
</dd>
<dt><a href="#module_KGquery_controlPanel">KGquery_controlPanel</a></dt>
<dd><p>KGquery_controlPanel Module
Handles the user interface control panel for knowledge graph queries.</p>
</dd>
<dt><a href="#module_KGquery_filter">KGquery_filter</a></dt>
<dd><p>KGquery_filter Module
Handles filtering functionality for knowledge graph queries.</p>
</dd>
<dt><a href="#module_KGquery_myQueries">KGquery_myQueries</a></dt>
<dd><p>KGquery_myQueries Module
Handles saving and loading of knowledge graph queries.</p>
</dd>
<dt><a href="#module_KGquery_nodeSelector">KGquery_nodeSelector</a></dt>
<dd><p>KGquery_nodeSelector Module
Module for selecting and managing nodes in knowledge graph queries.</p>
</dd>
<dt><a href="#module_KGquery_paths">KGquery_paths</a></dt>
<dd><p>Module for managing paths in knowledge graph queries.
This module provides functionality for:</p>
<ul>
<li>Configuring and managing paths between nodes</li>
<li>Manipulating identifiers and variables in paths</li>
<li>Managing graphical display of paths</li>
<li>Finding shortest paths between nodes</li>
<li>Managing path ambiguities</li>
</ul>
</dd>
<dt><a href="#module_DataSourceManager">DataSourceManager</a></dt>
<dd><p>DataSourceManager module
Responsible for managing data source configurations and operations.</p>
</dd>
<dt><a href="#module_MappingColumnsGraph">MappingColumnsGraph</a></dt>
<dd><p>MappingColumnsGraph module.
Handles the visualization and management of mapping columns in a graph.</p>
</dd>
<dt><a href="#module_MappingModeler">MappingModeler</a></dt>
<dd><p>MappingModeler module.
The MappingModeler tool helps creating new mappings from sources, and visualising and editing these mappings.</p>
</dd>
<dt><a href="#module_MappingsDetails">MappingsDetails</a> : <code>Object</code></dt>
<dd><p>MappingsDetails manages technical mappings (non structural mappings)</p>
</dd>
<dt><a href="#module_MappingTransform">MappingTransform</a></dt>
<dd><p>Module responsible for generating and managing mappings for the MappingTransform process.
It interacts with the Vis.js graph to retrieve mappings and formats them as JSON for use in the application.
It also provides functionality for generating SLS mappings and R2ML mappings (coming soon).</p>
</dd>
<dt><a href="#module_TripleFactory">TripleFactory</a></dt>
<dd><p>The TripleFactory module handles the creation, filtering, and writing of RDF triples.
It includes functions for generating sample triples, creating all mappings triples, and indexing the graph.</p>
</dd>
<dt><a href="#module_UIcontroller">UIcontroller</a></dt>
<dd><p>UIcontroller module manages the display of panels in the mapping modeler interface,
handling tab activation and panel visibility for data sources, column mappings, technical mappings, and triples.</p>
</dd>
</dl>

## Functions

<dl>
<dt><a href="#saveVisjsModelGraph">saveVisjsModelGraph([callback])</a></dt>
<dd><p>Saves the current Vis.js graph model.</p>
</dd>
</dl>

<a name="module_Lineage_axioms"></a>

## Lineage\_axioms
Module for managing and visualizing ontological axioms in the lineage graph.
Provides functionality for:
- Visualizing classes with their associated axioms
- Drawing axiom relationships in the graph
- Supporting different types of axioms
- Testing axiom functionality
- Managing axiom metadata and visualization


* [Lineage_axioms](#module_Lineage_axioms)
    * [.drawClassesWithAxioms([source], [axiomType])](#module_Lineage_axioms.drawClassesWithAxioms) ⇒ <code>void</code>
    * [.testAxioms()](#module_Lineage_axioms.testAxioms) ⇒ <code>void</code>

<a name="module_Lineage_axioms.drawClassesWithAxioms"></a>

### Lineage_axioms.drawClassesWithAxioms([source], [axiomType]) ⇒ <code>void</code>
Draws classes with associated axioms in a visual graph representation.
Retrieves axioms from the specified source and visualizes them using Vis.js.

**Kind**: static method of [<code>Lineage\_axioms</code>](#module_Lineage_axioms)  

| Param | Type | Description |
| --- | --- | --- |
| [source] | <code>string</code> | The name of the data source. Defaults to the active source if not provided. |
| [axiomType] | <code>string</code> | The specific type of axiom to filter by (optional). |

<a name="module_Lineage_axioms.testAxioms"></a>

### Lineage_axioms.testAxioms() ⇒ <code>void</code>
Tests axiom functionalities by initializing a sample node with axiom data.
Opens a dialog displaying axioms for the test node.

**Kind**: static method of [<code>Lineage\_axioms</code>](#module_Lineage_axioms)  
<a name="module_Lineage_combine"></a>

## Lineage\_combine
Module for combining and merging multiple ontology sources in the lineage graph.
Provides functionality for:
- Adding multiple ontology sources to the graph
- Merging nodes from different sources
- Managing source visibility and grouping
- Handling node hierarchies during merges
- Supporting different merge modes and depths
- Preserving ontological restrictions during merges


* [Lineage_combine](#module_Lineage_combine)
    * [.showSourcesDialog()](#module_Lineage_combine.showSourcesDialog) ⇒ <code>void</code>
    * [.init()](#module_Lineage_combine.init) ⇒ <code>void</code>
    * [.addSelectedSourcesToGraph()](#module_Lineage_combine.addSelectedSourcesToGraph) ⇒ <code>void</code>
    * [.setGraphPopupMenus()](#module_Lineage_combine.setGraphPopupMenus) ⇒ <code>void</code>
    * [.showMergeNodesDialog([fromNode], [toNode])](#module_Lineage_combine.showMergeNodesDialog) ⇒ <code>void</code>
    * [.mergeNodesUI([testObj])](#module_Lineage_combine.mergeNodesUI) ⇒ <code>void</code>
    * [.mergeNodes(jstreeNodes, mergeMode, mergeDepth, mergeRestrictions, mergedNodesType, targetSource, [targetNode], callback)](#module_Lineage_combine.mergeNodes) ⇒ <code>void</code>

<a name="module_Lineage_combine.showSourcesDialog"></a>

### Lineage_combine.showSourcesDialog() ⇒ <code>void</code>
Displays a dialog for selecting ontology sources to add to the graph.
Supports OWL and SKOS sources.

**Kind**: static method of [<code>Lineage\_combine</code>](#module_Lineage_combine)  
<a name="module_Lineage_combine.init"></a>

### Lineage_combine.init() ⇒ <code>void</code>
Initializes the Lineage_combine module by resetting selected sources
and hiding action-related UI elements.

**Kind**: static method of [<code>Lineage\_combine</code>](#module_Lineage_combine)  
<a name="module_Lineage_combine.addSelectedSourcesToGraph"></a>

### Lineage_combine.addSelectedSourcesToGraph() ⇒ <code>void</code>
Adds selected ontology sources to the graph and updates the UI accordingly.
Registers the selected sources, draws their top concepts, and updates menu actions.

**Kind**: static method of [<code>Lineage\_combine</code>](#module_Lineage_combine)  
<a name="module_Lineage_combine.setGraphPopupMenus"></a>

### Lineage_combine.setGraphPopupMenus() ⇒ <code>void</code>
Sets the popup menu options for the graph, including actions to hide, show,
group, and ungroup sources.

**Kind**: static method of [<code>Lineage\_combine</code>](#module_Lineage_combine)  
<a name="module_Lineage_combine.showMergeNodesDialog"></a>

### Lineage_combine.showMergeNodesDialog([fromNode], [toNode]) ⇒ <code>void</code>
Displays a dialog for merging selected ontology nodes. Allows users to specify
the target source and node, select merge options, and choose nodes for merging.

**Kind**: static method of [<code>Lineage\_combine</code>](#module_Lineage_combine)  

| Param | Type | Description |
| --- | --- | --- |
| [fromNode] | <code>Object</code> | The node from which the merge is initiated. |
| [toNode] | <code>Object</code> | The target node for the merge. |

<a name="module_Lineage_combine.mergeNodesUI"></a>

### Lineage_combine.mergeNodesUI([testObj]) ⇒ <code>void</code>
Handles the UI logic for merging ontology nodes. Gathers user input such as
target source, merge mode, and selected nodes before triggering the merge process.

**Kind**: static method of [<code>Lineage\_combine</code>](#module_Lineage_combine)  

| Param | Type | Description |
| --- | --- | --- |
| [testObj] | <code>Object</code> | Optional test object for debugging. |

<a name="module_Lineage_combine.mergeNodes"></a>

### Lineage_combine.mergeNodes(jstreeNodes, mergeMode, mergeDepth, mergeRestrictions, mergedNodesType, targetSource, [targetNode], callback) ⇒ <code>void</code>
Merges multiple ontology nodes into a target source, preserving hierarchy and restrictions.
This function retrieves node descendants, applies restrictions, and inserts the merged data into the target source.

**Kind**: static method of [<code>Lineage\_combine</code>](#module_Lineage_combine)  

| Param | Type | Description |
| --- | --- | --- |
| jstreeNodes | <code>Array.&lt;Object&gt;</code> | The nodes selected for merging, represented as jstree objects. |
| mergeMode | <code>string</code> | The merging mode, e.g., "keepUri". |
| mergeDepth | <code>string</code> | Defines the depth of the merge operation ("nodeOnly", "nodeAndDirectChildren", "nodeDescendantsOnly"). |
| mergeRestrictions | <code>boolean</code> | Whether to include ontology restrictions in the merge. |
| mergedNodesType | <code>string</code> | The RDF type of the merged nodes (e.g., "owl:NamedIndividual", "owl:Class"). |
| targetSource | <code>string</code> | The target source where merged nodes will be inserted. |
| [targetNode] | <code>string</code> | The optional parent node under which merged nodes will be placed. |
| callback | <code>function</code> | A callback function executed after the merge process completes. |

<a name="module_Lineage_common"></a>

## Lineage\_common
Common utility functions for the lineage system.
Provides functionality for:
- Managing clipboard operations with nodes
- Node deletion and manipulation
- Copy/paste operations between nodes
- Managing ontology imports
- Basic node operations and validations


* [Lineage_common](#module_Lineage_common)
    * [.copyNodeToClipboard(nodeData)](#module_Lineage_common.copyNodeToClipboard) ⇒ <code>void</code>
    * [.deleteNode(node, jstreeId)](#module_Lineage_common.deleteNode) ⇒ <code>void</code>
    * [.pasteNodeFromClipboard(parentNode)](#module_Lineage_common.pasteNodeFromClipboard) ⇒ <code>void</code>
    * [.onshowImportsCBXChange(cbx)](#module_Lineage_common.onshowImportsCBXChange) ⇒ <code>void</code>

<a name="module_Lineage_common.copyNodeToClipboard"></a>

### Lineage_common.copyNodeToClipboard(nodeData) ⇒ <code>void</code>
Copies a node's data to the clipboard as a JSON string.

**Kind**: static method of [<code>Lineage\_common</code>](#module_Lineage_common)  

| Param | Type | Description |
| --- | --- | --- |
| nodeData | <code>Object</code> | The node data to copy. |

<a name="module_Lineage_common.deleteNode"></a>

### Lineage_common.deleteNode(node, jstreeId) ⇒ <code>void</code>
Deletes a specified ontology node, removing its associated triples.
If the node has children, deletion is prevented.

**Kind**: static method of [<code>Lineage\_common</code>](#module_Lineage_common)  

| Param | Type | Description |
| --- | --- | --- |
| node | <code>Object</code> | The node to delete. |
| jstreeId | <code>string</code> | The ID of the jstree instance where the node is displayed. |

<a name="module_Lineage_common.pasteNodeFromClipboard"></a>

### Lineage_common.pasteNodeFromClipboard(parentNode) ⇒ <code>void</code>
Pastes a copied node from the clipboard under a specified parent node.
The function ensures that only compatible node types are pasted.

**Kind**: static method of [<code>Lineage\_common</code>](#module_Lineage_common)  

| Param | Type | Description |
| --- | --- | --- |
| parentNode | <code>Object</code> | The parent node under which the copied node will be pasted. |

<a name="module_Lineage_common.onshowImportsCBXChange"></a>

### Lineage_common.onshowImportsCBXChange(cbx) ⇒ <code>void</code>
Toggles the inclusion of ontology imports in SPARQL queries.

**Kind**: static method of [<code>Lineage\_common</code>](#module_Lineage_common)  

| Param | Type | Description |
| --- | --- | --- |
| cbx | <code>HTMLInputElement</code> | The checkbox input element controlling the setting. |

<a name="module_Lineage_createRelation"></a>

## Lineage\_createRelation
Module for creating and managing relationships between ontology nodes.Provides functionality for:- Creating new relationships between nodes in the ontology- Managing relationship types and properties- Validating relationship constraints- Supporting different types of ontological relationships- Managing relationship metadata and restrictions- Integrating with the ontology model system

<a name="module_Lineage_createResource"></a>

## Lineage\_createResource
Module for creating new resources (classes, named individuals) in the ontology.
Provides functionality for:
- Creating new classes and named individuals
- Generating and managing RDF triples
- Handling resource URIs and labels
- Managing resource relationships and hierarchies
- Supporting metadata and provenance information
- Validating resource creation inputs

<a name="module_Lineage_createResource..getTriple"></a>

### Lineage_createResource~getTriple(resourceUri, predicate, object) ⇒ <code>Object</code>
Helper function to create a triple object with subject, predicate and object.

**Kind**: inner method of [<code>Lineage\_createResource</code>](#module_Lineage_createResource)  
**Returns**: <code>Object</code> - Triple object with subject, predicate and object properties  

| Param | Type | Description |
| --- | --- | --- |
| resourceUri | <code>string</code> | The URI of the resource (subject) |
| predicate | <code>string</code> | The predicate of the triple |
| object | <code>string</code> | The object of the triple |

<a name="module_Lineage_createSLSVsource"></a>

## Lineage\_createSLSVsource
Module for creating new SLSV (Sous Le Sens Vocables) sources in the system.
Provides functionality for:
- Creating and configuring new ontology sources
- Managing source metadata and configuration
- Handling source imports and dependencies
- Managing user permissions and ownership
- Supporting source validation and persistence
- Integrating with the SLSV bot system

<a name="module_Lineage_decoration"></a>

## Lineage\_decoration
Module for managing visual decorations and styling of nodes in the lineage graph.
Provides functionality for:
- Managing node colors and styles based on ontology classes
- Handling legends and visual indicators
- Supporting different decoration schemes (upper ontology, custom)
- Managing predefined color schemes
- Handling node shapes and icons
- Supporting dynamic visual updates

<a name="module_Lineage_dictionary"></a>

## Lineage\_dictionary
Module for managing ontology dictionaries and term mappings.
Provides functionality for:
- Managing term mappings between different ontology sources
- Supporting dictionary-based operations and queries
- Handling domain and range source relationships
- Managing dictionary filters and constraints
- Supporting dictionary visualization and navigation
- Handling dictionary metadata and timestamps
- Supporting dictionary-based search and filtering


* [Lineage_dictionary](#module_Lineage_dictionary)
    * [.onLoaded()](#module_Lineage_dictionary.onLoaded) ⇒ <code>void</code>
    * [.showTSFdictionaryDialog(context)](#module_Lineage_dictionary.showTSFdictionaryDialog) ⇒ <code>void</code>
    * [.onChangeFilterSelect(value)](#module_Lineage_dictionary.onChangeFilterSelect) ⇒ <code>void</code>
    * [.getDictionarySources(dictionary, [domainSource], [rangeSource], callback)](#module_Lineage_dictionary.getDictionarySources) ⇒ <code>void</code>
    * [.getDictionaryFilters()](#module_Lineage_dictionary.getDictionaryFilters) ⇒ <code>string</code>
    * [.getFilterPredicates(subjectVarname)](#module_Lineage_dictionary.getFilterPredicates) ⇒ <code>string</code>
    * [.fillDictionaryFilters(filterClassName, source)](#module_Lineage_dictionary.fillDictionaryFilters) ⇒ <code>void</code>
    * [.exportDictionaryToTable(filters)](#module_Lineage_dictionary.exportDictionaryToTable) ⇒ <code>void</code>

<a name="module_Lineage_dictionary.onLoaded"></a>

### Lineage_dictionary.onLoaded() ⇒ <code>void</code>
Callback function executed when the dictionary module is loaded.
Shows the TSF dictionary dialog in the Lineage_dictionary context.

**Kind**: static method of [<code>Lineage\_dictionary</code>](#module_Lineage_dictionary)  
<a name="module_Lineage_dictionary.showTSFdictionaryDialog"></a>

### Lineage_dictionary.showTSFdictionaryDialog(context) ⇒ <code>void</code>
Displays the TSF dictionary dialog with appropriate configuration based on context.

**Kind**: static method of [<code>Lineage\_dictionary</code>](#module_Lineage_dictionary)  

| Param | Type | Description |
| --- | --- | --- |
| context | <code>string</code> | The context in which to show the dictionary ("Lineage_dictionary", "Lineage_similars", or "Lineage_relations"). |

<a name="module_Lineage_dictionary.onChangeFilterSelect"></a>

### Lineage_dictionary.onChangeFilterSelect(value) ⇒ <code>void</code>
Event handler for changes in filter select elements.
Updates dictionary filters based on the selected value.

**Kind**: static method of [<code>Lineage\_dictionary</code>](#module_Lineage_dictionary)  

| Param | Type | Description |
| --- | --- | --- |
| value | <code>string</code> | The selected filter value. |

<a name="module_Lineage_dictionary.getDictionarySources"></a>

### Lineage_dictionary.getDictionarySources(dictionary, [domainSource], [rangeSource], callback) ⇒ <code>void</code>
Retrieves dictionary sources with their domain and range labels.

**Kind**: static method of [<code>Lineage\_dictionary</code>](#module_Lineage_dictionary)  

| Param | Type | Description |
| --- | --- | --- |
| dictionary | <code>string</code> | The dictionary source to query. |
| [domainSource] | <code>string</code> | Optional domain source filter. |
| [rangeSource] | <code>string</code> | Optional range source filter. |
| callback | <code>function</code> | Callback function with signature (error, results). |

<a name="module_Lineage_dictionary.getDictionaryFilters"></a>

### Lineage_dictionary.getDictionaryFilters() ⇒ <code>string</code>
Retrieves current dictionary filters from the UI.

**Kind**: static method of [<code>Lineage\_dictionary</code>](#module_Lineage_dictionary)  
**Returns**: <code>string</code> - SPARQL filter string based on current UI filter values.  
<a name="module_Lineage_dictionary.getFilterPredicates"></a>

### Lineage_dictionary.getFilterPredicates(subjectVarname) ⇒ <code>string</code>
Gets filter predicates for a given subject variable.

**Kind**: static method of [<code>Lineage\_dictionary</code>](#module_Lineage_dictionary)  
**Returns**: <code>string</code> - SPARQL predicates string based on current UI filter values.  

| Param | Type | Description |
| --- | --- | --- |
| subjectVarname | <code>string</code> | The name of the subject variable in the SPARQL query. |

<a name="module_Lineage_dictionary.fillDictionaryFilters"></a>

### Lineage_dictionary.fillDictionaryFilters(filterClassName, source) ⇒ <code>void</code>
Populates dictionary filter select elements with available values.

**Kind**: static method of [<code>Lineage\_dictionary</code>](#module_Lineage_dictionary)  

| Param | Type | Description |
| --- | --- | --- |
| filterClassName | <code>string</code> | The CSS class name for filter elements. |
| source | <code>string</code> | The source to query for filter values. |

<a name="module_Lineage_dictionary.exportDictionaryToTable"></a>

### Lineage_dictionary.exportDictionaryToTable(filters) ⇒ <code>void</code>
Exports dictionary data to a table format based on current filters.

**Kind**: static method of [<code>Lineage\_dictionary</code>](#module_Lineage_dictionary)  

| Param | Type | Description |
| --- | --- | --- |
| filters | <code>Object</code> | Filter criteria for the export. |

<a name="module_Lineage_graphTraversal"></a>

## Lineage\_graphTraversal
Module for managing the shortest path search between nodes in the Lineage graph.

<a name="module_Lineage_properties"></a>

## Lineage\_properties
Module for managing ontology properties and their relationships.Provides functionality for:- Managing object and data properties- Visualizing property hierarchies- Handling property restrictions and constraints- Supporting property domains and ranges- Managing property metadata and visualization- Supporting property tree operations- Handling property-based graph operations


* [Lineage_properties](#module_Lineage_properties)
    * [.init()](#module_Lineage_properties.init) ⇒ <code>void</code>
    * [.showPropInfos(_event, obj)](#module_Lineage_properties.showPropInfos) ⇒ <code>void</code>
    * [.jstreeContextMenu()](#module_Lineage_properties.jstreeContextMenu) ⇒ <code>Object</code>
    * [.onTreeNodeClick(_event, obj)](#module_Lineage_properties.onTreeNodeClick) ⇒ <code>void</code>
    * [.openNode(node)](#module_Lineage_properties.openNode) ⇒ <code>void</code>
    * [.getPropertiesjsTreeData(source, ids, words, options, callback)](#module_Lineage_properties.getPropertiesjsTreeData) ⇒ <code>void</code>

<a name="module_Lineage_properties.init"></a>

### Lineage_properties.init() ⇒ <code>void</code>
Initializes the properties module by resetting the graph initialization state.

**Kind**: static method of [<code>Lineage\_properties</code>](#module_Lineage_properties)  
<a name="module_Lineage_properties.showPropInfos"></a>

### Lineage_properties.showPropInfos(_event, obj) ⇒ <code>void</code>
Displays property information in the graph div.

**Kind**: static method of [<code>Lineage\_properties</code>](#module_Lineage_properties)  

| Param | Type | Description |
| --- | --- | --- |
| _event | <code>Event</code> | The event object (unused). |
| obj | <code>Object</code> | Object containing the node information. |
| obj.node | <code>Object</code> | The node object. |
| obj.node.id | <code>string</code> | The ID of the node. |

<a name="module_Lineage_properties.jstreeContextMenu"></a>

### Lineage_properties.jstreeContextMenu() ⇒ <code>Object</code>
Creates the context menu for the jstree nodes.

**Kind**: static method of [<code>Lineage\_properties</code>](#module_Lineage_properties)  
**Returns**: <code>Object</code> - Object containing menu items and their actions.  
<a name="module_Lineage_properties.onTreeNodeClick"></a>

### Lineage_properties.onTreeNodeClick(_event, obj) ⇒ <code>void</code>
Handles click events on tree nodes.

**Kind**: static method of [<code>Lineage\_properties</code>](#module_Lineage_properties)  

| Param | Type | Description |
| --- | --- | --- |
| _event | <code>Event</code> | The click event object. |
| obj | <code>Object</code> | Object containing the clicked node information. |

<a name="module_Lineage_properties.openNode"></a>

### Lineage_properties.openNode(node) ⇒ <code>void</code>
Opens a node in the property tree and loads its subproperties.

**Kind**: static method of [<code>Lineage\_properties</code>](#module_Lineage_properties)  

| Param | Type | Description |
| --- | --- | --- |
| node | <code>Object</code> | The node to open. |
| node.data | <code>Object</code> | The node's data. |
| node.data.id | <code>string</code> | The node's ID. |
| node.data.source | <code>string</code> | The node's source. |

<a name="module_Lineage_properties.getPropertiesjsTreeData"></a>

### Lineage_properties.getPropertiesjsTreeData(source, ids, words, options, callback) ⇒ <code>void</code>
Generates jstree data structure for object properties.

**Kind**: static method of [<code>Lineage\_properties</code>](#module_Lineage_properties)  

| Param | Type | Description |
| --- | --- | --- |
| source | <code>string</code> | The source to query. |
| ids | <code>Array.&lt;string&gt;</code> | Array of property IDs to filter by. |
| words | <code>Array.&lt;string&gt;</code> | Array of words to search for in property labels. |
| options | <code>Object</code> | Additional options for the query. |
| [options.searchType] | <code>string</code> | Type of search to perform (filters properties on words present in predicate or subject or object label). |
| callback | <code>function</code> | Callback function with signature (error, jstreeData). |

<a name="module_Lineage_reasoner"></a>

## Lineage\_reasoner
Module for performing reasoning operations on ontologies.
Provides functionality for:
- Running inference operations on ontologies
- Checking ontology consistency
- Detecting unsatisfiable classes
- Managing inference rules and predicates
- Visualizing reasoning results
- Supporting different reasoning operations
- Handling reasoning errors and results


* [Lineage_reasoner](#module_Lineage_reasoner)
    * [.showReasonerDialog()](#module_Lineage_reasoner.showReasonerDialog) ⇒ <code>void</code>
    * [.runOperation(operation)](#module_Lineage_reasoner.runOperation) ⇒ <code>void</code>
    * [.runConsistency()](#module_Lineage_reasoner.runConsistency) ⇒ <code>void</code>
    * [.runUnsatisfiable()](#module_Lineage_reasoner.runUnsatisfiable) ⇒ <code>void</code>
    * [.showInferencePredicates()](#module_Lineage_reasoner.showInferencePredicates) ⇒ <code>void</code>
    * [.runInference(predicates, callback)](#module_Lineage_reasoner.runInference) ⇒ <code>void</code>
    * [.execute()](#module_Lineage_reasoner.execute) ⇒ <code>void</code>
    * [.listInferenceSubjects()](#module_Lineage_reasoner.listInferenceSubjects) ⇒ <code>void</code>
    * [.displayInference()](#module_Lineage_reasoner.displayInference) ⇒ <code>void</code>

<a name="module_Lineage_reasoner.showReasonerDialog"></a>

### Lineage_reasoner.showReasonerDialog() ⇒ <code>void</code>
Shows the reasoner dialog with options for different reasoning operations.

**Kind**: static method of [<code>Lineage\_reasoner</code>](#module_Lineage_reasoner)  
<a name="module_Lineage_reasoner.runOperation"></a>

### Lineage_reasoner.runOperation(operation) ⇒ <code>void</code>
Runs a selected reasoning operation (Inference, Consistency, or Unsatisfiable).

**Kind**: static method of [<code>Lineage\_reasoner</code>](#module_Lineage_reasoner)  

| Param | Type | Description |
| --- | --- | --- |
| operation | <code>string</code> | The type of reasoning operation to run. |

<a name="module_Lineage_reasoner.runConsistency"></a>

### Lineage_reasoner.runConsistency() ⇒ <code>void</code>
Runs a consistency check on the current ontology.

**Kind**: static method of [<code>Lineage\_reasoner</code>](#module_Lineage_reasoner)  
<a name="module_Lineage_reasoner.runUnsatisfiable"></a>

### Lineage_reasoner.runUnsatisfiable() ⇒ <code>void</code>
Runs an unsatisfiability check on the current ontology.

**Kind**: static method of [<code>Lineage\_reasoner</code>](#module_Lineage_reasoner)  
<a name="module_Lineage_reasoner.showInferencePredicates"></a>

### Lineage_reasoner.showInferencePredicates() ⇒ <code>void</code>
Shows available inference predicates in a tree structure.

**Kind**: static method of [<code>Lineage\_reasoner</code>](#module_Lineage_reasoner)  
<a name="module_Lineage_reasoner.runInference"></a>

### Lineage_reasoner.runInference(predicates, callback) ⇒ <code>void</code>
Runs inference on the selected predicates.

**Kind**: static method of [<code>Lineage\_reasoner</code>](#module_Lineage_reasoner)  

| Param | Type | Description |
| --- | --- | --- |
| predicates | <code>Array.&lt;string&gt;</code> | Array of predicates to use for inference. |
| callback | <code>function</code> | Callback function with signature (error, result). |

<a name="module_Lineage_reasoner.execute"></a>

### Lineage_reasoner.execute() ⇒ <code>void</code>
Executes the selected reasoning operation and displays results.

**Kind**: static method of [<code>Lineage\_reasoner</code>](#module_Lineage_reasoner)  
<a name="module_Lineage_reasoner.listInferenceSubjects"></a>

### Lineage_reasoner.listInferenceSubjects() ⇒ <code>void</code>
Lists subjects from inference results in a tree structure.

**Kind**: static method of [<code>Lineage\_reasoner</code>](#module_Lineage_reasoner)  
<a name="module_Lineage_reasoner.displayInference"></a>

### Lineage_reasoner.displayInference() ⇒ <code>void</code>
Displays inference results in either table or graph format.

**Kind**: static method of [<code>Lineage\_reasoner</code>](#module_Lineage_reasoner)  
<a name="module_Lineage_relationFilter"></a>

## Lineage\_relationFilter
Module for filtering and managing relationships between ontology nodes.
Provides functionality for:
- Creating and applying filters on node relationships
- Managing property restrictions and constraints
- Supporting different filter types (string, date, number)
- Handling domain and range filters
- Managing filter roles (subject/object)
- Supporting complex filter conditions
- Validating filter inputs


* [Lineage_relationFilter](#module_Lineage_relationFilter)
    * [.showAddFilterDiv(clear)](#module_Lineage_relationFilter.showAddFilterDiv) ⇒ <code>void</code>
    * [.onSelectRoleType(role)](#module_Lineage_relationFilter.onSelectRoleType) ⇒ <code>void</code>
    * [.onCommonUIWidgetSelectObjectValue(value)](#module_Lineage_relationFilter.onCommonUIWidgetSelectObjectValue) ⇒ <code>void</code>
    * [.addFilter()](#module_Lineage_relationFilter.addFilter) ⇒ <code>void</code>

<a name="module_Lineage_relationFilter.showAddFilterDiv"></a>

### Lineage_relationFilter.showAddFilterDiv(clear) ⇒ <code>void</code>
Displays the user interface for adding a filter on a relation.

**Kind**: static method of [<code>Lineage\_relationFilter</code>](#module_Lineage_relationFilter)  

| Param | Type | Description |
| --- | --- | --- |
| clear | <code>boolean</code> | Indicates if the current property should be reset. |

<a name="module_Lineage_relationFilter.onSelectRoleType"></a>

### Lineage_relationFilter.onSelectRoleType(role) ⇒ <code>void</code>
Handles the selection of a role type (subject or object) for the filter.

**Kind**: static method of [<code>Lineage\_relationFilter</code>](#module_Lineage_relationFilter)  

| Param | Type | Description |
| --- | --- | --- |
| role | <code>string</code> | The selected role ("subject" or "object"). |

<a name="module_Lineage_relationFilter.onCommonUIWidgetSelectObjectValue"></a>

### Lineage_relationFilter.onCommonUIWidgetSelectObjectValue(value) ⇒ <code>void</code>
Applies specific formatting to the selected value based on its type.

**Kind**: static method of [<code>Lineage\_relationFilter</code>](#module_Lineage_relationFilter)  

| Param | Type | Description |
| --- | --- | --- |
| value | <code>string</code> | The selected value. |

<a name="module_Lineage_relationFilter.addFilter"></a>

### Lineage_relationFilter.addFilter() ⇒ <code>void</code>
Adds a filter based on the selected property and value.

**Kind**: static method of [<code>Lineage\_relationFilter</code>](#module_Lineage_relationFilter)  
<a name="module_Lineage_relationIndividualsFilter"></a>

## Lineage\_relationIndividualsFilter
Module for managing filters on individuals in ontology relationships.
Provides functionality for:
- Filtering individuals based on class membership
- Supporting date-based filtering of individuals
- Managing advanced search criteria for individuals
- Handling individual selection and filtering UI
- Supporting range and domain filtering
- Managing filter persistence and application
- Supporting multiple filter types and combinations
- Coordinating with relation visualization

<a name="module_Lineage_relations"></a>

## Lineage\_relations
Module for managing and visualizing relationships between nodes in the lineage graph.
Provides functionality for:
- Drawing and filtering relationships between nodes
- Managing property trees and their visualization
- Handling relationship queries and filters
- Managing relationship colors and visual styles
- Supporting different types of relationships (hierarchical, semantic, etc.)


* [Lineage_relations](#module_Lineage_relations)
    * [.showDrawRelationsDialog(caller)](#module_Lineage_relations.showDrawRelationsDialog) ⇒ <code>void</code>
    * [.getPropertiesJstreeMenu()](#module_Lineage_relations.getPropertiesJstreeMenu) ⇒ <code>Object</code>
    * [.onSelectPropertyTreeNode(event, object)](#module_Lineage_relations.onSelectPropertyTreeNode) ⇒ <code>void</code>
    * [.onFilterObjectTypeSelect(role, type)](#module_Lineage_relations.onFilterObjectTypeSelect) ⇒ <code>void</code>
    * [.onshowDrawRelationsDialogValidate(action, [_type])](#module_Lineage_relations.onshowDrawRelationsDialogValidate) ⇒ <code>void</code>
    * [.outlineWhiteboardNodes(options)](#module_Lineage_relations.outlineWhiteboardNodes) ⇒ <code>void</code>
    * [.drawRelations(direction, type, caller, options, [graphDiv])](#module_Lineage_relations.drawRelations) ⇒ <code>void</code>
    * [.getInferredProperties(source, callback, result)](#module_Lineage_relations.getInferredProperties) ⇒ <code>void</code>
    * [.onCheckNodePropertyTreeNode(event, obj)](#module_Lineage_relations.onCheckNodePropertyTreeNode) ⇒ <code>void</code>
    * [.callPreviousQuery()](#module_Lineage_relations.callPreviousQuery) ⇒ <code>void</code>
    * [.loadUserQueries()](#module_Lineage_relations.loadUserQueries) ⇒ <code>void</code>
    * [.onSelectSavedQuery(id)](#module_Lineage_relations.onSelectSavedQuery) ⇒ <code>void</code>
    * [.saveCurrentQuery()](#module_Lineage_relations.saveCurrentQuery) ⇒ <code>void</code>
    * [.deleteSavedQuery(id)](#module_Lineage_relations.deleteSavedQuery) ⇒ <code>void</code>
    * [.drawEquivalentClasses(source, data, callback)](#module_Lineage_relations.drawEquivalentClasses) ⇒ <code>void</code>

<a name="module_Lineage_relations.showDrawRelationsDialog"></a>

### Lineage_relations.showDrawRelationsDialog(caller) ⇒ <code>void</code>
Shows the dialog for drawing relations between nodes in the graph.

**Kind**: static method of [<code>Lineage\_relations</code>](#module_Lineage_relations)  

| Param | Type | Description |
| --- | --- | --- |
| caller | <code>string</code> | The caller of the function ("Graph", "Tree", etc.). |

<a name="module_Lineage_relations.getPropertiesJstreeMenu"></a>

### Lineage_relations.getPropertiesJstreeMenu() ⇒ <code>Object</code>
Returns the context menu for the properties tree.

**Kind**: static method of [<code>Lineage\_relations</code>](#module_Lineage_relations)  
**Returns**: <code>Object</code> - The context menu items.  
<a name="module_Lineage_relations.onSelectPropertyTreeNode"></a>

### Lineage_relations.onSelectPropertyTreeNode(event, object) ⇒ <code>void</code>
Handles the selection of a node in the properties tree.

**Kind**: static method of [<code>Lineage\_relations</code>](#module_Lineage_relations)  

| Param | Type | Description |
| --- | --- | --- |
| event | <code>Event</code> | The selection event. |
| object | <code>Object</code> | The object containing node data. |
| object.node | <code>Object</code> | The selected node. |
| object.node.parent | <code>string</code> | The parent node ID. |
| object.node.data | <code>Object</code> | Additional node data. |

<a name="module_Lineage_relations.onFilterObjectTypeSelect"></a>

### Lineage_relations.onFilterObjectTypeSelect(role, type) ⇒ <code>void</code>
Handles the selection of object type for filtering.

**Kind**: static method of [<code>Lineage\_relations</code>](#module_Lineage_relations)  

| Param | Type | Description |
| --- | --- | --- |
| role | <code>string</code> | The role of the object (subject or object). |
| type | <code>string</code> | The selected object type. |

<a name="module_Lineage_relations.onshowDrawRelationsDialogValidate"></a>

### Lineage_relations.onshowDrawRelationsDialogValidate(action, [_type]) ⇒ <code>void</code>
Validates and executes the selected action in the relations dialog.

**Kind**: static method of [<code>Lineage\_relations</code>](#module_Lineage_relations)  

| Param | Type | Description |
| --- | --- | --- |
| action | <code>string</code> | The action to execute ("clear" or "draw"). |
| [_type] | <code>string</code> | The type of relation (unused). |

<a name="module_Lineage_relations.outlineWhiteboardNodes"></a>

### Lineage_relations.outlineWhiteboardNodes(options) ⇒ <code>void</code>
Outlines nodes in the whiteboard based on their properties.

**Kind**: static method of [<code>Lineage\_relations</code>](#module_Lineage_relations)  

| Param | Type | Description |
| --- | --- | --- |
| options | <code>Object</code> | Configuration options for outlining nodes. |
| options.filter | <code>string</code> | SPARQL filter to apply when querying nodes. |
| options.output | <code>string</code> | The output format ("outline"). |
| options.edgesColor | <code>string</code> | Color to use for edges. |

<a name="module_Lineage_relations.drawRelations"></a>

### Lineage_relations.drawRelations(direction, type, caller, options, [graphDiv]) ⇒ <code>void</code>
Draws relations between nodes in the graph.

**Kind**: static method of [<code>Lineage\_relations</code>](#module_Lineage_relations)  

| Param | Type | Default | Description |
| --- | --- | --- | --- |
| direction | <code>string</code> |  | Direction of relations ("direct", "inverse", or "both"). |
| type | <code>string</code> |  | Type of relations to draw ("restrictions", "dictionary", etc.). |
| caller | <code>string</code> |  | The caller of the function ("Graph", "Tree", "leftPanel", etc.). |
| options | <code>Object</code> |  | Configuration options for drawing relations. |
| [options.skipLiterals] | <code>boolean</code> | <code>true</code> | Whether to skip literal nodes. |
| [options.source] | <code>string</code> |  | Source to use for relations. |
| [options.data] | <code>string</code> \| <code>Array</code> |  | Data to use for relations (node IDs). |
| [options.output] | <code>string</code> |  | Output format ("table" or graph). |
| [options.returnVisjsData] | <code>boolean</code> |  | Whether to return Vis.js data. |
| [options.filter] | <code>string</code> |  | SPARQL filter to apply. |
| [options.includeSources] | <code>string</code> |  | Sources to include. |
| [graphDiv] | <code>string</code> |  | The div element where to draw the graph. |

<a name="module_Lineage_relations.getInferredProperties"></a>

### Lineage_relations.getInferredProperties(source, callback, result) ⇒ <code>void</code>
Retrieves inferred properties from the ontology model.

**Kind**: static method of [<code>Lineage\_relations</code>](#module_Lineage_relations)  

| Param | Type | Description |
| --- | --- | --- |
| source | <code>string</code> | The source from which to get inferred properties. |
| callback | <code>function</code> | Callback function with signature (error, result). |
| result | <code>Object</code> | The jstree data structure containing inferred properties. |
| result.nodes | <code>Array</code> | Array of nodes representing properties and their constraints. |
| result.nodes[].data | <code>Object</code> | Node data containing property information. |
| result.nodes[].data.id | <code>string</code> | Property ID. |
| result.nodes[].data.label | <code>string</code> | Property label. |
| result.nodes[].data.constraints | <code>Object</code> | Property constraints with domain and range. |

<a name="module_Lineage_relations.onCheckNodePropertyTreeNode"></a>

### Lineage_relations.onCheckNodePropertyTreeNode(event, obj) ⇒ <code>void</code>
Handles the selection of a node in the properties tree.

**Kind**: static method of [<code>Lineage\_relations</code>](#module_Lineage_relations)  

| Param | Type | Description |
| --- | --- | --- |
| event | <code>Event</code> | The selection event. |
| obj | <code>Object</code> | The object containing node data. |
| obj.node | <code>Object</code> | The selected node. |
| obj.node.data | <code>Object</code> | Node data containing property information. |
| obj.node.data.constraints | <code>Object</code> | Property constraints. |
| obj.node.data.label | <code>string</code> | Property label. |

<a name="module_Lineage_relations.callPreviousQuery"></a>

### Lineage_relations.callPreviousQuery() ⇒ <code>void</code>
Recalls and executes the previous query.

**Kind**: static method of [<code>Lineage\_relations</code>](#module_Lineage_relations)  
<a name="module_Lineage_relations.loadUserQueries"></a>

### Lineage_relations.loadUserQueries() ⇒ <code>void</code>
Loads user-saved queries.

**Kind**: static method of [<code>Lineage\_relations</code>](#module_Lineage_relations)  
<a name="module_Lineage_relations.onSelectSavedQuery"></a>

### Lineage_relations.onSelectSavedQuery(id) ⇒ <code>void</code>
Handles the selection of a saved query.

**Kind**: static method of [<code>Lineage\_relations</code>](#module_Lineage_relations)  

| Param | Type | Description |
| --- | --- | --- |
| id | <code>string</code> | The ID of the saved query to load. |

<a name="module_Lineage_relations.saveCurrentQuery"></a>

### Lineage_relations.saveCurrentQuery() ⇒ <code>void</code>
Saves the current query configuration.

**Kind**: static method of [<code>Lineage\_relations</code>](#module_Lineage_relations)  
<a name="module_Lineage_relations.deleteSavedQuery"></a>

### Lineage_relations.deleteSavedQuery(id) ⇒ <code>void</code>
Deletes a saved query.

**Kind**: static method of [<code>Lineage\_relations</code>](#module_Lineage_relations)  

| Param | Type | Description |
| --- | --- | --- |
| id | <code>string</code> | The ID of the query to delete. |

<a name="module_Lineage_relations.drawEquivalentClasses"></a>

### Lineage_relations.drawEquivalentClasses(source, data, callback) ⇒ <code>void</code>
Draws equivalent classes in the graph.

**Kind**: static method of [<code>Lineage\_relations</code>](#module_Lineage_relations)  

| Param | Type | Description |
| --- | --- | --- |
| source | <code>string</code> | The source containing the equivalent classes. |
| data | <code>Array.&lt;string&gt;</code> | Array of class IDs to find equivalents for. |
| callback | <code>function</code> | Callback function with signature (error, result). |

<a name="module_Lineage_rules"></a>

## Lineage\_rules
Module for managing ontological rules and constraints.
Provides functionality for:
- Creating and managing ontology rules
- Handling premises and conclusions
- Supporting rule-based reasoning
- Managing rule components and relationships
- Supporting rule validation and execution
- Handling rule visualization and editing
- Managing rule-based constraints


* [Lineage_rules](#module_Lineage_rules)
    * [.showRulesDialog()](#module_Lineage_rules.showRulesDialog) ⇒ <code>void</code>
    * [.onSearchClassKeyDown(event)](#module_Lineage_rules.onSearchClassKeyDown) ⇒ <code>void</code>
    * [.onSearchPropertyKeyDown(event)](#module_Lineage_rules.onSearchPropertyKeyDown) ⇒ <code>void</code>
    * [.searchItem(term, type)](#module_Lineage_rules.searchItem) ⇒ <code>void</code>
    * [.getContextMenu()](#module_Lineage_rules.getContextMenu) ⇒ <code>Object</code>
    * [.selectTreeNodeFn(event, obj)](#module_Lineage_rules.selectTreeNodeFn) ⇒ <code>void</code>
    * [.addPremiseOrConclusion(node, role)](#module_Lineage_rules.addPremiseOrConclusion) ⇒ <code>void</code>
    * [.clearPremise(div)](#module_Lineage_rules.clearPremise) ⇒ <code>void</code>
    * [.getImplicitModel()](#module_Lineage_rules.getImplicitModel) ⇒ <code>void</code>
    * [.addPropertiesToTree(node)](#module_Lineage_rules.addPropertiesToTree) ⇒ <code>void</code>
    * [.execRule()](#module_Lineage_rules.execRule) ⇒ <code>void</code>

<a name="module_Lineage_rules.showRulesDialog"></a>

### Lineage_rules.showRulesDialog() ⇒ <code>void</code>
Displays the rules dialog.

**Kind**: static method of [<code>Lineage\_rules</code>](#module_Lineage_rules)  
<a name="module_Lineage_rules.onSearchClassKeyDown"></a>

### Lineage_rules.onSearchClassKeyDown(event) ⇒ <code>void</code>
Handles the class search event on key press.

**Kind**: static method of [<code>Lineage\_rules</code>](#module_Lineage_rules)  

| Param | Type | Description |
| --- | --- | --- |
| event | <code>Event</code> | The keyboard event. |

<a name="module_Lineage_rules.onSearchPropertyKeyDown"></a>

### Lineage_rules.onSearchPropertyKeyDown(event) ⇒ <code>void</code>
Handles the property search event on key press.

**Kind**: static method of [<code>Lineage\_rules</code>](#module_Lineage_rules)  

| Param | Type | Description |
| --- | --- | --- |
| event | <code>Event</code> | The keyboard event. |

<a name="module_Lineage_rules.searchItem"></a>

### Lineage_rules.searchItem(term, type) ⇒ <code>void</code>
Searches for items (classes or properties) in the ontology.

**Kind**: static method of [<code>Lineage\_rules</code>](#module_Lineage_rules)  

| Param | Type | Description |
| --- | --- | --- |
| term | <code>string</code> | The search term. |
| type | <code>string</code> | The type of item to search for ("Class" or "ObjectProperty"). |

<a name="module_Lineage_rules.getContextMenu"></a>

### Lineage_rules.getContextMenu() ⇒ <code>Object</code>
Returns the context menu for the rules tree.

**Kind**: static method of [<code>Lineage\_rules</code>](#module_Lineage_rules)  
**Returns**: <code>Object</code> - The context menu items.  
<a name="module_Lineage_rules.selectTreeNodeFn"></a>

### Lineage_rules.selectTreeNodeFn(event, obj) ⇒ <code>void</code>
Handles the selection of a node in the tree.

**Kind**: static method of [<code>Lineage\_rules</code>](#module_Lineage_rules)  

| Param | Type | Description |
| --- | --- | --- |
| event | <code>Event</code> | The selection event. |
| obj | <code>Object</code> | Object containing the selected node data. |

<a name="module_Lineage_rules.addPremiseOrConclusion"></a>

### Lineage_rules.addPremiseOrConclusion(node, role) ⇒ <code>void</code>
Adds a premise or conclusion to the rule.

**Kind**: static method of [<code>Lineage\_rules</code>](#module_Lineage_rules)  

| Param | Type | Description |
| --- | --- | --- |
| node | <code>Object</code> | The node to add. |
| role | <code>string</code> | The role of the node ("premise" or "conclusion"). |

<a name="module_Lineage_rules.clearPremise"></a>

### Lineage_rules.clearPremise(div) ⇒ <code>void</code>
Removes a premise from the rule.

**Kind**: static method of [<code>Lineage\_rules</code>](#module_Lineage_rules)  

| Param | Type | Description |
| --- | --- | --- |
| div | <code>string</code> | The ID of the div to remove. |

<a name="module_Lineage_rules.getImplicitModel"></a>

### Lineage_rules.getImplicitModel() ⇒ <code>void</code>
Retrieves the implicit model of the ontology.

**Kind**: static method of [<code>Lineage\_rules</code>](#module_Lineage_rules)  
<a name="module_Lineage_rules.addPropertiesToTree"></a>

### Lineage_rules.addPropertiesToTree(node) ⇒ <code>void</code>
Adds properties to the tree for a given node.

**Kind**: static method of [<code>Lineage\_rules</code>](#module_Lineage_rules)  

| Param | Type | Description |
| --- | --- | --- |
| node | <code>Object</code> | The node for which to add properties. |

<a name="module_Lineage_rules.execRule"></a>

### Lineage_rules.execRule() ⇒ <code>void</code>
Exécute la règle définie avec les prémisses et conclusions sélectionnées.

**Kind**: static method of [<code>Lineage\_rules</code>](#module_Lineage_rules)  
<a name="module_Lineage_selection"></a>

## Lineage\_selection
Module for managing node selection in the lineage graph.
Provides functionality for:
- Selecting and deselecting nodes
- Managing multiple node selections
- Visualizing selected nodes
- Supporting keyboard modifiers for selection
- Handling selection events and actions
- Managing selection trees and hierarchies
- Supporting selection-based operations


* [Lineage_selection](#module_Lineage_selection)
    * [.self.filterBy](#module_Lineage_selection.self.filterBy) : <code>object</code>
    * [.self.decorate](#module_Lineage_selection.self.decorate) : <code>object</code>
    * [.self.classDecorate](#module_Lineage_selection.self.classDecorate) : <code>object</code>
    * [.addNodeToSelection(node)](#module_Lineage_selection.addNodeToSelection) ⇒ <code>void</code>
    * [.clearNodesSelection([ids])](#module_Lineage_selection.clearNodesSelection) ⇒ <code>void</code>
    * [.getSelectedNodesTree()](#module_Lineage_selection.getSelectedNodesTree) ⇒ <code>Array.&lt;Object&gt;</code>
    * [.showSelectionDialog(allGraphNodes)](#module_Lineage_selection.showSelectionDialog) ⇒ <code>void</code>
    * [.selectNodesOnHover(node, point, options)](#module_Lineage_selection.selectNodesOnHover) ⇒ <code>void</code>
    * [.onSelectedNodeTreeclick(event, obj)](#module_Lineage_selection.onSelectedNodeTreeclick) ⇒ <code>void</code>
    * [.getSelectedNodes(onlyIds)](#module_Lineage_selection.getSelectedNodes) ⇒ <code>Array.&lt;(string\|Object)&gt;</code>
    * [.onSelectionExecuteAction(action, checkSelected)](#module_Lineage_selection.onSelectionExecuteAction) ⇒ <code>void</code>

<a name="module_Lineage_selection.self.filterBy"></a>

### Lineage_selection.self.filterBy : <code>object</code>
Filter operations for selected nodes.

**Kind**: static namespace of [<code>Lineage\_selection</code>](#module_Lineage_selection)  
<a name="module_Lineage_selection.self.decorate"></a>

### Lineage_selection.self.decorate : <code>object</code>
Decoration operations for selected nodes.

**Kind**: static namespace of [<code>Lineage\_selection</code>](#module_Lineage_selection)  
<a name="module_Lineage_selection.self.classDecorate"></a>

### Lineage_selection.self.classDecorate : <code>object</code>
Class decoration operations for selected nodes.

**Kind**: static namespace of [<code>Lineage\_selection</code>](#module_Lineage_selection)  
<a name="module_Lineage_selection.addNodeToSelection"></a>

### Lineage_selection.addNodeToSelection(node) ⇒ <code>void</code>
Adds a node to the current selection and updates its visual appearance.

**Kind**: static method of [<code>Lineage\_selection</code>](#module_Lineage_selection)  

| Param | Type | Description |
| --- | --- | --- |
| node | <code>Object</code> | The node to add to the selection. |
| node.data | <code>Object</code> | The node's data. |
| node.data.id | <code>string</code> | The node's unique identifier. |

<a name="module_Lineage_selection.clearNodesSelection"></a>

### Lineage_selection.clearNodesSelection([ids]) ⇒ <code>void</code>
Clears the selection for specified node IDs or all nodes if no IDs are provided.

**Kind**: static method of [<code>Lineage\_selection</code>](#module_Lineage_selection)  

| Param | Type | Description |
| --- | --- | --- |
| [ids] | <code>string</code> \| <code>Array.&lt;string&gt;</code> | Single ID or array of node IDs to clear from selection. |

<a name="module_Lineage_selection.getSelectedNodesTree"></a>

### Lineage_selection.getSelectedNodesTree() ⇒ <code>Array.&lt;Object&gt;</code>
Creates a jstree data structure from the currently selected nodes.

**Kind**: static method of [<code>Lineage\_selection</code>](#module_Lineage_selection)  
**Returns**: <code>Array.&lt;Object&gt;</code> - Array of jstree node objects.  
<a name="module_Lineage_selection.showSelectionDialog"></a>

### Lineage_selection.showSelectionDialog(allGraphNodes) ⇒ <code>void</code>
Shows the selection dialog with a tree view of selected nodes.

**Kind**: static method of [<code>Lineage\_selection</code>](#module_Lineage_selection)  

| Param | Type | Description |
| --- | --- | --- |
| allGraphNodes | <code>boolean</code> | If true, selects all nodes in the graph. |

<a name="module_Lineage_selection.selectNodesOnHover"></a>

### Lineage_selection.selectNodesOnHover(node, point, options) ⇒ <code>void</code>
Handles node selection on hover with keyboard modifiers.

**Kind**: static method of [<code>Lineage\_selection</code>](#module_Lineage_selection)  

| Param | Type | Description |
| --- | --- | --- |
| node | <code>Object</code> | The node being hovered. |
| point | <code>Object</code> | The point where the hover occurred. |
| options | <code>Object</code> | Keyboard modifier options. |
| options.ctrlKey | <code>boolean</code> | Whether the Ctrl key is pressed. |
| options.altKey | <code>boolean</code> | Whether the Alt key is pressed. |
| options.shiftKey | <code>boolean</code> | Whether the Shift key is pressed. |

<a name="module_Lineage_selection.onSelectedNodeTreeclick"></a>

### Lineage_selection.onSelectedNodeTreeclick(event, obj) ⇒ <code>void</code>
Handles click events on nodes in the selection tree.

**Kind**: static method of [<code>Lineage\_selection</code>](#module_Lineage_selection)  

| Param | Type | Description |
| --- | --- | --- |
| event | <code>Event</code> | The click event. |
| obj | <code>Object</code> | Object containing the clicked node data. |

<a name="module_Lineage_selection.getSelectedNodes"></a>

### Lineage_selection.getSelectedNodes(onlyIds) ⇒ <code>Array.&lt;(string\|Object)&gt;</code>
Gets the currently selected nodes from the selection tree.

**Kind**: static method of [<code>Lineage\_selection</code>](#module_Lineage_selection)  
**Returns**: <code>Array.&lt;(string\|Object)&gt;</code> - Array of node IDs or node objects.  

| Param | Type | Description |
| --- | --- | --- |
| onlyIds | <code>boolean</code> | If true, returns only node IDs instead of full node objects. |

<a name="module_Lineage_selection.onSelectionExecuteAction"></a>

### Lineage_selection.onSelectionExecuteAction(action, checkSelected) ⇒ <code>void</code>
Executes an action on the selected nodes.

**Kind**: static method of [<code>Lineage\_selection</code>](#module_Lineage_selection)  

| Param | Type | Description |
| --- | --- | --- |
| action | <code>string</code> | The action to execute ("filterBy", "decorate", "classDecorate", etc.). |
| checkSelected | <code>boolean</code> | Whether to check if nodes are selected before executing. |

<a name="module_Lineage_similars"></a>

## Lineage\_similars
Module for finding and visualizing similar nodes across different ontology sources.
Provides functionality for:
- Finding nodes with similar labels or properties
- Comparing nodes across different sources
- Visualizing similar nodes in the graph
- Supporting exact and fuzzy matching
- Managing source-specific similarity searches
- Handling node selection and comparison
- Supporting interactive similarity exploration


* [Lineage_similars](#module_Lineage_similars)
    * [.showDialog(selection)](#module_Lineage_similars.showDialog) ⇒ <code>void</code>
    * [.onChangeSelection(value)](#module_Lineage_similars.onChangeSelection) ⇒ <code>void</code>
    * [.showSourcesTree()](#module_Lineage_similars.showSourcesTree) ⇒ <code>void</code>
    * [.onSourceSelected(evt, obj)](#module_Lineage_similars.onSourceSelected) ⇒ <code>void</code>
    * [.onValidateSources()](#module_Lineage_similars.onValidateSources) ⇒ <code>void</code>
    * [.drawSimilars()](#module_Lineage_similars.drawSimilars) ⇒ <code>void</code>
    * [.drawSourceSimilars(fromFource, source)](#module_Lineage_similars.drawSourceSimilars) ⇒ <code>void</code>
    * [.getStartingNodes()](#module_Lineage_similars.getStartingNodes) ⇒ <code>Array.&lt;Object&gt;</code> \| <code>null</code>
    * [.drawWhiteBoardSimilars([selectedMode], [mode], [output])](#module_Lineage_similars.drawWhiteBoardSimilars) ⇒ <code>void</code>

<a name="module_Lineage_similars.showDialog"></a>

### Lineage_similars.showDialog(selection) ⇒ <code>void</code>
Shows the dialog for finding similar nodes.

**Kind**: static method of [<code>Lineage\_similars</code>](#module_Lineage_similars)  

| Param | Type | Description |
| --- | --- | --- |
| selection | <code>boolean</code> | Whether to use selected nodes as the source. |

<a name="module_Lineage_similars.onChangeSelection"></a>

### Lineage_similars.onChangeSelection(value) ⇒ <code>void</code>
Handles changes in the selection mode.

**Kind**: static method of [<code>Lineage\_similars</code>](#module_Lineage_similars)  

| Param | Type | Description |
| --- | --- | --- |
| value | <code>string</code> | The new selection value. |

<a name="module_Lineage_similars.showSourcesTree"></a>

### Lineage_similars.showSourcesTree() ⇒ <code>void</code>
Displays the tree of available sources for finding similar nodes.

**Kind**: static method of [<code>Lineage\_similars</code>](#module_Lineage_similars)  
<a name="module_Lineage_similars.onSourceSelected"></a>

### Lineage_similars.onSourceSelected(evt, obj) ⇒ <code>void</code>
Handles the selection of a source from the sources tree.

**Kind**: static method of [<code>Lineage\_similars</code>](#module_Lineage_similars)  

| Param | Type | Description |
| --- | --- | --- |
| evt | <code>Event</code> | The selection event. |
| obj | <code>Object</code> | Object containing the selected node data. |

<a name="module_Lineage_similars.onValidateSources"></a>

### Lineage_similars.onValidateSources() ⇒ <code>void</code>
Callback for source selection validation.

**Kind**: static method of [<code>Lineage\_similars</code>](#module_Lineage_similars)  
<a name="module_Lineage_similars.drawSimilars"></a>

### Lineage_similars.drawSimilars() ⇒ <code>void</code>
Initiates the drawing of similar nodes based on the current mode.

**Kind**: static method of [<code>Lineage\_similars</code>](#module_Lineage_similars)  
<a name="module_Lineage_similars.drawSourceSimilars"></a>

### Lineage_similars.drawSourceSimilars(fromFource, source) ⇒ <code>void</code>
Draws similar nodes from a specific source.

**Kind**: static method of [<code>Lineage\_similars</code>](#module_Lineage_similars)  

| Param | Type | Description |
| --- | --- | --- |
| fromFource | <code>string</code> | The starting source |
| source | <code>string</code> | The source to search for similar nodes. |

<a name="module_Lineage_similars.getStartingNodes"></a>

### Lineage_similars.getStartingNodes() ⇒ <code>Array.&lt;Object&gt;</code> \| <code>null</code>
Gets the nodes to use as starting points for similarity search.

**Kind**: static method of [<code>Lineage\_similars</code>](#module_Lineage_similars)  
**Returns**: <code>Array.&lt;Object&gt;</code> \| <code>null</code> - Array of starting nodes or null if none selected.  
<a name="module_Lineage_similars.drawWhiteBoardSimilars"></a>

### Lineage_similars.drawWhiteBoardSimilars([selectedMode], [mode], [output]) ⇒ <code>void</code>
Draws similar nodes found within the whiteboard.

**Kind**: static method of [<code>Lineage\_similars</code>](#module_Lineage_similars)  

| Param | Type | Description |
| --- | --- | --- |
| [selectedMode] | <code>string</code> | Optional selected mode. "AllWhiteboardNodes" or "SelectedNodes" |
| [mode] | <code>string</code> | Optional mode. "exactMatch" or "fuzzyMatch" |
| [output] | <code>string</code> | Optional output format. "graph" or "table" or "save" |

<a name="module_Lineage_sources"></a>

## Lineage\_sources
Module for managing ontology sources in the lineage system.
Provides functionality for:
- Loading and initializing ontology sources
- Managing source selection and activation
- Handling source-specific UI elements and themes
- Supporting source imports and dependencies
- Managing source metadata and configurations
- Coordinating source-related operations with other modules
- Supporting source validation and persistence


* [Lineage_sources](#module_Lineage_sources)
    * [.self.menuActions](#module_Lineage_sources.self.menuActions) : <code>object</code>
    * [.init(showDialog)](#module_Lineage_sources.init) ⇒ <code>void</code>
    * [.resetAll(showDialog)](#module_Lineage_sources.resetAll) ⇒ <code>void</code>
    * [.showSourcesDialog(forceDialog)](#module_Lineage_sources.showSourcesDialog) ⇒ <code>void</code>
    * [.loadSources(sources, [callback])](#module_Lineage_sources.loadSources) ⇒ <code>void</code>
    * [.setCurrentSource(source)](#module_Lineage_sources.setCurrentSource) ⇒ <code>void</code>
    * [.initSourcesSearchSelect()](#module_Lineage_sources.initSourcesSearchSelect) ⇒ <code>void</code>
    * [.showHideLineageLeftPanels()](#module_Lineage_sources.showHideLineageLeftPanels) ⇒ <code>void</code>
    * [.showHideEditButtons(source, [hide])](#module_Lineage_sources.showHideEditButtons) ⇒ <code>void</code>
    * [.whiteboard_setGraphOpacity(source)](#module_Lineage_sources.whiteboard_setGraphOpacity) ⇒ <code>void</code>
    * [.initSource(source, callback)](#module_Lineage_sources.initSource) ⇒ <code>void</code>
    * [.indexSourceIfNotIndexed(source)](#module_Lineage_sources.indexSourceIfNotIndexed) ⇒ <code>void</code>
    * [.registerSource(sourceLabel, [callback])](#module_Lineage_sources.registerSource) ⇒ <code>void</code>
    * [.showSourceDivPopupMenu(sourceDivId)](#module_Lineage_sources.showSourceDivPopupMenu) ⇒ <code>void</code>
    * [.registerSourceImports(sourceLabel, callback)](#module_Lineage_sources.registerSourceImports) ⇒ <code>void</code>
    * [.setAllWhiteBoardSources(remove)](#module_Lineage_sources.setAllWhiteBoardSources) ⇒ <code>void</code>
    * [.showHideCurrentSourceNodes(source, hide)](#module_Lineage_sources.showHideCurrentSourceNodes) ⇒ <code>void</code>
    * [.setTopLevelOntologyFromImports(sourceLabel)](#module_Lineage_sources.setTopLevelOntologyFromImports) ⇒ <code>string</code> \| <code>null</code>
    * [.setTopLevelOntologyFromPrefix(prefix)](#module_Lineage_sources.setTopLevelOntologyFromPrefix) ⇒ <code>string</code> \| <code>null</code>
    * [.isSourceOwnedByUser(sourceName)](#module_Lineage_sources.isSourceOwnedByUser) ⇒ <code>boolean</code>
    * [.isSourceEditableForUser(source)](#module_Lineage_sources.isSourceEditableForUser) ⇒ <code>boolean</code>
    * [.clearSource([source])](#module_Lineage_sources.clearSource) ⇒ <code>void</code>
    * [.setTheme(theme)](#module_Lineage_sources.setTheme) ⇒ <code>void</code>

<a name="module_Lineage_sources.self.menuActions"></a>

### Lineage_sources.self.menuActions : <code>object</code>
Collection of menu actions for source management.

**Kind**: static namespace of [<code>Lineage\_sources</code>](#module_Lineage_sources)  
<a name="module_Lineage_sources.init"></a>

### Lineage_sources.init(showDialog) ⇒ <code>void</code>
Initializes the lineage sources module, resetting the active source and UI elements.
Optionally displays the source selection dialog.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  

| Param | Type | Description |
| --- | --- | --- |
| showDialog | <code>boolean</code> | Whether to show the source selection dialog. |

<a name="module_Lineage_sources.resetAll"></a>

### Lineage_sources.resetAll(showDialog) ⇒ <code>void</code>
Resets all loaded sources and unregisters ontology models.
Calls the initialization function afterward.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  

| Param | Type | Description |
| --- | --- | --- |
| showDialog | <code>boolean</code> | Whether to show the source selection dialog. |

<a name="module_Lineage_sources.showSourcesDialog"></a>

### Lineage_sources.showSourcesDialog(forceDialog) ⇒ <code>void</code>
Displays the source selection dialog, allowing users to choose ontology sources.
If a source is provided via URL parameters, it is loaded directly.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  

| Param | Type | Description |
| --- | --- | --- |
| forceDialog | <code>boolean</code> | Whether to force the display of the selection dialog. |

<a name="module_Lineage_sources.loadSources"></a>

### Lineage_sources.loadSources(sources, [callback]) ⇒ <code>void</code>
Loads the specified sources asynchronously, initializing each if not already loaded.
After loading, sets the first source as the current active source.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  

| Param | Type | Description |
| --- | --- | --- |
| sources | <code>string</code> \| <code>Array.&lt;string&gt;</code> | The source(s) to be loaded. |
| [callback] | <code>function</code> | Optional callback function executed after loading. |

<a name="module_Lineage_sources.setCurrentSource"></a>

### Lineage_sources.setCurrentSource(source) ⇒ <code>void</code>
Sets the specified source as the current active source.
Updates the UI accordingly, initializes the whiteboard, and loads source-specific elements.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  

| Param | Type | Description |
| --- | --- | --- |
| source | <code>string</code> | The source to be set as active. |

<a name="module_Lineage_sources.initSourcesSearchSelect"></a>

### Lineage_sources.initSourcesSearchSelect() ⇒ <code>void</code>
Initializes the source search selection based on the user's selected search scope.
Updates available class options for searching within the selected source.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  
<a name="module_Lineage_sources.showHideLineageLeftPanels"></a>

### Lineage_sources.showHideLineageLeftPanels() ⇒ <code>void</code>
Shows or hides the left panels in the lineage UI based on the current ontology configuration.
Adjusts the display of the legend wrapper section accordingly.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  
<a name="module_Lineage_sources.showHideEditButtons"></a>

### Lineage_sources.showHideEditButtons(source, [hide]) ⇒ <code>void</code>
Shows or hides edit buttons based on the source's editability.
Disables edit mode for the graph and updates the UI accordingly.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  

| Param | Type | Description |
| --- | --- | --- |
| source | <code>string</code> | The source to check for editability. |
| [hide] | <code>boolean</code> | Optional flag to force hiding the buttons. |

<a name="module_Lineage_sources.whiteboard_setGraphOpacity"></a>

### Lineage_sources.whiteboard\_setGraphOpacity(source) ⇒ <code>void</code>
Adjusts the opacity of nodes and edges in the whiteboard graph based on the active source.
Nodes and edges belonging to the active source remain fully visible, while others become transparent.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  

| Param | Type | Description |
| --- | --- | --- |
| source | <code>string</code> | The currently active source. |

<a name="module_Lineage_sources.initSource"></a>

### Lineage_sources.initSource(source, callback) ⇒ <code>void</code>
Initializes a given source by registering it and setting up ontology imports.
Optionally draws top-level concepts if needed.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  

| Param | Type | Description |
| --- | --- | --- |
| source | <code>string</code> | The source to initialize. |
| callback | <code>function</code> | Callback function executed after initialization. |

<a name="module_Lineage_sources.indexSourceIfNotIndexed"></a>

### Lineage_sources.indexSourceIfNotIndexed(source) ⇒ <code>void</code>
Checks if a source is indexed in ElasticSearch. If not, it triggers the indexing process.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  

| Param | Type | Description |
| --- | --- | --- |
| source | <code>string</code> | The source to check and index if necessary. |

<a name="module_Lineage_sources.registerSource"></a>

### Lineage_sources.registerSource(sourceLabel, [callback]) ⇒ <code>void</code>
Registers a source, ensuring it is loaded and displayed in the UI.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  

| Param | Type | Description |
| --- | --- | --- |
| sourceLabel | <code>string</code> | The label of the source to register. |
| [callback] | <code>function</code> | Optional callback function to execute after registration. |

<a name="module_Lineage_sources.showSourceDivPopupMenu"></a>

### Lineage_sources.showSourceDivPopupMenu(sourceDivId) ⇒ <code>void</code>
Displays a contextual popup menu for a source, allowing various actions such as hiding, grouping, or editing.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  

| Param | Type | Description |
| --- | --- | --- |
| sourceDivId | <code>string</code> | The ID of the source's div element. |

<a name="module_Lineage_sources.registerSourceImports"></a>

### Lineage_sources.registerSourceImports(sourceLabel, callback) ⇒ <code>void</code>
Registers all imported sources of a given source.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  

| Param | Type | Description |
| --- | --- | --- |
| sourceLabel | <code>string</code> | The label of the source whose imports should be registered. |
| callback | <code>function</code> | Callback function executed after all imports are registered. |

<a name="module_Lineage_sources.setAllWhiteBoardSources"></a>

### Lineage_sources.setAllWhiteBoardSources(remove) ⇒ <code>void</code>
Toggles the selection of all whiteboard sources, affecting UI highlighting and opacity settings.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  

| Param | Type | Description |
| --- | --- | --- |
| remove | <code>boolean</code> | If true, sets a flag to remove sources from the whiteboard. |

<a name="module_Lineage_sources.showHideCurrentSourceNodes"></a>

### Lineage_sources.showHideCurrentSourceNodes(source, hide) ⇒ <code>void</code>
Toggles the visibility of nodes belonging to a given source in the lineage graph.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  

| Param | Type | Description |
| --- | --- | --- |
| source | <code>string</code> | The source whose nodes should be shown or hidden. |
| hide | <code>boolean</code> | Whether to hide (true) or show (false) the nodes. |

<a name="module_Lineage_sources.setTopLevelOntologyFromImports"></a>

### Lineage_sources.setTopLevelOntologyFromImports(sourceLabel) ⇒ <code>string</code> \| <code>null</code>
Sets the current top-level ontology based on a source's imports.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  
**Returns**: <code>string</code> \| <code>null</code> - The selected top-level ontology or null if none found.  

| Param | Type | Description |
| --- | --- | --- |
| sourceLabel | <code>string</code> | The source label to check for imports. |

<a name="module_Lineage_sources.setTopLevelOntologyFromPrefix"></a>

### Lineage_sources.setTopLevelOntologyFromPrefix(prefix) ⇒ <code>string</code> \| <code>null</code>
Sets the current top-level ontology based on a prefix.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  
**Returns**: <code>string</code> \| <code>null</code> - The selected top-level ontology or null if none found.  

| Param | Type | Description |
| --- | --- | --- |
| prefix | <code>string</code> | The prefix to search for in top-level ontologies. |

<a name="module_Lineage_sources.isSourceOwnedByUser"></a>

### Lineage_sources.isSourceOwnedByUser(sourceName) ⇒ <code>boolean</code>
Checks if a source is owned by the current user.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  
**Returns**: <code>boolean</code> - True if the source is owned by the current user, false otherwise.  

| Param | Type | Description |
| --- | --- | --- |
| sourceName | <code>string</code> | The name of the source to check. |

<a name="module_Lineage_sources.isSourceEditableForUser"></a>

### Lineage_sources.isSourceEditableForUser(source) ⇒ <code>boolean</code>
Checks if a source is editable by the current user based on access control settings.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  
**Returns**: <code>boolean</code> - True if the source is editable by the current user, false otherwise.  

| Param | Type | Description |
| --- | --- | --- |
| source | <code>string</code> | The source to check. |

<a name="module_Lineage_sources.clearSource"></a>

### Lineage_sources.clearSource([source]) ⇒ <code>void</code>
Clears all nodes belonging to a source from the graph.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  

| Param | Type | Description |
| --- | --- | --- |
| [source] | <code>string</code> | The source to clear. If not provided, uses the active source. |

<a name="module_Lineage_sources.setTheme"></a>

### Lineage_sources.setTheme(theme) ⇒ <code>void</code>
Sets the theme for the lineage graph, affecting background and text colors.

**Kind**: static method of [<code>Lineage\_sources</code>](#module_Lineage_sources)  

| Param | Type | Description |
| --- | --- | --- |
| theme | <code>string</code> | The theme to apply ("white" or other). |

<a name="module_Lineage_whiteboard"></a>

## Lineage\_whiteboard

* [Lineage_whiteboard](#module_Lineage_whiteboard)
    * [.drawTopConcepts(source, [options], graphDiv, callback)](#module_Lineage_whiteboard.drawTopConcepts) ⇒ <code>void</code>
    * [.isResultAcceptable(result)](#module_Lineage_whiteboard.isResultAcceptable) ⇒ <code>boolean</code>
    * [.initWhiteBoard(force)](#module_Lineage_whiteboard.initWhiteBoard) ⇒ <code>void</code>
    * [.drawNewGraph(visjsData, graphDiv, [_options])](#module_Lineage_whiteboard.drawNewGraph) ⇒ <code>void</code>
    * [.drawDictionarySameAs()](#module_Lineage_whiteboard.drawDictionarySameAs) ⇒ <code>void</code>
    * [.drawNamedLinkedData([classIds])](#module_Lineage_whiteboard.drawNamedLinkedData) ⇒ <code>void</code>
    * [.collapseNode(nodeId)](#module_Lineage_whiteboard.collapseNode) ⇒ <code>void</code>
    * [.setGraphPopupMenus(node, event)](#module_Lineage_whiteboard.setGraphPopupMenus) ⇒ <code>void</code>

<a name="module_Lineage_whiteboard.drawTopConcepts"></a>

### Lineage_whiteboard.drawTopConcepts(source, [options], graphDiv, callback) ⇒ <code>void</code>
Retrieves and displays the top-level concepts for a given ontology source.
It ensures that concepts are properly linked to their respective sources and adds them to the graph.

**Kind**: static method of [<code>Lineage\_whiteboard</code>](#module_Lineage_whiteboard)  

| Param | Type | Default | Description |
| --- | --- | --- | --- |
| source | <code>string</code> |  | The ontology source to retrieve top concepts from. |
| [options] | <code>Object</code> | <code>{}</code> | Configuration options for fetching and displaying concepts. |
| graphDiv | <code>string</code> |  | The ID of the div container where the graph will be drawn. |
| callback | <code>function</code> |  | Callback function executed after fetching top concepts. |

<a name="module_Lineage_whiteboard.isResultAcceptable"></a>

### Lineage_whiteboard.isResultAcceptable(result) ⇒ <code>boolean</code>
Checks if the result set is acceptable based on predefined constraints.
If too many nodes are present, an alert is shown, and false is returned.
If no data is found, a message is displayed.

**Kind**: static method of [<code>Lineage\_whiteboard</code>](#module_Lineage_whiteboard)  
**Returns**: <code>boolean</code> - - Returns true if the result is acceptable, otherwise false.  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Array</code> | The result array to be evaluated. |

<a name="module_Lineage_whiteboard.initWhiteBoard"></a>

### Lineage_whiteboard.initWhiteBoard(force) ⇒ <code>void</code>
Initializes the whiteboard by clearing or redrawing the graph if necessary.
If the graph is empty or the force parameter is set to true, a new empty graph is drawn.

**Kind**: static method of [<code>Lineage\_whiteboard</code>](#module_Lineage_whiteboard)  

| Param | Type | Description |
| --- | --- | --- |
| force | <code>boolean</code> | If true, forces the graph to reset even if it's not empty. |

<a name="module_Lineage_whiteboard.drawNewGraph"></a>

### Lineage_whiteboard.drawNewGraph(visjsData, graphDiv, [_options]) ⇒ <code>void</code>
Draws a new graph with provided data and options. Configures visualization settings
such as physics, layout, and interaction settings. Also manages node and edge interactions.

**Kind**: static method of [<code>Lineage\_whiteboard</code>](#module_Lineage_whiteboard)  

| Param | Type | Default | Description |
| --- | --- | --- | --- |
| visjsData | <code>Object</code> |  | The data containing nodes and edges to be displayed. |
| graphDiv | <code>string</code> |  | The ID of the div container where the graph will be rendered. |
| [_options] | <code>Object</code> | <code>{}</code> | Optional configuration settings for the graph. |
| [_options.visjsOptions] | <code>Object</code> |  | Custom options for the Vis.js graph. |
| [_options.layoutHierarchical] | <code>boolean</code> |  | If true, enables hierarchical layout. |
| [_options.physics] | <code>Object</code> |  | Custom physics settings for the graph. |
| [_options.noDecorations] | <code>boolean</code> |  | If true, skips the decoration step after drawing. |
| [_options.legendType] | <code>string</code> |  | Type of legend to be used for decoration. |

<a name="module_Lineage_whiteboard.drawDictionarySameAs"></a>

### Lineage_whiteboard.drawDictionarySameAs() ⇒ <code>void</code>
Draws the sameAs restrictions for the dictionary.
This function fetches and visualizes the sameAs properties for the dictionary source,
displaying the relationships in a graph format.

**Kind**: static method of [<code>Lineage\_whiteboard</code>](#module_Lineage_whiteboard)  
<a name="module_Lineage_whiteboard.drawNamedLinkedData"></a>

### Lineage_whiteboard.drawNamedLinkedData([classIds]) ⇒ <code>void</code>
Draws linked data for named classes.
This function fetches named linked data from a source based on the provided class IDs,
and visualizes the results in the graph, adding new nodes and edges as necessary.

**Kind**: static method of [<code>Lineage\_whiteboard</code>](#module_Lineage_whiteboard)  

| Param | Type | Description |
| --- | --- | --- |
| [classIds] | <code>Array.&lt;any&gt;</code> | The list of class IDs to filter the linked data by. If not provided, it will be retrieved from the active source. |

<a name="module_Lineage_whiteboard.collapseNode"></a>

### Lineage_whiteboard.collapseNode(nodeId) ⇒ <code>void</code>
Collapses a node and removes its connected children from the graph.
This function collapses the specified node and removes any connected nodes in the "from" direction.

**Kind**: static method of [<code>Lineage\_whiteboard</code>](#module_Lineage_whiteboard)  

| Param | Type | Description |
| --- | --- | --- |
| nodeId | <code>any</code> | The ID of the node to collapse. |

<a name="module_Lineage_whiteboard.setGraphPopupMenus"></a>

### Lineage_whiteboard.setGraphPopupMenus(node, event) ⇒ <code>void</code>
Sets the context menu for a graph node based on the node's type and context.
This function generates a dynamic context menu for the clicked node with options such as
opening clusters, showing property information, or removing nodes from the graph.

**Kind**: static method of [<code>Lineage\_whiteboard</code>](#module_Lineage_whiteboard)  

| Param | Type | Description |
| --- | --- | --- |
| node | <code>Object</code> | The node that was clicked on in the graph. |
| event | <code>Event</code> | The event triggered by the click, used to set the context menu options. |

<a name="module_KGquery"></a>

## KGquery
KGquery Module
Module for querying and visualizing knowledge graphs.
Provides functionality to build and execute queries on knowledge graphs.


* [KGquery](#module_KGquery)
    * [.unload()](#module_KGquery.unload) ⇒ <code>void</code>
    * [.init()](#module_KGquery.init) ⇒ <code>void</code>
    * [.initOutputType()](#module_KGquery.initOutputType) ⇒ <code>void</code>
    * [.loadSource()](#module_KGquery.loadSource) ⇒ <code>void</code>
    * [.addQuerySet(booleanOperator)](#module_KGquery.addQuerySet) ⇒ <code>Object</code>
    * [.addQueryElementToQuerySet(querySet)](#module_KGquery.addQueryElementToQuerySet) ⇒ <code>Object</code>
    * [.addNodeToQueryElement(queryElement, node, role)](#module_KGquery.addNodeToQueryElement) ⇒ <code>void</code>
    * [.addNode(selectedNode, nodeEvent, [callback])](#module_KGquery.addNode) ⇒ <code>void</code>
    * [.addEdgeNodes(fromNode, toNode, edge)](#module_KGquery.addEdgeNodes) ⇒ <code>void</code>
    * [.addEdge(edge, evt)](#module_KGquery.addEdge) ⇒ <code>void</code>
    * [.aggregateQuery()](#module_KGquery.aggregateQuery) ⇒ <code>void</code>
    * [.queryKG(output, [options], [isVirtualSQLquery])](#module_KGquery.queryKG) ⇒ <code>void</code>
    * [.execPathQuery(options, callback)](#module_KGquery.execPathQuery) ⇒ <code>void</code>
    * [.queryResultToVisjsGraph(result)](#module_KGquery.queryResultToVisjsGraph) ⇒ <code>void</code>
    * [.queryToTagsGeometry(result)](#module_KGquery.queryToTagsGeometry) ⇒ <code>void</code>
    * [.queryToTagsCalendar(result)](#module_KGquery.queryToTagsCalendar) ⇒ <code>void</code>
    * [.queryResultToTable(result)](#module_KGquery.queryResultToTable) ⇒ <code>void</code>
    * [.clearAll([exceptSetQueries])](#module_KGquery.clearAll) ⇒ <code>void</code>
    * [.getVarName(node, [withoutQuestionMark])](#module_KGquery.getVarName) ⇒ <code>string</code>
    * [.getAllQueryPathClasses()](#module_KGquery.getAllQueryPathClasses) ⇒ <code>Array.&lt;Object&gt;</code>
    * [.message(message, [stopWaitImg])](#module_KGquery.message) ⇒ <code>void</code>
    * [.switchRightPanel([forceGraph])](#module_KGquery.switchRightPanel) ⇒ <code>void</code>
    * [.onBooleanOperatorChange(querySetDivId, value)](#module_KGquery.onBooleanOperatorChange) ⇒ <code>void</code>
    * [.removeQueryElement(queryElementDivId)](#module_KGquery.removeQueryElement) ⇒ <code>void</code>
    * [.removeSet(querySetDivId)](#module_KGquery.removeSet) ⇒ <code>void</code>
    * [.onOutputTypeSelect(output)](#module_KGquery.onOutputTypeSelect) ⇒ <code>void</code>
    * [.addOutputType()](#module_KGquery.addOutputType) ⇒ <code>void</code>
    * [.initQuery()](#module_KGquery.initQuery) ⇒ <code>void</code>
    * [.initGraph()](#module_KGquery.initGraph) ⇒ <code>void</code>
    * [.checkRequirements()](#module_KGquery.checkRequirements) ⇒ <code>void</code>
    * [.initMyQuery()](#module_KGquery.initMyQuery) ⇒ <code>void</code>
    * [.unload()](#module_KGquery.unload) ⇒ <code>void</code>
    * [.init()](#module_KGquery.init) ⇒ <code>void</code>
    * [.initOutputType()](#module_KGquery.initOutputType) ⇒ <code>void</code>
    * [.loadSource()](#module_KGquery.loadSource) ⇒ <code>void</code>
    * [.addQuerySet(booleanOperator)](#module_KGquery.addQuerySet) ⇒ <code>Object</code>
    * [.addQueryElementToQuerySet(querySet)](#module_KGquery.addQueryElementToQuerySet) ⇒ <code>Object</code>
    * [.addNodeToQueryElement(queryElement, node, role)](#module_KGquery.addNodeToQueryElement) ⇒ <code>void</code>
    * [.addNode(selectedNode, nodeEvent, [callback])](#module_KGquery.addNode) ⇒ <code>void</code>
    * [.addEdgeNodes(fromNode, toNode, edge)](#module_KGquery.addEdgeNodes) ⇒ <code>void</code>
    * [.addEdge(edge, evt)](#module_KGquery.addEdge) ⇒ <code>void</code>
    * [.aggregateQuery()](#module_KGquery.aggregateQuery) ⇒ <code>void</code>
    * [.queryKG(output, [options], [isVirtualSQLquery])](#module_KGquery.queryKG) ⇒ <code>void</code>
    * [.execPathQuery(options, callback)](#module_KGquery.execPathQuery) ⇒ <code>void</code>
    * [.queryResultToVisjsGraph(result)](#module_KGquery.queryResultToVisjsGraph) ⇒ <code>void</code>
    * [.queryToTagsGeometry(result)](#module_KGquery.queryToTagsGeometry) ⇒ <code>void</code>
    * [.queryToTagsCalendar(result)](#module_KGquery.queryToTagsCalendar) ⇒ <code>void</code>
    * [.queryResultToTable(result)](#module_KGquery.queryResultToTable) ⇒ <code>void</code>
    * [.clearAll([exceptSetQueries])](#module_KGquery.clearAll) ⇒ <code>void</code>
    * [.getVarName(node, [withoutQuestionMark])](#module_KGquery.getVarName) ⇒ <code>string</code>
    * [.getAllQueryPathClasses()](#module_KGquery.getAllQueryPathClasses) ⇒ <code>Array.&lt;Object&gt;</code>
    * [.message(message, [stopWaitImg])](#module_KGquery.message) ⇒ <code>void</code>
    * [.switchRightPanel([forceGraph])](#module_KGquery.switchRightPanel) ⇒ <code>void</code>
    * [.onBooleanOperatorChange(querySetDivId, value)](#module_KGquery.onBooleanOperatorChange) ⇒ <code>void</code>
    * [.removeQueryElement(queryElementDivId)](#module_KGquery.removeQueryElement) ⇒ <code>void</code>
    * [.removeSet(querySetDivId)](#module_KGquery.removeSet) ⇒ <code>void</code>
    * [.onOutputTypeSelect(output)](#module_KGquery.onOutputTypeSelect) ⇒ <code>void</code>
    * [.addOutputType()](#module_KGquery.addOutputType) ⇒ <code>void</code>
    * [.initQuery()](#module_KGquery.initQuery) ⇒ <code>void</code>
    * [.initGraph()](#module_KGquery.initGraph) ⇒ <code>void</code>
    * [.checkRequirements()](#module_KGquery.checkRequirements) ⇒ <code>void</code>
    * [.initMyQuery()](#module_KGquery.initMyQuery) ⇒ <code>void</code>
    * _KGquery_
        * [.onLoaded()](#module_KGquery.onLoaded) ⇒ <code>void</code>
        * [.onLoaded()](#module_KGquery.onLoaded) ⇒ <code>void</code>

<a name="module_KGquery.unload"></a>

### KGquery.unload() ⇒ <code>void</code>
Unloads the module and restores initial state.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.init"></a>

### KGquery.init() ⇒ <code>void</code>
Initializes the module.
Draws the graph model and sets up saved queries.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.initOutputType"></a>

### KGquery.initOutputType() ⇒ <code>void</code>
Initializes the output type selector with available tools.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.loadSource"></a>

### KGquery.loadSource() ⇒ <code>void</code>
Loads a source and initializes the graph visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.addQuerySet"></a>

### KGquery.addQuerySet(booleanOperator) ⇒ <code>Object</code>
Adds a new query set with a boolean operator.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Returns**: <code>Object</code> - querySet - The newly created query set  

| Param | Type | Description |
| --- | --- | --- |
| booleanOperator | <code>string</code> | The boolean operator to use (AND, OR, etc.) |

**Properties**

| Name | Type | Description |
| --- | --- | --- |
| querySet.divId | <code>string</code> | The ID of the div containing the query set |
| querySet.elements | <code>Array</code> | Array of query elements in this set |
| querySet.color | <code>string</code> | The color assigned to this query set |
| querySet.booleanOperator | <code>string</code> | The boolean operator for this set |
| querySet.classFiltersMap | <code>Object</code> | Map of class filters |
| querySet.index | <code>number</code> | Index of this query set |

<a name="module_KGquery.addQueryElementToQuerySet"></a>

### KGquery.addQueryElementToQuerySet(querySet) ⇒ <code>Object</code>
Adds a query element to a query set.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Returns**: <code>Object</code> - queryElement - The newly created query element  

| Param | Type | Description |
| --- | --- | --- |
| querySet | <code>Object</code> | The query set to add the element to |

**Properties**

| Name | Type | Description |
| --- | --- | --- |
| queryElement.divId | <code>string</code> | The ID of the div containing this element |
| queryElement.fromNode | <code>string</code> | The source node |
| queryElement.toNode | <code>string</code> | The target node |
| queryElement.paths | <code>Array</code> | Array of paths between fromNode and toNode |
| queryElement.queryElementDivId | <code>string</code> | The element's div ID |
| queryElement.fromNodeDivId | <code>string</code> | The source node's div ID |
| queryElement.toNodeDivId | <code>string</code> | The target node's div ID |
| queryElement.index | <code>number</code> | Index within the query set |
| queryElement.setIndex | <code>number</code> | Index of the parent query set |

<a name="module_KGquery.addNodeToQueryElement"></a>

### KGquery.addNodeToQueryElement(queryElement, node, role) ⇒ <code>void</code>
Adds a node to a query element.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| queryElement | <code>Object</code> | The query element to add the node to |
| node | <code>Object</code> | The node to add |
| role | <code>string</code> | The role of the node ('fromNode' or 'toNode') |

<a name="module_KGquery.addNode"></a>

### KGquery.addNode(selectedNode, nodeEvent, [callback]) ⇒ <code>void</code>
Adds a node to the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| selectedNode | <code>Object</code> | The node to add |
| nodeEvent | <code>Object</code> | The event that triggered the addition |
| [callback] | <code>function</code> | Optional callback after adding |

<a name="module_KGquery.addEdgeNodes"></a>

### KGquery.addEdgeNodes(fromNode, toNode, edge) ⇒ <code>void</code>
Adds edge nodes to the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| fromNode | <code>Object</code> | The source node |
| toNode | <code>Object</code> | The target node |
| edge | <code>Object</code> | The edge data |

<a name="module_KGquery.addEdge"></a>

### KGquery.addEdge(edge, evt) ⇒ <code>void</code>
Adds edges between nodes in the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| edge | <code>Object</code> | The edge to add |
| evt | <code>Object</code> | The event that triggered the addition |

<a name="module_KGquery.aggregateQuery"></a>

### KGquery.aggregateQuery() ⇒ <code>void</code>
Performs aggregation on query results.
Shows a dialog for selecting aggregate clauses and validates that variables belong to the same set.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.queryKG"></a>

### KGquery.queryKG(output, [options], [isVirtualSQLquery]) ⇒ <code>void</code>
Executes a query on the knowledge graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Throws**:

- <code>Error</code> If the query execution fails


| Param | Type | Default | Description |
| --- | --- | --- | --- |
| output | <code>string</code> |  | The desired output format ('table', 'Graph', 'shacl', or custom tool name) |
| [options] | <code>Object</code> |  | Additional query options |
| [options.aggregate] | <code>Object</code> |  | Aggregation settings for the query |
| [isVirtualSQLquery] | <code>boolean</code> | <code>false</code> | Whether this is a virtual SQL query |

<a name="module_KGquery.execPathQuery"></a>

### KGquery.execPathQuery(options, callback) ⇒ <code>void</code>
Executes a SPARQL path query based on the provided options.
The query is constructed dynamically and executed in multiple steps.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| options | <code>Object</code> | The options for query execution |
| options.output | <code>string</code> | The desired output format (e.g., "shacl") |
| callback | <code>function</code> | Callback function to handle the query results |
| callback.err | <code>Error</code> | Error object if the query fails |
| callback.result | <code>Object</code> | The query results if successful |

<a name="module_KGquery.queryResultToVisjsGraph"></a>

### KGquery.queryResultToVisjsGraph(result) ⇒ <code>void</code>
Converts query results to a Vis.js graph visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Throws**:

- <code>Error</code> If result size exceeds maxResultSizeforLineageViz


| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | The query results to convert |

<a name="module_KGquery.queryToTagsGeometry"></a>

### KGquery.queryToTagsGeometry(result) ⇒ <code>void</code>
Converts query results to a tags geometry visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | The query results to convert |

<a name="module_KGquery.queryToTagsCalendar"></a>

### KGquery.queryToTagsCalendar(result) ⇒ <code>void</code>
Converts query results to a tags calendar visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | The query results to convert |

<a name="module_KGquery.queryResultToTable"></a>

### KGquery.queryResultToTable(result) ⇒ <code>void</code>
Converts query results to a table format and displays it in a dialog.
Handles large result sets by exporting to CSV if size exceeds 10000 rows.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | The query results to convert |
| result.results.bindings | <code>Array</code> | The query result bindings |
| result.head.vars | <code>Array</code> | The query result variables |

<a name="module_KGquery.clearAll"></a>

### KGquery.clearAll([exceptSetQueries]) ⇒ <code>void</code>
Clears all query sets and resets the graph state.
Optionally preserves set queries if specified.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| [exceptSetQueries] | <code>boolean</code> | If true, preserves set queries during cleanup |

<a name="module_KGquery.getVarName"></a>

### KGquery.getVarName(node, [withoutQuestionMark]) ⇒ <code>string</code>
Gets the variable name for a node.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Returns**: <code>string</code> - The variable name for the node  

| Param | Type | Description |
| --- | --- | --- |
| node | <code>Object</code> | The node to get variable name for |
| [withoutQuestionMark] | <code>boolean</code> | Whether to omit the question mark prefix |

<a name="module_KGquery.getAllQueryPathClasses"></a>

### KGquery.getAllQueryPathClasses() ⇒ <code>Array.&lt;Object&gt;</code>
Gets all classes used in query paths.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Returns**: <code>Array.&lt;Object&gt;</code> - Array of class objects used in query paths  
<a name="module_KGquery.message"></a>

### KGquery.message(message, [stopWaitImg]) ⇒ <code>void</code>
Displays a message in the UI and controls the wait image.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Default | Description |
| --- | --- | --- | --- |
| message | <code>string</code> |  | The message to display |
| [stopWaitImg] | <code>boolean</code> | <code>false</code> | If true, hides the wait image |

<a name="module_KGquery.switchRightPanel"></a>

### KGquery.switchRightPanel([forceGraph]) ⇒ <code>void</code>
Switches the right panel display between graph and other views.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| [forceGraph] | <code>boolean</code> | Whether to force graph display |

<a name="module_KGquery.onBooleanOperatorChange"></a>

### KGquery.onBooleanOperatorChange(querySetDivId, value) ⇒ <code>void</code>
Handles boolean operator changes for query sets.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| querySetDivId | <code>string</code> | ID of the query set div |
| value | <code>string</code> | New boolean operator value ('AND', 'OR', 'Union', etc.) |

<a name="module_KGquery.removeQueryElement"></a>

### KGquery.removeQueryElement(queryElementDivId) ⇒ <code>void</code>
Removes a query element from the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| queryElementDivId | <code>string</code> | ID of the query element div to remove |

<a name="module_KGquery.removeSet"></a>

### KGquery.removeSet(querySetDivId) ⇒ <code>void</code>
Removes a query set from the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| querySetDivId | <code>string</code> | ID of the query set div to remove |

<a name="module_KGquery.onOutputTypeSelect"></a>

### KGquery.onOutputTypeSelect(output) ⇒ <code>void</code>
Handles output type selection changes.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| output | <code>string</code> | The selected output type |

<a name="module_KGquery.addOutputType"></a>

### KGquery.addOutputType() ⇒ <code>void</code>
Adds an output type to the select options.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.initQuery"></a>

### KGquery.initQuery() ⇒ <code>void</code>
Initializes the query interface.
Loads the query tab HTML if not already loaded.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.initGraph"></a>

### KGquery.initGraph() ⇒ <code>void</code>
Initializes the graph interface.
Loads the graph tab HTML if not already loaded and initializes the graph visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.checkRequirements"></a>

### KGquery.checkRequirements() ⇒ <code>void</code>
Checks requirements by executing a SHACL query.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.initMyQuery"></a>

### KGquery.initMyQuery() ⇒ <code>void</code>
Initializes the query management interface.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.unload"></a>

### KGquery.unload() ⇒ <code>void</code>
Unloads the module and restores initial state.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.init"></a>

### KGquery.init() ⇒ <code>void</code>
Initializes the module.
Draws the graph model and sets up saved queries.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.initOutputType"></a>

### KGquery.initOutputType() ⇒ <code>void</code>
Initializes the output type selector with available tools.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.loadSource"></a>

### KGquery.loadSource() ⇒ <code>void</code>
Loads a source and initializes the graph visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.addQuerySet"></a>

### KGquery.addQuerySet(booleanOperator) ⇒ <code>Object</code>
Adds a new query set with a boolean operator.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Returns**: <code>Object</code> - querySet - The newly created query set  

| Param | Type | Description |
| --- | --- | --- |
| booleanOperator | <code>string</code> | The boolean operator to use (AND, OR, etc.) |

**Properties**

| Name | Type | Description |
| --- | --- | --- |
| querySet.divId | <code>string</code> | The ID of the div containing the query set |
| querySet.elements | <code>Array</code> | Array of query elements in this set |
| querySet.color | <code>string</code> | The color assigned to this query set |
| querySet.booleanOperator | <code>string</code> | The boolean operator for this set |
| querySet.classFiltersMap | <code>Object</code> | Map of class filters |
| querySet.index | <code>number</code> | Index of this query set |

<a name="module_KGquery.addQueryElementToQuerySet"></a>

### KGquery.addQueryElementToQuerySet(querySet) ⇒ <code>Object</code>
Adds a query element to a query set.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Returns**: <code>Object</code> - queryElement - The newly created query element  

| Param | Type | Description |
| --- | --- | --- |
| querySet | <code>Object</code> | The query set to add the element to |

**Properties**

| Name | Type | Description |
| --- | --- | --- |
| queryElement.divId | <code>string</code> | The ID of the div containing this element |
| queryElement.fromNode | <code>string</code> | The source node |
| queryElement.toNode | <code>string</code> | The target node |
| queryElement.paths | <code>Array</code> | Array of paths between fromNode and toNode |
| queryElement.queryElementDivId | <code>string</code> | The element's div ID |
| queryElement.fromNodeDivId | <code>string</code> | The source node's div ID |
| queryElement.toNodeDivId | <code>string</code> | The target node's div ID |
| queryElement.index | <code>number</code> | Index within the query set |
| queryElement.setIndex | <code>number</code> | Index of the parent query set |

<a name="module_KGquery.addNodeToQueryElement"></a>

### KGquery.addNodeToQueryElement(queryElement, node, role) ⇒ <code>void</code>
Adds a node to a query element.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| queryElement | <code>Object</code> | The query element to add the node to |
| node | <code>Object</code> | The node to add |
| role | <code>string</code> | The role of the node ('fromNode' or 'toNode') |

<a name="module_KGquery.addNode"></a>

### KGquery.addNode(selectedNode, nodeEvent, [callback]) ⇒ <code>void</code>
Adds a node to the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| selectedNode | <code>Object</code> | The node to add |
| nodeEvent | <code>Object</code> | The event that triggered the addition |
| [callback] | <code>function</code> | Optional callback after adding |

<a name="module_KGquery.addEdgeNodes"></a>

### KGquery.addEdgeNodes(fromNode, toNode, edge) ⇒ <code>void</code>
Adds edge nodes to the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| fromNode | <code>Object</code> | The source node |
| toNode | <code>Object</code> | The target node |
| edge | <code>Object</code> | The edge data |

<a name="module_KGquery.addEdge"></a>

### KGquery.addEdge(edge, evt) ⇒ <code>void</code>
Adds edges between nodes in the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| edge | <code>Object</code> | The edge to add |
| evt | <code>Object</code> | The event that triggered the addition |

<a name="module_KGquery.aggregateQuery"></a>

### KGquery.aggregateQuery() ⇒ <code>void</code>
Performs aggregation on query results.
Shows a dialog for selecting aggregate clauses and validates that variables belong to the same set.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.queryKG"></a>

### KGquery.queryKG(output, [options], [isVirtualSQLquery]) ⇒ <code>void</code>
Executes a query on the knowledge graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Throws**:

- <code>Error</code> If the query execution fails


| Param | Type | Default | Description |
| --- | --- | --- | --- |
| output | <code>string</code> |  | The desired output format ('table', 'Graph', 'shacl', or custom tool name) |
| [options] | <code>Object</code> |  | Additional query options |
| [options.aggregate] | <code>Object</code> |  | Aggregation settings for the query |
| [isVirtualSQLquery] | <code>boolean</code> | <code>false</code> | Whether this is a virtual SQL query |

<a name="module_KGquery.execPathQuery"></a>

### KGquery.execPathQuery(options, callback) ⇒ <code>void</code>
Executes a SPARQL path query based on the provided options.
The query is constructed dynamically and executed in multiple steps.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| options | <code>Object</code> | The options for query execution |
| options.output | <code>string</code> | The desired output format (e.g., "shacl") |
| [options.aggregate] | <code>Object</code> | Aggregation settings for the query |
| callback | <code>function</code> | Callback function to handle the query results |
| callback.err | <code>Error</code> | Error object if the query fails |
| callback.result | <code>Object</code> | The query results if successful |

<a name="module_KGquery.queryResultToVisjsGraph"></a>

### KGquery.queryResultToVisjsGraph(result) ⇒ <code>void</code>
Converts query results to a Vis.js graph visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Throws**:

- <code>Error</code> If result size exceeds maxResultSizeforLineageViz


| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | The query results to convert |

<a name="module_KGquery.queryToTagsGeometry"></a>

### KGquery.queryToTagsGeometry(result) ⇒ <code>void</code>
Converts query results to a tags geometry visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | The query results to convert |

<a name="module_KGquery.queryToTagsCalendar"></a>

### KGquery.queryToTagsCalendar(result) ⇒ <code>void</code>
Converts query results to a tags calendar visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | The query results to convert |

<a name="module_KGquery.queryResultToTable"></a>

### KGquery.queryResultToTable(result) ⇒ <code>void</code>
Converts query results to a table format and displays it in a dialog.
Handles large result sets by exporting to CSV if size exceeds 10000 rows.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | The query results to convert |
| result.results.bindings | <code>Array</code> | The query result bindings |
| result.head.vars | <code>Array</code> | The query result variables |

<a name="module_KGquery.clearAll"></a>

### KGquery.clearAll([exceptSetQueries]) ⇒ <code>void</code>
Clears all query sets and resets the graph state.
Optionally preserves set queries if specified.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| [exceptSetQueries] | <code>boolean</code> | If true, preserves set queries during cleanup |

<a name="module_KGquery.getVarName"></a>

### KGquery.getVarName(node, [withoutQuestionMark]) ⇒ <code>string</code>
Gets the variable name for a node.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Returns**: <code>string</code> - The variable name for the node  

| Param | Type | Description |
| --- | --- | --- |
| node | <code>Object</code> | The node to get variable name for |
| [withoutQuestionMark] | <code>boolean</code> | Whether to omit the question mark prefix |

<a name="module_KGquery.getAllQueryPathClasses"></a>

### KGquery.getAllQueryPathClasses() ⇒ <code>Array.&lt;Object&gt;</code>
Gets all classes used in query paths.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Returns**: <code>Array.&lt;Object&gt;</code> - Array of class objects used in query paths  
<a name="module_KGquery.message"></a>

### KGquery.message(message, [stopWaitImg]) ⇒ <code>void</code>
Displays a message in the UI and controls the wait image.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Default | Description |
| --- | --- | --- | --- |
| message | <code>string</code> |  | The message to display |
| [stopWaitImg] | <code>boolean</code> | <code>false</code> | If true, hides the wait image |

<a name="module_KGquery.switchRightPanel"></a>

### KGquery.switchRightPanel([forceGraph]) ⇒ <code>void</code>
Switches the right panel display between graph and other views.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| [forceGraph] | <code>boolean</code> | Whether to force graph display |

<a name="module_KGquery.onBooleanOperatorChange"></a>

### KGquery.onBooleanOperatorChange(querySetDivId, value) ⇒ <code>void</code>
Handles boolean operator changes for query sets.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| querySetDivId | <code>string</code> | ID of the query set div |
| value | <code>string</code> | New boolean operator value ('AND', 'OR', 'Union', etc.) |

<a name="module_KGquery.removeQueryElement"></a>

### KGquery.removeQueryElement(queryElementDivId) ⇒ <code>void</code>
Removes a query element from the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| queryElementDivId | <code>string</code> | ID of the query element div to remove |

<a name="module_KGquery.removeSet"></a>

### KGquery.removeSet(querySetDivId) ⇒ <code>void</code>
Removes a query set from the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| querySetDivId | <code>string</code> | ID of the query set div to remove |

<a name="module_KGquery.onOutputTypeSelect"></a>

### KGquery.onOutputTypeSelect(output) ⇒ <code>void</code>
Handles output type selection changes.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| output | <code>string</code> | The selected output type |

<a name="module_KGquery.addOutputType"></a>

### KGquery.addOutputType() ⇒ <code>void</code>
Adds an output type to the select options.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.initQuery"></a>

### KGquery.initQuery() ⇒ <code>void</code>
Initializes the query interface.
Loads the query tab HTML if not already loaded.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.initGraph"></a>

### KGquery.initGraph() ⇒ <code>void</code>
Initializes the graph interface.
Loads the graph tab HTML if not already loaded and initializes the graph visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.checkRequirements"></a>

### KGquery.checkRequirements() ⇒ <code>void</code>
Checks requirements by executing a SHACL query.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.initMyQuery"></a>

### KGquery.initMyQuery() ⇒ <code>void</code>
Initializes the query management interface.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.onLoaded"></a>

### KGquery.onLoaded() ⇒ <code>void</code>
Called when the module is loaded.
Initializes the user interface and loads saved queries.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Category**: KGquery  
**Access**: public  
<a name="module_KGquery.onLoaded"></a>

### KGquery.onLoaded() ⇒ <code>void</code>
Called when the module is loaded.
Initializes the user interface and loads saved queries.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Category**: KGquery  
**Access**: public  
<a name="module_KGquery"></a>

## KGquery
KGquery Module
Module for querying and visualizing knowledge graphs.
Provides functionality to build and execute queries on knowledge graphs.


* [KGquery](#module_KGquery)
    * [.unload()](#module_KGquery.unload) ⇒ <code>void</code>
    * [.init()](#module_KGquery.init) ⇒ <code>void</code>
    * [.initOutputType()](#module_KGquery.initOutputType) ⇒ <code>void</code>
    * [.loadSource()](#module_KGquery.loadSource) ⇒ <code>void</code>
    * [.addQuerySet(booleanOperator)](#module_KGquery.addQuerySet) ⇒ <code>Object</code>
    * [.addQueryElementToQuerySet(querySet)](#module_KGquery.addQueryElementToQuerySet) ⇒ <code>Object</code>
    * [.addNodeToQueryElement(queryElement, node, role)](#module_KGquery.addNodeToQueryElement) ⇒ <code>void</code>
    * [.addNode(selectedNode, nodeEvent, [callback])](#module_KGquery.addNode) ⇒ <code>void</code>
    * [.addEdgeNodes(fromNode, toNode, edge)](#module_KGquery.addEdgeNodes) ⇒ <code>void</code>
    * [.addEdge(edge, evt)](#module_KGquery.addEdge) ⇒ <code>void</code>
    * [.aggregateQuery()](#module_KGquery.aggregateQuery) ⇒ <code>void</code>
    * [.queryKG(output, [options], [isVirtualSQLquery])](#module_KGquery.queryKG) ⇒ <code>void</code>
    * [.execPathQuery(options, callback)](#module_KGquery.execPathQuery) ⇒ <code>void</code>
    * [.queryResultToVisjsGraph(result)](#module_KGquery.queryResultToVisjsGraph) ⇒ <code>void</code>
    * [.queryToTagsGeometry(result)](#module_KGquery.queryToTagsGeometry) ⇒ <code>void</code>
    * [.queryToTagsCalendar(result)](#module_KGquery.queryToTagsCalendar) ⇒ <code>void</code>
    * [.queryResultToTable(result)](#module_KGquery.queryResultToTable) ⇒ <code>void</code>
    * [.clearAll([exceptSetQueries])](#module_KGquery.clearAll) ⇒ <code>void</code>
    * [.getVarName(node, [withoutQuestionMark])](#module_KGquery.getVarName) ⇒ <code>string</code>
    * [.getAllQueryPathClasses()](#module_KGquery.getAllQueryPathClasses) ⇒ <code>Array.&lt;Object&gt;</code>
    * [.message(message, [stopWaitImg])](#module_KGquery.message) ⇒ <code>void</code>
    * [.switchRightPanel([forceGraph])](#module_KGquery.switchRightPanel) ⇒ <code>void</code>
    * [.onBooleanOperatorChange(querySetDivId, value)](#module_KGquery.onBooleanOperatorChange) ⇒ <code>void</code>
    * [.removeQueryElement(queryElementDivId)](#module_KGquery.removeQueryElement) ⇒ <code>void</code>
    * [.removeSet(querySetDivId)](#module_KGquery.removeSet) ⇒ <code>void</code>
    * [.onOutputTypeSelect(output)](#module_KGquery.onOutputTypeSelect) ⇒ <code>void</code>
    * [.addOutputType()](#module_KGquery.addOutputType) ⇒ <code>void</code>
    * [.initQuery()](#module_KGquery.initQuery) ⇒ <code>void</code>
    * [.initGraph()](#module_KGquery.initGraph) ⇒ <code>void</code>
    * [.checkRequirements()](#module_KGquery.checkRequirements) ⇒ <code>void</code>
    * [.initMyQuery()](#module_KGquery.initMyQuery) ⇒ <code>void</code>
    * [.unload()](#module_KGquery.unload) ⇒ <code>void</code>
    * [.init()](#module_KGquery.init) ⇒ <code>void</code>
    * [.initOutputType()](#module_KGquery.initOutputType) ⇒ <code>void</code>
    * [.loadSource()](#module_KGquery.loadSource) ⇒ <code>void</code>
    * [.addQuerySet(booleanOperator)](#module_KGquery.addQuerySet) ⇒ <code>Object</code>
    * [.addQueryElementToQuerySet(querySet)](#module_KGquery.addQueryElementToQuerySet) ⇒ <code>Object</code>
    * [.addNodeToQueryElement(queryElement, node, role)](#module_KGquery.addNodeToQueryElement) ⇒ <code>void</code>
    * [.addNode(selectedNode, nodeEvent, [callback])](#module_KGquery.addNode) ⇒ <code>void</code>
    * [.addEdgeNodes(fromNode, toNode, edge)](#module_KGquery.addEdgeNodes) ⇒ <code>void</code>
    * [.addEdge(edge, evt)](#module_KGquery.addEdge) ⇒ <code>void</code>
    * [.aggregateQuery()](#module_KGquery.aggregateQuery) ⇒ <code>void</code>
    * [.queryKG(output, [options], [isVirtualSQLquery])](#module_KGquery.queryKG) ⇒ <code>void</code>
    * [.execPathQuery(options, callback)](#module_KGquery.execPathQuery) ⇒ <code>void</code>
    * [.queryResultToVisjsGraph(result)](#module_KGquery.queryResultToVisjsGraph) ⇒ <code>void</code>
    * [.queryToTagsGeometry(result)](#module_KGquery.queryToTagsGeometry) ⇒ <code>void</code>
    * [.queryToTagsCalendar(result)](#module_KGquery.queryToTagsCalendar) ⇒ <code>void</code>
    * [.queryResultToTable(result)](#module_KGquery.queryResultToTable) ⇒ <code>void</code>
    * [.clearAll([exceptSetQueries])](#module_KGquery.clearAll) ⇒ <code>void</code>
    * [.getVarName(node, [withoutQuestionMark])](#module_KGquery.getVarName) ⇒ <code>string</code>
    * [.getAllQueryPathClasses()](#module_KGquery.getAllQueryPathClasses) ⇒ <code>Array.&lt;Object&gt;</code>
    * [.message(message, [stopWaitImg])](#module_KGquery.message) ⇒ <code>void</code>
    * [.switchRightPanel([forceGraph])](#module_KGquery.switchRightPanel) ⇒ <code>void</code>
    * [.onBooleanOperatorChange(querySetDivId, value)](#module_KGquery.onBooleanOperatorChange) ⇒ <code>void</code>
    * [.removeQueryElement(queryElementDivId)](#module_KGquery.removeQueryElement) ⇒ <code>void</code>
    * [.removeSet(querySetDivId)](#module_KGquery.removeSet) ⇒ <code>void</code>
    * [.onOutputTypeSelect(output)](#module_KGquery.onOutputTypeSelect) ⇒ <code>void</code>
    * [.addOutputType()](#module_KGquery.addOutputType) ⇒ <code>void</code>
    * [.initQuery()](#module_KGquery.initQuery) ⇒ <code>void</code>
    * [.initGraph()](#module_KGquery.initGraph) ⇒ <code>void</code>
    * [.checkRequirements()](#module_KGquery.checkRequirements) ⇒ <code>void</code>
    * [.initMyQuery()](#module_KGquery.initMyQuery) ⇒ <code>void</code>
    * _KGquery_
        * [.onLoaded()](#module_KGquery.onLoaded) ⇒ <code>void</code>
        * [.onLoaded()](#module_KGquery.onLoaded) ⇒ <code>void</code>

<a name="module_KGquery.unload"></a>

### KGquery.unload() ⇒ <code>void</code>
Unloads the module and restores initial state.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.init"></a>

### KGquery.init() ⇒ <code>void</code>
Initializes the module.
Draws the graph model and sets up saved queries.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.initOutputType"></a>

### KGquery.initOutputType() ⇒ <code>void</code>
Initializes the output type selector with available tools.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.loadSource"></a>

### KGquery.loadSource() ⇒ <code>void</code>
Loads a source and initializes the graph visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.addQuerySet"></a>

### KGquery.addQuerySet(booleanOperator) ⇒ <code>Object</code>
Adds a new query set with a boolean operator.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Returns**: <code>Object</code> - querySet - The newly created query set  

| Param | Type | Description |
| --- | --- | --- |
| booleanOperator | <code>string</code> | The boolean operator to use (AND, OR, etc.) |

**Properties**

| Name | Type | Description |
| --- | --- | --- |
| querySet.divId | <code>string</code> | The ID of the div containing the query set |
| querySet.elements | <code>Array</code> | Array of query elements in this set |
| querySet.color | <code>string</code> | The color assigned to this query set |
| querySet.booleanOperator | <code>string</code> | The boolean operator for this set |
| querySet.classFiltersMap | <code>Object</code> | Map of class filters |
| querySet.index | <code>number</code> | Index of this query set |

<a name="module_KGquery.addQueryElementToQuerySet"></a>

### KGquery.addQueryElementToQuerySet(querySet) ⇒ <code>Object</code>
Adds a query element to a query set.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Returns**: <code>Object</code> - queryElement - The newly created query element  

| Param | Type | Description |
| --- | --- | --- |
| querySet | <code>Object</code> | The query set to add the element to |

**Properties**

| Name | Type | Description |
| --- | --- | --- |
| queryElement.divId | <code>string</code> | The ID of the div containing this element |
| queryElement.fromNode | <code>string</code> | The source node |
| queryElement.toNode | <code>string</code> | The target node |
| queryElement.paths | <code>Array</code> | Array of paths between fromNode and toNode |
| queryElement.queryElementDivId | <code>string</code> | The element's div ID |
| queryElement.fromNodeDivId | <code>string</code> | The source node's div ID |
| queryElement.toNodeDivId | <code>string</code> | The target node's div ID |
| queryElement.index | <code>number</code> | Index within the query set |
| queryElement.setIndex | <code>number</code> | Index of the parent query set |

<a name="module_KGquery.addNodeToQueryElement"></a>

### KGquery.addNodeToQueryElement(queryElement, node, role) ⇒ <code>void</code>
Adds a node to a query element.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| queryElement | <code>Object</code> | The query element to add the node to |
| node | <code>Object</code> | The node to add |
| role | <code>string</code> | The role of the node ('fromNode' or 'toNode') |

<a name="module_KGquery.addNode"></a>

### KGquery.addNode(selectedNode, nodeEvent, [callback]) ⇒ <code>void</code>
Adds a node to the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| selectedNode | <code>Object</code> | The node to add |
| nodeEvent | <code>Object</code> | The event that triggered the addition |
| [callback] | <code>function</code> | Optional callback after adding |

<a name="module_KGquery.addEdgeNodes"></a>

### KGquery.addEdgeNodes(fromNode, toNode, edge) ⇒ <code>void</code>
Adds edge nodes to the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| fromNode | <code>Object</code> | The source node |
| toNode | <code>Object</code> | The target node |
| edge | <code>Object</code> | The edge data |

<a name="module_KGquery.addEdge"></a>

### KGquery.addEdge(edge, evt) ⇒ <code>void</code>
Adds edges between nodes in the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| edge | <code>Object</code> | The edge to add |
| evt | <code>Object</code> | The event that triggered the addition |

<a name="module_KGquery.aggregateQuery"></a>

### KGquery.aggregateQuery() ⇒ <code>void</code>
Performs aggregation on query results.
Shows a dialog for selecting aggregate clauses and validates that variables belong to the same set.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.queryKG"></a>

### KGquery.queryKG(output, [options], [isVirtualSQLquery]) ⇒ <code>void</code>
Executes a query on the knowledge graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Throws**:

- <code>Error</code> If the query execution fails


| Param | Type | Default | Description |
| --- | --- | --- | --- |
| output | <code>string</code> |  | The desired output format ('table', 'Graph', 'shacl', or custom tool name) |
| [options] | <code>Object</code> |  | Additional query options |
| [options.aggregate] | <code>Object</code> |  | Aggregation settings for the query |
| [isVirtualSQLquery] | <code>boolean</code> | <code>false</code> | Whether this is a virtual SQL query |

<a name="module_KGquery.execPathQuery"></a>

### KGquery.execPathQuery(options, callback) ⇒ <code>void</code>
Executes a SPARQL path query based on the provided options.
The query is constructed dynamically and executed in multiple steps.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| options | <code>Object</code> | The options for query execution |
| options.output | <code>string</code> | The desired output format (e.g., "shacl") |
| callback | <code>function</code> | Callback function to handle the query results |
| callback.err | <code>Error</code> | Error object if the query fails |
| callback.result | <code>Object</code> | The query results if successful |

<a name="module_KGquery.queryResultToVisjsGraph"></a>

### KGquery.queryResultToVisjsGraph(result) ⇒ <code>void</code>
Converts query results to a Vis.js graph visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Throws**:

- <code>Error</code> If result size exceeds maxResultSizeforLineageViz


| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | The query results to convert |

<a name="module_KGquery.queryToTagsGeometry"></a>

### KGquery.queryToTagsGeometry(result) ⇒ <code>void</code>
Converts query results to a tags geometry visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | The query results to convert |

<a name="module_KGquery.queryToTagsCalendar"></a>

### KGquery.queryToTagsCalendar(result) ⇒ <code>void</code>
Converts query results to a tags calendar visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | The query results to convert |

<a name="module_KGquery.queryResultToTable"></a>

### KGquery.queryResultToTable(result) ⇒ <code>void</code>
Converts query results to a table format and displays it in a dialog.
Handles large result sets by exporting to CSV if size exceeds 10000 rows.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | The query results to convert |
| result.results.bindings | <code>Array</code> | The query result bindings |
| result.head.vars | <code>Array</code> | The query result variables |

<a name="module_KGquery.clearAll"></a>

### KGquery.clearAll([exceptSetQueries]) ⇒ <code>void</code>
Clears all query sets and resets the graph state.
Optionally preserves set queries if specified.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| [exceptSetQueries] | <code>boolean</code> | If true, preserves set queries during cleanup |

<a name="module_KGquery.getVarName"></a>

### KGquery.getVarName(node, [withoutQuestionMark]) ⇒ <code>string</code>
Gets the variable name for a node.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Returns**: <code>string</code> - The variable name for the node  

| Param | Type | Description |
| --- | --- | --- |
| node | <code>Object</code> | The node to get variable name for |
| [withoutQuestionMark] | <code>boolean</code> | Whether to omit the question mark prefix |

<a name="module_KGquery.getAllQueryPathClasses"></a>

### KGquery.getAllQueryPathClasses() ⇒ <code>Array.&lt;Object&gt;</code>
Gets all classes used in query paths.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Returns**: <code>Array.&lt;Object&gt;</code> - Array of class objects used in query paths  
<a name="module_KGquery.message"></a>

### KGquery.message(message, [stopWaitImg]) ⇒ <code>void</code>
Displays a message in the UI and controls the wait image.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Default | Description |
| --- | --- | --- | --- |
| message | <code>string</code> |  | The message to display |
| [stopWaitImg] | <code>boolean</code> | <code>false</code> | If true, hides the wait image |

<a name="module_KGquery.switchRightPanel"></a>

### KGquery.switchRightPanel([forceGraph]) ⇒ <code>void</code>
Switches the right panel display between graph and other views.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| [forceGraph] | <code>boolean</code> | Whether to force graph display |

<a name="module_KGquery.onBooleanOperatorChange"></a>

### KGquery.onBooleanOperatorChange(querySetDivId, value) ⇒ <code>void</code>
Handles boolean operator changes for query sets.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| querySetDivId | <code>string</code> | ID of the query set div |
| value | <code>string</code> | New boolean operator value ('AND', 'OR', 'Union', etc.) |

<a name="module_KGquery.removeQueryElement"></a>

### KGquery.removeQueryElement(queryElementDivId) ⇒ <code>void</code>
Removes a query element from the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| queryElementDivId | <code>string</code> | ID of the query element div to remove |

<a name="module_KGquery.removeSet"></a>

### KGquery.removeSet(querySetDivId) ⇒ <code>void</code>
Removes a query set from the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| querySetDivId | <code>string</code> | ID of the query set div to remove |

<a name="module_KGquery.onOutputTypeSelect"></a>

### KGquery.onOutputTypeSelect(output) ⇒ <code>void</code>
Handles output type selection changes.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| output | <code>string</code> | The selected output type |

<a name="module_KGquery.addOutputType"></a>

### KGquery.addOutputType() ⇒ <code>void</code>
Adds an output type to the select options.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.initQuery"></a>

### KGquery.initQuery() ⇒ <code>void</code>
Initializes the query interface.
Loads the query tab HTML if not already loaded.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.initGraph"></a>

### KGquery.initGraph() ⇒ <code>void</code>
Initializes the graph interface.
Loads the graph tab HTML if not already loaded and initializes the graph visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.checkRequirements"></a>

### KGquery.checkRequirements() ⇒ <code>void</code>
Checks requirements by executing a SHACL query.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.initMyQuery"></a>

### KGquery.initMyQuery() ⇒ <code>void</code>
Initializes the query management interface.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.unload"></a>

### KGquery.unload() ⇒ <code>void</code>
Unloads the module and restores initial state.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.init"></a>

### KGquery.init() ⇒ <code>void</code>
Initializes the module.
Draws the graph model and sets up saved queries.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.initOutputType"></a>

### KGquery.initOutputType() ⇒ <code>void</code>
Initializes the output type selector with available tools.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.loadSource"></a>

### KGquery.loadSource() ⇒ <code>void</code>
Loads a source and initializes the graph visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.addQuerySet"></a>

### KGquery.addQuerySet(booleanOperator) ⇒ <code>Object</code>
Adds a new query set with a boolean operator.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Returns**: <code>Object</code> - querySet - The newly created query set  

| Param | Type | Description |
| --- | --- | --- |
| booleanOperator | <code>string</code> | The boolean operator to use (AND, OR, etc.) |

**Properties**

| Name | Type | Description |
| --- | --- | --- |
| querySet.divId | <code>string</code> | The ID of the div containing the query set |
| querySet.elements | <code>Array</code> | Array of query elements in this set |
| querySet.color | <code>string</code> | The color assigned to this query set |
| querySet.booleanOperator | <code>string</code> | The boolean operator for this set |
| querySet.classFiltersMap | <code>Object</code> | Map of class filters |
| querySet.index | <code>number</code> | Index of this query set |

<a name="module_KGquery.addQueryElementToQuerySet"></a>

### KGquery.addQueryElementToQuerySet(querySet) ⇒ <code>Object</code>
Adds a query element to a query set.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Returns**: <code>Object</code> - queryElement - The newly created query element  

| Param | Type | Description |
| --- | --- | --- |
| querySet | <code>Object</code> | The query set to add the element to |

**Properties**

| Name | Type | Description |
| --- | --- | --- |
| queryElement.divId | <code>string</code> | The ID of the div containing this element |
| queryElement.fromNode | <code>string</code> | The source node |
| queryElement.toNode | <code>string</code> | The target node |
| queryElement.paths | <code>Array</code> | Array of paths between fromNode and toNode |
| queryElement.queryElementDivId | <code>string</code> | The element's div ID |
| queryElement.fromNodeDivId | <code>string</code> | The source node's div ID |
| queryElement.toNodeDivId | <code>string</code> | The target node's div ID |
| queryElement.index | <code>number</code> | Index within the query set |
| queryElement.setIndex | <code>number</code> | Index of the parent query set |

<a name="module_KGquery.addNodeToQueryElement"></a>

### KGquery.addNodeToQueryElement(queryElement, node, role) ⇒ <code>void</code>
Adds a node to a query element.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| queryElement | <code>Object</code> | The query element to add the node to |
| node | <code>Object</code> | The node to add |
| role | <code>string</code> | The role of the node ('fromNode' or 'toNode') |

<a name="module_KGquery.addNode"></a>

### KGquery.addNode(selectedNode, nodeEvent, [callback]) ⇒ <code>void</code>
Adds a node to the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| selectedNode | <code>Object</code> | The node to add |
| nodeEvent | <code>Object</code> | The event that triggered the addition |
| [callback] | <code>function</code> | Optional callback after adding |

<a name="module_KGquery.addEdgeNodes"></a>

### KGquery.addEdgeNodes(fromNode, toNode, edge) ⇒ <code>void</code>
Adds edge nodes to the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| fromNode | <code>Object</code> | The source node |
| toNode | <code>Object</code> | The target node |
| edge | <code>Object</code> | The edge data |

<a name="module_KGquery.addEdge"></a>

### KGquery.addEdge(edge, evt) ⇒ <code>void</code>
Adds edges between nodes in the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| edge | <code>Object</code> | The edge to add |
| evt | <code>Object</code> | The event that triggered the addition |

<a name="module_KGquery.aggregateQuery"></a>

### KGquery.aggregateQuery() ⇒ <code>void</code>
Performs aggregation on query results.
Shows a dialog for selecting aggregate clauses and validates that variables belong to the same set.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.queryKG"></a>

### KGquery.queryKG(output, [options], [isVirtualSQLquery]) ⇒ <code>void</code>
Executes a query on the knowledge graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Throws**:

- <code>Error</code> If the query execution fails


| Param | Type | Default | Description |
| --- | --- | --- | --- |
| output | <code>string</code> |  | The desired output format ('table', 'Graph', 'shacl', or custom tool name) |
| [options] | <code>Object</code> |  | Additional query options |
| [options.aggregate] | <code>Object</code> |  | Aggregation settings for the query |
| [isVirtualSQLquery] | <code>boolean</code> | <code>false</code> | Whether this is a virtual SQL query |

<a name="module_KGquery.execPathQuery"></a>

### KGquery.execPathQuery(options, callback) ⇒ <code>void</code>
Executes a SPARQL path query based on the provided options.
The query is constructed dynamically and executed in multiple steps.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| options | <code>Object</code> | The options for query execution |
| options.output | <code>string</code> | The desired output format (e.g., "shacl") |
| [options.aggregate] | <code>Object</code> | Aggregation settings for the query |
| callback | <code>function</code> | Callback function to handle the query results |
| callback.err | <code>Error</code> | Error object if the query fails |
| callback.result | <code>Object</code> | The query results if successful |

<a name="module_KGquery.queryResultToVisjsGraph"></a>

### KGquery.queryResultToVisjsGraph(result) ⇒ <code>void</code>
Converts query results to a Vis.js graph visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Throws**:

- <code>Error</code> If result size exceeds maxResultSizeforLineageViz


| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | The query results to convert |

<a name="module_KGquery.queryToTagsGeometry"></a>

### KGquery.queryToTagsGeometry(result) ⇒ <code>void</code>
Converts query results to a tags geometry visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | The query results to convert |

<a name="module_KGquery.queryToTagsCalendar"></a>

### KGquery.queryToTagsCalendar(result) ⇒ <code>void</code>
Converts query results to a tags calendar visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | The query results to convert |

<a name="module_KGquery.queryResultToTable"></a>

### KGquery.queryResultToTable(result) ⇒ <code>void</code>
Converts query results to a table format and displays it in a dialog.
Handles large result sets by exporting to CSV if size exceeds 10000 rows.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | The query results to convert |
| result.results.bindings | <code>Array</code> | The query result bindings |
| result.head.vars | <code>Array</code> | The query result variables |

<a name="module_KGquery.clearAll"></a>

### KGquery.clearAll([exceptSetQueries]) ⇒ <code>void</code>
Clears all query sets and resets the graph state.
Optionally preserves set queries if specified.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| [exceptSetQueries] | <code>boolean</code> | If true, preserves set queries during cleanup |

<a name="module_KGquery.getVarName"></a>

### KGquery.getVarName(node, [withoutQuestionMark]) ⇒ <code>string</code>
Gets the variable name for a node.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Returns**: <code>string</code> - The variable name for the node  

| Param | Type | Description |
| --- | --- | --- |
| node | <code>Object</code> | The node to get variable name for |
| [withoutQuestionMark] | <code>boolean</code> | Whether to omit the question mark prefix |

<a name="module_KGquery.getAllQueryPathClasses"></a>

### KGquery.getAllQueryPathClasses() ⇒ <code>Array.&lt;Object&gt;</code>
Gets all classes used in query paths.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Returns**: <code>Array.&lt;Object&gt;</code> - Array of class objects used in query paths  
<a name="module_KGquery.message"></a>

### KGquery.message(message, [stopWaitImg]) ⇒ <code>void</code>
Displays a message in the UI and controls the wait image.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Default | Description |
| --- | --- | --- | --- |
| message | <code>string</code> |  | The message to display |
| [stopWaitImg] | <code>boolean</code> | <code>false</code> | If true, hides the wait image |

<a name="module_KGquery.switchRightPanel"></a>

### KGquery.switchRightPanel([forceGraph]) ⇒ <code>void</code>
Switches the right panel display between graph and other views.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| [forceGraph] | <code>boolean</code> | Whether to force graph display |

<a name="module_KGquery.onBooleanOperatorChange"></a>

### KGquery.onBooleanOperatorChange(querySetDivId, value) ⇒ <code>void</code>
Handles boolean operator changes for query sets.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| querySetDivId | <code>string</code> | ID of the query set div |
| value | <code>string</code> | New boolean operator value ('AND', 'OR', 'Union', etc.) |

<a name="module_KGquery.removeQueryElement"></a>

### KGquery.removeQueryElement(queryElementDivId) ⇒ <code>void</code>
Removes a query element from the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| queryElementDivId | <code>string</code> | ID of the query element div to remove |

<a name="module_KGquery.removeSet"></a>

### KGquery.removeSet(querySetDivId) ⇒ <code>void</code>
Removes a query set from the graph.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| querySetDivId | <code>string</code> | ID of the query set div to remove |

<a name="module_KGquery.onOutputTypeSelect"></a>

### KGquery.onOutputTypeSelect(output) ⇒ <code>void</code>
Handles output type selection changes.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  

| Param | Type | Description |
| --- | --- | --- |
| output | <code>string</code> | The selected output type |

<a name="module_KGquery.addOutputType"></a>

### KGquery.addOutputType() ⇒ <code>void</code>
Adds an output type to the select options.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.initQuery"></a>

### KGquery.initQuery() ⇒ <code>void</code>
Initializes the query interface.
Loads the query tab HTML if not already loaded.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.initGraph"></a>

### KGquery.initGraph() ⇒ <code>void</code>
Initializes the graph interface.
Loads the graph tab HTML if not already loaded and initializes the graph visualization.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.checkRequirements"></a>

### KGquery.checkRequirements() ⇒ <code>void</code>
Checks requirements by executing a SHACL query.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.initMyQuery"></a>

### KGquery.initMyQuery() ⇒ <code>void</code>
Initializes the query management interface.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
<a name="module_KGquery.onLoaded"></a>

### KGquery.onLoaded() ⇒ <code>void</code>
Called when the module is loaded.
Initializes the user interface and loads saved queries.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Category**: KGquery  
**Access**: public  
<a name="module_KGquery.onLoaded"></a>

### KGquery.onLoaded() ⇒ <code>void</code>
Called when the module is loaded.
Initializes the user interface and loads saved queries.

**Kind**: static method of [<code>KGquery</code>](#module_KGquery)  
**Category**: KGquery  
**Access**: public  
<a name="module_KGquery_controlPanel"></a>

## KGquery\_controlPanel
KGquery_controlPanel Module
Handles the user interface control panel for knowledge graph queries.


* [KGquery_controlPanel](#module_KGquery_controlPanel)
    * [.addQuerySet(toDivId, booleanOperator, label, color)](#module_KGquery_controlPanel.addQuerySet) ⇒ <code>string</code>
    * [.addQueryElementToCurrentSet(querySetDivId, [color])](#module_KGquery_controlPanel.addQueryElementToCurrentSet) ⇒ <code>string</code>
    * [.addNodeToQueryElementDiv(queryElementDivId, role, label)](#module_KGquery_controlPanel.addNodeToQueryElementDiv) ⇒ <code>string</code>
    * [.addPredicateToQueryElementDiv(queryElementDivId, label)](#module_KGquery_controlPanel.addPredicateToQueryElementDiv) ⇒ <code>void</code>
    * [.getQueryElementPredicateLabel(queryElement)](#module_KGquery_controlPanel.getQueryElementPredicateLabel) ⇒ <code>string</code>

<a name="module_KGquery_controlPanel.addQuerySet"></a>

### KGquery_controlPanel.addQuerySet(toDivId, booleanOperator, label, color) ⇒ <code>string</code>
Adds a new query set to the interface.

**Kind**: static method of [<code>KGquery\_controlPanel</code>](#module_KGquery_controlPanel)  
**Returns**: <code>string</code> - The ID of the created query set div  

| Param | Type | Description |
| --- | --- | --- |
| toDivId | <code>string</code> | The ID of the container div |
| booleanOperator | <code>string</code> | The boolean operator for the set (Union/Minus) |
| label | <code>string</code> | The label for the query set |
| color | <code>string</code> | The color for the query set visualization |

<a name="module_KGquery_controlPanel.addQueryElementToCurrentSet"></a>

### KGquery_controlPanel.addQueryElementToCurrentSet(querySetDivId, [color]) ⇒ <code>string</code>
Adds a query element to the current set.

**Kind**: static method of [<code>KGquery\_controlPanel</code>](#module_KGquery_controlPanel)  
**Returns**: <code>string</code> - The ID of the created query element div  

| Param | Type | Description |
| --- | --- | --- |
| querySetDivId | <code>string</code> | The ID of the query set div |
| [color] | <code>string</code> | Optional color for the query element |

<a name="module_KGquery_controlPanel.addNodeToQueryElementDiv"></a>

### KGquery_controlPanel.addNodeToQueryElementDiv(queryElementDivId, role, label) ⇒ <code>string</code>
Adds a node to a query element div.

**Kind**: static method of [<code>KGquery\_controlPanel</code>](#module_KGquery_controlPanel)  
**Returns**: <code>string</code> - The ID of the created node div  

| Param | Type | Description |
| --- | --- | --- |
| queryElementDivId | <code>string</code> | The ID of the query element div |
| role | <code>string</code> | The role of the node (fromNode/toNode) |
| label | <code>string</code> | The label for the node |

<a name="module_KGquery_controlPanel.addPredicateToQueryElementDiv"></a>

### KGquery_controlPanel.addPredicateToQueryElementDiv(queryElementDivId, label) ⇒ <code>void</code>
Adds a predicate to a query element div.

**Kind**: static method of [<code>KGquery\_controlPanel</code>](#module_KGquery_controlPanel)  

| Param | Type | Description |
| --- | --- | --- |
| queryElementDivId | <code>string</code> | The ID of the query element div |
| label | <code>string</code> | The label for the predicate |

<a name="module_KGquery_controlPanel.getQueryElementPredicateLabel"></a>

### KGquery_controlPanel.getQueryElementPredicateLabel(queryElement) ⇒ <code>string</code>
Gets the predicate label for a query element.

**Kind**: static method of [<code>KGquery\_controlPanel</code>](#module_KGquery_controlPanel)  
**Returns**: <code>string</code> - The formatted predicate label  

| Param | Type | Description |
| --- | --- | --- |
| queryElement | <code>Object</code> | The query element |
| queryElement.paths | <code>Array</code> | Array of paths in the query element |

<a name="module_KGquery_filter"></a>

## KGquery\_filter
KGquery_filter ModuleHandles filtering functionality for knowledge graph queries.


* [KGquery_filter](#module_KGquery_filter)
    * [.selectOptionalPredicates(querySets, options, callback)](#module_KGquery_filter.selectOptionalPredicates) ⇒ <code>void</code>
    * [.getOptionalPredicates(propertyNodes, options, callback)](#module_KGquery_filter.getOptionalPredicates) ⇒ <code>void</code>
    * [.getAggregateFilterOptionalPredicates(querySet, filter)](#module_KGquery_filter.getAggregateFilterOptionalPredicates) ⇒ <code>string</code>
    * [.getAggregatePredicates(groupByPredicates, groupByPredicates[key)](#module_KGquery_filter.getAggregatePredicates) ⇒ <code>string</code>
    * [.applyFilterToNode(classDivId, aClass, classSetIndex, result, addTojsTreeNode)](#module_KGquery_filter.applyFilterToNode) ⇒ <code>void</code>
    * [.addNodeFilter(classDivId, addTojsTreeNode, propertyId)](#module_KGquery_filter.addNodeFilter) ⇒ <code>void</code>

<a name="module_KGquery_filter.selectOptionalPredicates"></a>

### KGquery_filter.selectOptionalPredicates(querySets, options, callback) ⇒ <code>void</code>
Selects optional predicates for the query.

**Kind**: static method of [<code>KGquery\_filter</code>](#module_KGquery_filter)  

| Param | Type | Description |
| --- | --- | --- |
| querySets | <code>Object</code> | The query sets to process |
| options | <code>Object</code> | Options for predicate selection |
| callback | <code>function</code> | Callback function called with (err, result) |

<a name="module_KGquery_filter.getOptionalPredicates"></a>

### KGquery_filter.getOptionalPredicates(propertyNodes, options, callback) ⇒ <code>void</code>
Gets the SPARQL representation of selected optional predicates.

**Kind**: static method of [<code>KGquery\_filter</code>](#module_KGquery_filter)  

| Param | Type | Description |
| --- | --- | --- |
| propertyNodes | <code>Array</code> | Array of selected property nodes |
| options | <code>Object</code> |  |
| options.noConfirm | <code>boolean</code> |  |
| callback | <code>function</code> | Callback function called with (err, result) |
| callback.result | <code>Object</code> | The result object containing: |
| callback.result.optionalPredicatesSparql | <code>string</code> | The OPTIONAL clauses in SPARQL |
| callback.result.selectClauseSparql | <code>string</code> | The SELECT clause variables |

<a name="module_KGquery_filter.getAggregateFilterOptionalPredicates"></a>

### KGquery_filter.getAggregateFilterOptionalPredicates(querySet, filter) ⇒ <code>string</code>
Gets optional predicates for aggregate filters.

**Kind**: static method of [<code>KGquery\_filter</code>](#module_KGquery_filter)  
**Returns**: <code>string</code> - The filter string with optional predicates  

| Param | Type | Description |
| --- | --- | --- |
| querySet | <code>Object</code> | The query set to process |
| filter | <code>string</code> | The filter string to check |

<a name="module_KGquery_filter.getAggregatePredicates"></a>

### KGquery_filter.getAggregatePredicates(groupByPredicates, groupByPredicates[key) ⇒ <code>string</code>
Gets aggregate predicates for grouping.

**Kind**: static method of [<code>KGquery\_filter</code>](#module_KGquery_filter)  
**Returns**: <code>string</code> - SPARQL string for aggregate predicates  

| Param | Type | Description |
| --- | --- | --- |
| groupByPredicates | <code>Object</code> | Map of predicates to group by |
| groupByPredicates[key | <code>Object</code> | A predicate object |

<a name="module_KGquery_filter.applyFilterToNode"></a>

### KGquery_filter.applyFilterToNode(classDivId, aClass, classSetIndex, result, addTojsTreeNode) ⇒ <code>void</code>
Applies the filter result to a node and updates the UI.

**Kind**: static method of [<code>KGquery\_filter</code>](#module_KGquery_filter)  

| Param | Type | Description |
| --- | --- | --- |
| classDivId | <code>string</code> | The ID of the class div |
| aClass | <code>Object</code> | The class object |
| classSetIndex | <code>number</code> | The index of the class set |
| result | <code>Object</code> | The filter result object |
| result.filter | <code>string</code> | The filter string |
| result.filterLabel | <code>string</code> | The filter label |
| addTojsTreeNode | <code>string</code> | The node to add the filter to (optional) |

<a name="module_KGquery_filter.addNodeFilter"></a>

### KGquery_filter.addNodeFilter(classDivId, addTojsTreeNode, propertyId) ⇒ <code>void</code>
Adds a filter to a node based on a property.

**Kind**: static method of [<code>KGquery\_filter</code>](#module_KGquery_filter)  

| Param | Type | Description |
| --- | --- | --- |
| classDivId | <code>string</code> | The ID of the class div |
| addTojsTreeNode | <code>string</code> | The node to add the filter to |
| propertyId | <code>string</code> | The ID of the property to filter on |

<a name="module_KGquery_myQueries"></a>

## KGquery\_myQueries
KGquery_myQueries Module
Handles saving and loading of knowledge graph queries.


* [KGquery_myQueries](#module_KGquery_myQueries)
    * [.save(callback)](#module_KGquery_myQueries.save) ⇒ <code>void</code>
    * [.load(err, result)](#module_KGquery_myQueries.load) ⇒ <code>void</code>

<a name="module_KGquery_myQueries.save"></a>

### KGquery_myQueries.save(callback) ⇒ <code>void</code>
Saves the current query state.

**Kind**: static method of [<code>KGquery\_myQueries</code>](#module_KGquery_myQueries)  

| Param | Type | Description |
| --- | --- | --- |
| callback | <code>function</code> | Callback function called with (err, data) where data contains: |
| callback.data | <code>Object</code> | The data to save |
| callback.data.querySets | <code>Object</code> | The current query sets |
| callback.data.sparqlQuery | <code>string</code> | The current SPARQL query |
| callback.data.optionalPredicatesSparql | <code>string</code> | Optional predicates in SPARQL format |
| callback.data.selectClauseSparql | <code>string</code> | The SELECT clause in SPARQL format |

<a name="module_KGquery_myQueries.load"></a>

### KGquery_myQueries.load(err, result) ⇒ <code>void</code>
Loads a saved query state.

**Kind**: static method of [<code>KGquery\_myQueries</code>](#module_KGquery_myQueries)  

| Param | Type | Description |
| --- | --- | --- |
| err | <code>Error</code> | Error object if loading failed |
| result | <code>Object</code> | The saved query state to load |
| result.querySets | <code>Object</code> | The saved query sets |
| result.optionalPredicatesSparql | <code>string</code> | Optional predicates in SPARQL format |
| result.selectClauseSparql | <code>string</code> | The SELECT clause in SPARQL format |

<a name="module_KGquery_nodeSelector"></a>

## KGquery\_nodeSelector
KGquery_nodeSelector Module
Module for selecting and managing nodes in knowledge graph queries.


* [KGquery_nodeSelector](#module_KGquery_nodeSelector)
    * [.showImplicitModelInJstree(visjsData)](#module_KGquery_nodeSelector.showImplicitModelInJstree) ⇒ <code>void</code>
    * [.onSelectNode(node)](#module_KGquery_nodeSelector.onSelectNode) ⇒ <code>void</code>

<a name="module_KGquery_nodeSelector.showImplicitModelInJstree"></a>

### KGquery_nodeSelector.showImplicitModelInJstree(visjsData) ⇒ <code>void</code>
Shows the implicit model in a jsTree structure.

**Kind**: static method of [<code>KGquery\_nodeSelector</code>](#module_KGquery_nodeSelector)  

| Param | Type | Description |
| --- | --- | --- |
| visjsData | <code>Object</code> | The Vis.js graph data containing nodes and edges |
| visjsData.nodes | <code>Array</code> | Array of nodes in the graph |
| visjsData.edges | <code>Array</code> | Array of edges in the graph |

<a name="module_KGquery_nodeSelector.onSelectNode"></a>

### KGquery_nodeSelector.onSelectNode(node) ⇒ <code>void</code>
Handles node selection in the jsTree.

**Kind**: static method of [<code>KGquery\_nodeSelector</code>](#module_KGquery_nodeSelector)  

| Param | Type | Description |
| --- | --- | --- |
| node | <code>Object</code> | The selected node from jsTree |
| node.id | <code>string</code> | The node ID |
| node.text | <code>string</code> | The node text/label |
| node.data | <code>Object</code> | Additional node data |

<a name="module_KGquery_paths"></a>

## KGquery\_paths
Module for managing paths in knowledge graph queries.
This module provides functionality for:
- Configuring and managing paths between nodes
- Manipulating identifiers and variables in paths
- Managing graphical display of paths
- Finding shortest paths between nodes
- Managing path ambiguities

**Requires**: <code>module:shared/common</code>, <code>module:KGquery\_graph</code>, <code>module:uiWidgets/simpleListSelectorWidget</code>, <code>module:sparqlProxies/sparql\_common</code>  
<a name="module_DataSourceManager"></a>

## DataSourceManager
DataSourceManager module
Responsible for managing data source configurations and operations.

**See**: [Tutorial: Overview]{@tutorial overview}  

* [DataSourceManager](#module_DataSourceManager)
    * [.getSlsvSourceConfig(source, callback)](#module_DataSourceManager.getSlsvSourceConfig) ⇒ <code>void</code>
    * [.initNewSlsvSource(source, callback)](#module_DataSourceManager.initNewSlsvSource) ⇒ <code>void</code>
    * [.loaDataSourcesJstree(jstreeDiv, tableStatsMap, callback)](#module_DataSourceManager.loaDataSourcesJstree) ⇒ <code>void</code>
    * [.initNewDataSource(name, type, sqlType, table)](#module_DataSourceManager.initNewDataSource) ⇒ <code>void</code>
    * [.loadCsvSource(slsvSource, fileName, loadJstree, callback)](#module_DataSourceManager.loadCsvSource) ⇒ <code>void</code>
    * [.loadDataBaseSource(slsvSource, dataSource, sqlType, callback)](#module_DataSourceManager.loadDataBaseSource) ⇒ <code>void</code>
    * [.onDataSourcesJstreeSelect(event, obj)](#module_DataSourceManager.onDataSourcesJstreeSelect) ⇒ <code>void</code>
    * [.saveSlsvSourceConfig(callback)](#module_DataSourceManager.saveSlsvSourceConfig) ⇒ <code>void</code>
    * [.displayUploadApp(displayForm)](#module_DataSourceManager.displayUploadApp) ⇒ <code>void</code>
    * [.createDataBaseSourceMappings()](#module_DataSourceManager.createDataBaseSourceMappings) ⇒ <code>void</code>
    * [.createCsvSourceMappings()](#module_DataSourceManager.createCsvSourceMappings) ⇒ <code>void</code>
    * [.deleteDataSource(jstreeNode)](#module_DataSourceManager.deleteDataSource) ⇒ <code>void</code>

<a name="module_DataSourceManager.getSlsvSourceConfig"></a>

### DataSourceManager.getSlsvSourceConfig(source, callback) ⇒ <code>void</code>
Retrieves the configuration for a given data source.
Transfers the "main.json" configuration to the Vis.js graph if not already transferred.

**Kind**: static method of [<code>DataSourceManager</code>](#module_DataSourceManager)  

| Param | Type | Description |
| --- | --- | --- |
| source | <code>string</code> | The source name. |
| callback | <code>function</code> | The callback function to be executed after the operation. |

<a name="module_DataSourceManager.initNewSlsvSource"></a>

### DataSourceManager.initNewSlsvSource(source, callback) ⇒ <code>void</code>
Initializes a new data source and sets the current configuration.

**Kind**: static method of [<code>DataSourceManager</code>](#module_DataSourceManager)  

| Param | Type | Description |
| --- | --- | --- |
| source | <code>string</code> | The source name. |
| callback | <code>function</code> | The callback function to be executed after the initialization. |

<a name="module_DataSourceManager.loaDataSourcesJstree"></a>

### DataSourceManager.loaDataSourcesJstree(jstreeDiv, tableStatsMap, callback) ⇒ <code>void</code>
Loads data sources into a Jstree widget for visualization and interaction.

**Kind**: static method of [<code>DataSourceManager</code>](#module_DataSourceManager)  

| Param | Type | Description |
| --- | --- | --- |
| jstreeDiv | <code>string</code> | The DOM element where the tree should be loaded. |
| tableStatsMap | <code>string</code> | map where key is a table and value the number of triples created from this table |
| callback | <code>function</code> | The callback function to be executed after loading the data sources. |

<a name="module_DataSourceManager.initNewDataSource"></a>

### DataSourceManager.initNewDataSource(name, type, sqlType, table) ⇒ <code>void</code>
Initializes a new data source, updating the current configuration.
This function handles both CSV and non-CSV sources by adding them to the Jstree and updating the current data source configuration.

**Kind**: static method of [<code>DataSourceManager</code>](#module_DataSourceManager)  

| Param | Type | Description |
| --- | --- | --- |
| name | <code>string</code> | The name of the data source. |
| type | <code>string</code> | The type of the data source (e.g., "csvSource" or other types). |
| sqlType | <code>string</code> | The SQL type of the data source, relevant for non-CSV sources. |
| table | <code>string</code> | The initial table to be set for the data source. |

<a name="module_DataSourceManager.loadCsvSource"></a>

### DataSourceManager.loadCsvSource(slsvSource, fileName, loadJstree, callback) ⇒ <code>void</code>
Loads a CSV source by fetching data from the server, including headers and sample data.
This function updates the current configuration with the columns of the CSV source and its sample data.

**Kind**: static method of [<code>DataSourceManager</code>](#module_DataSourceManager)  

| Param | Type | Description |
| --- | --- | --- |
| slsvSource | <code>string</code> | The name of the CSV source. |
| fileName | <code>string</code> | The name of the CSV file to load. |
| loadJstree | <code>boolean</code> | A flag indicating whether to reload the Jstree. |
| callback | <code>function</code> | A callback function to be executed after loading the CSV source. |

<a name="module_DataSourceManager.loadDataBaseSource"></a>

### DataSourceManager.loadDataBaseSource(slsvSource, dataSource, sqlType, callback) ⇒ <code>void</code>
Loads a database source and its associated model by fetching data from the server.
This function retrieves the model for a given data source and updates the configuration with its tables.
It also updates the Jstree with the available tables for the data source.

**Kind**: static method of [<code>DataSourceManager</code>](#module_DataSourceManager)  

| Param | Type | Description |
| --- | --- | --- |
| slsvSource | <code>string</code> | The name of the source. |
| dataSource | <code>string</code> | The name of the database source to load. |
| sqlType | <code>string</code> | The SQL type of the database source. |
| callback | <code>function</code> | A callback function to be executed after the source is loaded. |

<a name="module_DataSourceManager.onDataSourcesJstreeSelect"></a>

### DataSourceManager.onDataSourcesJstreeSelect(event, obj) ⇒ <code>void</code>
Handles the selection of a node in the Jstree, which represents different types of data sources, including databases, CSVs, and tables.
It updates the configuration and loads the corresponding data source or table based on the selection.
Also handles UI updates for the mapping modeler and left panel tabs.

**Kind**: static method of [<code>DataSourceManager</code>](#module_DataSourceManager)  

| Param | Type | Description |
| --- | --- | --- |
| event | <code>Object</code> | The event object triggered by the selection. |
| obj | <code>Object</code> | The Jstree node object containing details about the selected node. |

<a name="module_DataSourceManager.saveSlsvSourceConfig"></a>

### DataSourceManager.saveSlsvSourceConfig(callback) ⇒ <code>void</code>
Saves the current configuration of the SlsvSource by using the MappingColumnsGraph save function.
Calls the provided callback once the saving operation is complete.

**Kind**: static method of [<code>DataSourceManager</code>](#module_DataSourceManager)  

| Param | Type | Description |
| --- | --- | --- |
| callback | <code>function</code> | The callback to invoke after saving the configuration. |

<a name="module_DataSourceManager.displayUploadApp"></a>

### DataSourceManager.displayUploadApp(displayForm) ⇒ <code>void</code>
Displays the upload form app for uploading database or CSV sources.
Depending on the form type, it loads the appropriate form and handles initialization of the React app.

**Kind**: static method of [<code>DataSourceManager</code>](#module_DataSourceManager)  

| Param | Type | Description |
| --- | --- | --- |
| displayForm | <code>string</code> | The type of form to display ("database" or "file"). |

<a name="module_DataSourceManager.createDataBaseSourceMappings"></a>

### DataSourceManager.createDataBaseSourceMappings() ⇒ <code>void</code>
Creates mappings for a selected database source.
Closes the upload app dialog, adds the selected database source to the current configuration,
and saves the updated configuration. Calls the provided callback once the operation is complete.

**Kind**: static method of [<code>DataSourceManager</code>](#module_DataSourceManager)  
<a name="module_DataSourceManager.createCsvSourceMappings"></a>

### DataSourceManager.createCsvSourceMappings() ⇒ <code>void</code>
Creates mappings for a selected CSV source.
Closes the upload app dialog, adds the selected CSV source to the current configuration,
and saves the updated configuration. Calls the provided callback once the operation is complete.

**Kind**: static method of [<code>DataSourceManager</code>](#module_DataSourceManager)  
<a name="module_DataSourceManager.deleteDataSource"></a>

### DataSourceManager.deleteDataSource(jstreeNode) ⇒ <code>void</code>
Deletes a data source (either database or CSV) from the configuration.
Removes the data source from the raw configuration, updates the JSTree,
and removes related nodes and edges from the graph. The updated configuration
is then saved. If the source is a CSV, additional steps would be taken to remove the file.

**Kind**: static method of [<code>DataSourceManager</code>](#module_DataSourceManager)  

| Param | Type | Description |
| --- | --- | --- |
| jstreeNode | <code>Object</code> | The JSTree node representing the data source to be deleted. |

<a name="module_MappingColumnsGraph"></a>

## MappingColumnsGraph
MappingColumnsGraph module.
Handles the visualization and management of mapping columns in a graph.

**See**: [Tutorial: Overview]{@tutorial overview}  

* [MappingColumnsGraph](#module_MappingColumnsGraph)
    * _static_
        * [.self.currentOffset](#module_MappingColumnsGraph.self.currentOffset) : <code>Object</code>
        * [.self.currentGraphNode](#module_MappingColumnsGraph.self.currentGraphNode)
        * [.self.visjsGraph](#module_MappingColumnsGraph.self.visjsGraph) : <code>Object</code>
        * [.self.graphDiv](#module_MappingColumnsGraph.self.graphDiv)
        * [.stepX](#module_MappingColumnsGraph.stepX) : <code>number</code>
        * [.stepY](#module_MappingColumnsGraph.stepY) : <code>number</code>
        * [.minX](#module_MappingColumnsGraph.minX) : <code>number</code>
        * [.drawResource(newResource)](#module_MappingColumnsGraph.drawResource) ⇒ <code>void</code>
        * [.initOffsets()](#module_MappingColumnsGraph.initOffsets) ⇒ <code>void</code>
        * [.objectIdExistsInGraph(id)](#module_MappingColumnsGraph.objectIdExistsInGraph) ⇒ <code>boolean</code>
        * [.drawGraphCanvas(graphDiv, visjsData, [callback])](#module_MappingColumnsGraph.drawGraphCanvas) ⇒ <code>void</code>
        * [.onVisjsGraphClick(node, event, options)](#module_MappingColumnsGraph.onVisjsGraphClick) ⇒ <code>void</code>
        * [.showGraphPopupMenu(node, point, event)](#module_MappingColumnsGraph.showGraphPopupMenu) ⇒ <code>void</code>
        * [.outlineNode(nodeId)](#module_MappingColumnsGraph.outlineNode) ⇒ <code>void</code>
        * [.removeNodeFromGraph()](#module_MappingColumnsGraph.removeNodeFromGraph) ⇒ <code>void</code>
        * [.removeNodeEdgeGraph()](#module_MappingColumnsGraph.removeNodeEdgeGraph) ⇒ <code>void</code>
        * [.addSuperClassToGraph()](#module_MappingColumnsGraph.addSuperClassToGraph) ⇒ <code>void</code>
        * [.drawColumnToClassEdge()](#module_MappingColumnsGraph.drawColumnToClassEdge) ⇒ <code>void</code>
        * [.showNodeInfos()](#module_MappingColumnsGraph.showNodeInfos) ⇒ <code>void</code>
        * [.showSampledata()](#module_MappingColumnsGraph.showSampledata) ⇒ <code>void</code>
        * [.showColumnDetails([node])](#module_MappingColumnsGraph.showColumnDetails) ⇒ <code>void</code>
        * [.addNodesByDataTableBatch(nodes)](#module_MappingColumnsGraph.addNodesByDataTableBatch) ⇒ <code>void</code>
        * [.loadVisjsGraph([callback])](#module_MappingColumnsGraph.loadVisjsGraph) ⇒ <code>void</code>
        * [.saveVisjsGraph([callback])](#module_MappingColumnsGraph.saveVisjsGraph) ⇒ <code>void</code>
        * [.getDatasourceTablesFromVisjsGraph()](#module_MappingColumnsGraph.getDatasourceTablesFromVisjsGraph) ⇒ <code>Array.&lt;string&gt;</code>
        * [.updateNode(node)](#module_MappingColumnsGraph.updateNode) ⇒ <code>void</code>
        * [.removeNode(node)](#module_MappingColumnsGraph.removeNode) ⇒ <code>void</code>
        * [.addNodes(node)](#module_MappingColumnsGraph.addNodes) ⇒ <code>void</code>
        * [.updateEdge(edge)](#module_MappingColumnsGraph.updateEdge) ⇒ <code>void</code>
        * [.removeEdge(edge)](#module_MappingColumnsGraph.removeEdge) ⇒ <code>void</code>
        * [.sortVisjsColumns(nodes)](#module_MappingColumnsGraph.sortVisjsColumns) ⇒ <code>void</code>
        * [.addEdge(edge)](#module_MappingColumnsGraph.addEdge) ⇒ <code>void</code>
        * [.saveVisjsGraphWithConfig(callback)](#module_MappingColumnsGraph.saveVisjsGraphWithConfig) ⇒ <code>void</code>
        * [.clearGraph()](#module_MappingColumnsGraph.clearGraph) ⇒ <code>void</code>
        * [.exportMappings()](#module_MappingColumnsGraph.exportMappings) ⇒ <code>void</code>
        * [.importMappingsFromJSONFile()](#module_MappingColumnsGraph.importMappingsFromJSONFile) ⇒ <code>void</code>
        * [.exportMappings()](#module_MappingColumnsGraph.exportMappings) ⇒ <code>void</code>
    * _inner_
        * [~createDataSourcesClusters()](#module_MappingColumnsGraph..createDataSourcesClusters) ⇒ <code>void</code>

<a name="module_MappingColumnsGraph.self.currentOffset"></a>

### MappingColumnsGraph.self.currentOffset : <code>Object</code>
Current graph node being manipulated.

**Kind**: static property of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
<a name="module_MappingColumnsGraph.self.currentGraphNode"></a>

### MappingColumnsGraph.self.currentGraphNode
Stores the currently selected graph node.

**Kind**: static property of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
<a name="module_MappingColumnsGraph.self.visjsGraph"></a>

### MappingColumnsGraph.self.visjsGraph : <code>Object</code>
Instance of the Vis.js graph.

**Kind**: static property of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
<a name="module_MappingColumnsGraph.self.graphDiv"></a>

### MappingColumnsGraph.self.graphDiv
ID of the HTML container where the graph is rendered.

**Kind**: static property of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
<a name="module_MappingColumnsGraph.stepX"></a>

### MappingColumnsGraph.stepX : <code>number</code>
X-axis step size for node positioning.

**Kind**: static property of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
<a name="module_MappingColumnsGraph.stepY"></a>

### MappingColumnsGraph.stepY : <code>number</code>
Y-axis step size for node positioning.

**Kind**: static property of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
<a name="module_MappingColumnsGraph.minX"></a>

### MappingColumnsGraph.minX : <code>number</code>
Minimum X position for graph layout adjustments.

**Kind**: static property of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
<a name="module_MappingColumnsGraph.drawResource"></a>

### MappingColumnsGraph.drawResource(newResource) ⇒ <code>void</code>
Draws a new resource node in the Vis.js graph.
Positions the node dynamically and links it with existing nodes if necessary.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  

| Param | Type | Description |
| --- | --- | --- |
| newResource | <code>Object</code> | The resource to be added to the graph. |

<a name="module_MappingColumnsGraph.initOffsets"></a>

### MappingColumnsGraph.initOffsets() ⇒ <code>void</code>
Initializes the offset values for positioning nodes in the graph.
Ensures that the offset is set correctly before adding new nodes.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
<a name="module_MappingColumnsGraph.objectIdExistsInGraph"></a>

### MappingColumnsGraph.objectIdExistsInGraph(id) ⇒ <code>boolean</code>
Checks if a given object ID already exists in the Vis.js graph.
Iterates through existing nodes to determine if the ID is present.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
**Returns**: <code>boolean</code> - True if the object exists, otherwise false.  

| Param | Type | Description |
| --- | --- | --- |
| id | <code>string</code> | The ID of the object to check. |

<a name="module_MappingColumnsGraph.drawGraphCanvas"></a>

### MappingColumnsGraph.drawGraphCanvas(graphDiv, visjsData, [callback]) ⇒ <code>void</code>
Draws the graph canvas using Vis.js with specified options.
Configures the graph's visual settings and event handlers.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  

| Param | Type | Description |
| --- | --- | --- |
| graphDiv | <code>string</code> | The ID of the div container for the graph. |
| visjsData | <code>Object</code> | Data containing nodes and edges for the graph. |
| [callback] | <code>function</code> | Optional callback function to execute after drawing. |

<a name="module_MappingColumnsGraph.onVisjsGraphClick"></a>

### MappingColumnsGraph.onVisjsGraphClick(node, event, options) ⇒ <code>void</code>
Handles click events on the Vis.js graph.
Updates the current selected node and manages relations between columns.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  

| Param | Type | Default | Description |
| --- | --- | --- | --- |
| node | <code>Object</code> |  | The clicked node object. |
| event | <code>Object</code> |  | The click event object. |
| options | <code>Object</code> |  | Additional event options. |
| [options.ctrlKey] | <code>boolean</code> | <code>false</code> | Indicates if the Ctrl key was pressed during the click. |
| [options.shiftKey] | <code>boolean</code> | <code>false</code> | Indicates if the Shift key was pressed during the click. |
| [options.altKey] | <code>boolean</code> | <code>false</code> | Indicates if the Alt key was pressed during the click. |

<a name="module_MappingColumnsGraph.showGraphPopupMenu"></a>

### MappingColumnsGraph.showGraphPopupMenu(node, point, event) ⇒ <code>void</code>
Displays the context menu for a graph node.
Shows relevant options based on the node type (Class, Column, or Edge).

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  

| Param | Type | Description |
| --- | --- | --- |
| node | <code>Object</code> | The node where the menu should appear. |
| point | <code>Object</code> | The coordinates for the popup menu. |
| event | <code>Object</code> | The event triggering the menu. |

<a name="module_MappingColumnsGraph.outlineNode"></a>

### MappingColumnsGraph.outlineNode(nodeId) ⇒ <code>void</code>
Outlines a selected node by increasing its border width.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  

| Param | Type | Description |
| --- | --- | --- |
| nodeId | <code>string</code> | The ID of the node to highlight. |

<a name="module_MappingColumnsGraph.removeNodeFromGraph"></a>

### MappingColumnsGraph.removeNodeFromGraph() ⇒ <code>void</code>
Removes a node from the graph after user confirmation.
Also removes its connected edges.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
<a name="module_MappingColumnsGraph.removeNodeEdgeGraph"></a>

### MappingColumnsGraph.removeNodeEdgeGraph() ⇒ <code>void</code>
Removes an edge from the graph after user confirmation.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
<a name="module_MappingColumnsGraph.addSuperClassToGraph"></a>

### MappingColumnsGraph.addSuperClassToGraph() ⇒ <code>void</code>
Adds a superclass to the graph for the selected node.
Queries the ontology for superclass relationships.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
<a name="module_MappingColumnsGraph.drawColumnToClassEdge"></a>

### MappingColumnsGraph.drawColumnToClassEdge() ⇒ <code>void</code>
Draws an edge between a column and a class in the graph.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
<a name="module_MappingColumnsGraph.showNodeInfos"></a>

### MappingColumnsGraph.showNodeInfos() ⇒ <code>void</code>
Displays detailed information about the selected node.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
<a name="module_MappingColumnsGraph.showSampledata"></a>

### MappingColumnsGraph.showSampledata() ⇒ <code>void</code>
Displays sample data related to the selected column.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
<a name="module_MappingColumnsGraph.showColumnDetails"></a>

### MappingColumnsGraph.showColumnDetails([node]) ⇒ <code>void</code>
Shows detailed mappings for the selected column in a dialog.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  

| Param | Type | Description |
| --- | --- | --- |
| [node] | <code>Object</code> | The node for which details should be displayed. Defaults to the currently selected node. |

<a name="module_MappingColumnsGraph.addNodesByDataTableBatch"></a>

### MappingColumnsGraph.addNodesByDataTableBatch(nodes) ⇒ <code>void</code>
Adds nodes to the Vis.js graph in batches based on their associated data tables.
Nodes are grouped by their `dataTable` property and added to the graph incrementally.
Ensures that the graph layout is adjusted after each batch is added.
Permits to have a structured visualisation

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  

| Param | Type | Description |
| --- | --- | --- |
| nodes | <code>Array.&lt;Object&gt;</code> | The list of nodes to be added to the graph. |

<a name="module_MappingColumnsGraph.loadVisjsGraph"></a>

### MappingColumnsGraph.loadVisjsGraph([callback]) ⇒ <code>void</code>
Loads the Vis.js graph for the current mapping source.
Retrieves graph data from a JSON file and adjusts layout positioning.
Clusters nodes based on data tables for better visualization.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  

| Param | Type | Description |
| --- | --- | --- |
| [callback] | <code>function</code> | Optional callback function executed after loading the graph. |

<a name="module_MappingColumnsGraph.saveVisjsGraph"></a>

### MappingColumnsGraph.saveVisjsGraph([callback]) ⇒ <code>void</code>
Saves the current Vis.js graph to a JSON file.
Captures nodes, edges, positions, and configuration data before sending it to the backend for storage.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  

| Param | Type | Description |
| --- | --- | --- |
| [callback] | <code>function</code> | Optional callback function executed after saving the graph. |

<a name="module_MappingColumnsGraph.getDatasourceTablesFromVisjsGraph"></a>

### MappingColumnsGraph.getDatasourceTablesFromVisjsGraph() ⇒ <code>Array.&lt;string&gt;</code>
Retrieves distinct data tables from the Vis.js graph nodes.
Filters out undefined values and returns a list of unique data tables.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
**Returns**: <code>Array.&lt;string&gt;</code> - List of unique data table names.  
<a name="module_MappingColumnsGraph.updateNode"></a>

### MappingColumnsGraph.updateNode(node) ⇒ <code>void</code>
Updates a node in the Vis.js graph and saves the updated graph.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  

| Param | Type | Description |
| --- | --- | --- |
| node | <code>Object</code> | The node to be updated. |

<a name="module_MappingColumnsGraph.removeNode"></a>

### MappingColumnsGraph.removeNode(node) ⇒ <code>void</code>
Removes a node from the Vis.js graph and saves the updated graph.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  

| Param | Type | Description |
| --- | --- | --- |
| node | <code>Object</code> | The node to be removed. |

<a name="module_MappingColumnsGraph.addNodes"></a>

### MappingColumnsGraph.addNodes(node) ⇒ <code>void</code>
Adds a new node to the Vis.js graph and saves the updated graph.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  

| Param | Type | Description |
| --- | --- | --- |
| node | <code>Object</code> | The node to be added. |

<a name="module_MappingColumnsGraph.updateEdge"></a>

### MappingColumnsGraph.updateEdge(edge) ⇒ <code>void</code>
Updates an edge in the Vis.js graph and saves the updated graph.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  

| Param | Type | Description |
| --- | --- | --- |
| edge | <code>Object</code> | The edge to be updated. |

<a name="module_MappingColumnsGraph.removeEdge"></a>

### MappingColumnsGraph.removeEdge(edge) ⇒ <code>void</code>
Removes an edge from the Vis.js graph and saves the updated graph.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  

| Param | Type | Description |
| --- | --- | --- |
| edge | <code>Object</code> | The edge to be removed. |

<a name="module_MappingColumnsGraph.sortVisjsColumns"></a>

### MappingColumnsGraph.sortVisjsColumns(nodes) ⇒ <code>void</code>
Adds a new edge to the Vis.js graph and saves the updated graph.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  

| Param | Type | Description |
| --- | --- | --- |
| nodes | <code>array</code> | The nodes to be sorted. |

<a name="module_MappingColumnsGraph.addEdge"></a>

### MappingColumnsGraph.addEdge(edge) ⇒ <code>void</code>
Adds a new edge to the Vis.js graph and saves the updated graph.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  

| Param | Type | Description |
| --- | --- | --- |
| edge | <code>Object</code> | The edge to be added. |

<a name="module_MappingColumnsGraph.saveVisjsGraphWithConfig"></a>

### MappingColumnsGraph.saveVisjsGraphWithConfig(callback) ⇒ <code>void</code>
Saves the Vis.js graph with the current configuration.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  

| Param | Type | Description |
| --- | --- | --- |
| callback | <code>function</code> | Optional callback to execute after saving. |

<a name="module_MappingColumnsGraph.clearGraph"></a>

### MappingColumnsGraph.clearGraph() ⇒ <code>void</code>
Clears the current graph, resets offsets, and reinitializes the graph canvas.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
<a name="module_MappingColumnsGraph.exportMappings"></a>

### MappingColumnsGraph.exportMappings() ⇒ <code>void</code>
Exports the current mappings from the Vis.js graph to a JSON file.
Saves the graph data before exporting
Handles errors during the export process and displays appropriate messages.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
<a name="module_MappingColumnsGraph.importMappingsFromJSONFile"></a>

### MappingColumnsGraph.importMappingsFromJSONFile() ⇒ <code>void</code>
Imports mappings from a JSON file into the Vis.js graph file.
Opens a file import dialog, parses the JSON content, and uploads the data to the graphs in instance data repository.

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
<a name="module_MappingColumnsGraph.exportMappings"></a>

### MappingColumnsGraph.exportMappings() ⇒ <code>void</code>
Exports the current mappings from the Vis.js graph to a JSON file.
Saves the graph data before exporting

**Kind**: static method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
<a name="module_MappingColumnsGraph..createDataSourcesClusters"></a>

### MappingColumnsGraph~createDataSourcesClusters() ⇒ <code>void</code>
Creates clusters from the different data sources used in the graph.
Groups nodes based on their associated data tables and clusters them for better visualization.

**Kind**: inner method of [<code>MappingColumnsGraph</code>](#module_MappingColumnsGraph)  
<a name="module_MappingModeler"></a>

## MappingModeler
MappingModeler module.
The MappingModeler tool helps creating new mappings from sources, and visualising and editing these mappings.

**See**: [Tutorial: Overview]{@tutorial overview}  

* [MappingModeler](#module_MappingModeler)
    * [.self.jstreeDivId](#module_MappingModeler.self.jstreeDivId) : <code>string</code>
    * [.self.legendGraphDivId](#module_MappingModeler.self.legendGraphDivId) : <code>string</code>
    * [.self.legendItemsArray](#module_MappingModeler.self.legendItemsArray) : <code>Array.&lt;{label: string, color: string, shape: string, size: number}&gt;</code>
    * [.onLoaded()](#module_MappingModeler.onLoaded) ⇒ <code>void</code>
    * [.loadSuggestionSelectJstree(objects, parentName)](#module_MappingModeler.loadSuggestionSelectJstree)
    * [.initActiveLegend(divId)](#module_MappingModeler.initActiveLegend)
    * [.hideForbiddenResources(resourceType)](#module_MappingModeler.hideForbiddenResources)
    * [.onSuggestionsSelect(event, obj)](#module_MappingModeler.onSuggestionsSelect)
    * [.onLegendNodeClick(node, event)](#module_MappingModeler.onLegendNodeClick)
    * [.showLegendGraphPopupMenu()](#module_MappingModeler.showLegendGraphPopupMenu)
    * [.get    AllClasses(source, callback)](#module_MappingModeler.get    AllClasses)
    * [.getAllProperties(source, callback)](#module_MappingModeler.getAllProperties)
    * [.hideLegendItems(hiddenNodes)](#module_MappingModeler.hideLegendItems)
    * [.initResourcesMap(source, callback)](#module_MappingModeler.initResourcesMap)
    * [.clearMappings()](#module_MappingModeler.clearMappings)
    * [.showCreateResourceBot(resourceType, filteredUris)](#module_MappingModeler.showCreateResourceBot)
    * [.viewSampleTriples(mappings)](#module_MappingModeler.viewSampleTriples)
    * [.filterSuggestionTree()](#module_MappingModeler.filterSuggestionTree)
    * [.predicateFunctionShowDialog()](#module_MappingModeler.predicateFunctionShowDialog)
    * [.addPredicateFunction()](#module_MappingModeler.addPredicateFunction)
    * [.loadSource(callback)](#module_MappingModeler.loadSource)
    * [.showSampleData(node, columns, callback)](#module_MappingModeler.showSampleData)

<a name="module_MappingModeler.self.jstreeDivId"></a>

### MappingModeler.self.jstreeDivId : <code>string</code>
ID of the tree container.

**Kind**: static property of [<code>MappingModeler</code>](#module_MappingModeler)  
<a name="module_MappingModeler.self.legendGraphDivId"></a>

### MappingModeler.self.legendGraphDivId : <code>string</code>
ID of the legend container.

**Kind**: static property of [<code>MappingModeler</code>](#module_MappingModeler)  
<a name="module_MappingModeler.self.legendItemsArray"></a>

### MappingModeler.self.legendItemsArray : <code>Array.&lt;{label: string, color: string, shape: string, size: number}&gt;</code>
Array defining the legend items for the graph.
Each item includes label, color, shape, and size properties.

**Kind**: static property of [<code>MappingModeler</code>](#module_MappingModeler)  
<a name="module_MappingModeler.onLoaded"></a>

### MappingModeler.onLoaded() ⇒ <code>void</code>
Initializes the MappingModeler module.

This method performs the following steps in sequence:
1. Sets up the current source and initializes the UI menu bar.
2. Loads the source configuration using `DataSourceManager`.
3. Loads the HTML structure for the graph container.
4. Initializes an empty VisJS graph canvas.
5. Loads the VisJS mapping graph with data.
6. Loads and sets up the lateral panel with tabs and the data source tree.

**Kind**: static method of [<code>MappingModeler</code>](#module_MappingModeler)  
**Throws**:

- <code>Error</code> If any step in the initialization sequence fails.

<a name="module_MappingModeler.loadSuggestionSelectJstree"></a>

### MappingModeler.loadSuggestionSelectJstree(objects, parentName)
Loads and initializes a suggestion tree in the specified container.

**Kind**: static method of [<code>MappingModeler</code>](#module_MappingModeler)  

| Param | Type | Description |
| --- | --- | --- |
| objects | <code>Array.&lt;Object&gt;</code> | The objects to populate the tree with. |
| parentName | <code>string</code> | The name of the parent node. |

<a name="module_MappingModeler.initActiveLegend"></a>

### MappingModeler.initActiveLegend(divId)
Initializes the active legend for a given container.

**Kind**: static method of [<code>MappingModeler</code>](#module_MappingModeler)  

| Param | Type | Description |
| --- | --- | --- |
| divId | <code>string</code> | The ID of the container where the legend will be displayed. |

<a name="module_MappingModeler.hideForbiddenResources"></a>

### MappingModeler.hideForbiddenResources(resourceType)
Hides specific resources in the legend based on the resource type.

**Kind**: static method of [<code>MappingModeler</code>](#module_MappingModeler)  

| Param | Type | Description |
| --- | --- | --- |
| resourceType | <code>string</code> | The type of resource to hide. |

<a name="module_MappingModeler.onSuggestionsSelect"></a>

### MappingModeler.onSuggestionsSelect(event, obj)
Handles the selection of a suggestion from the tree.

**Kind**: static method of [<code>MappingModeler</code>](#module_MappingModeler)  

| Param | Type | Description |
| --- | --- | --- |
| event | <code>Object</code> | The selection event object. |
| obj | <code>Object</code> | The selected tree node object. |

<a name="module_MappingModeler.onLegendNodeClick"></a>

### MappingModeler.onLegendNodeClick(node, event)
Performs actions such as:
- Creating a specific URI resource.
- Loading suggestions for columns, classes, or properties.
- Managing virtual columns or row indices.

**Kind**: static method of [<code>MappingModeler</code>](#module_MappingModeler)  

| Param | Type | Description |
| --- | --- | --- |
| node | <code>Object</code> | The legend node clicked, containing its ID and properties. |
| event | <code>Object</code> | The click event triggering the action. |

<a name="module_MappingModeler.showLegendGraphPopupMenu"></a>

### MappingModeler.showLegendGraphPopupMenu()
Displays the legend graph popup menu (TO DO).

**Kind**: static method of [<code>MappingModeler</code>](#module_MappingModeler)  
<a name="module_MappingModeler.get    AllClasses"></a>

### MappingModeler.get    AllClasses(source, callback)
- If the classes are already cached in `self.allClasses`, returns the cached list.
- Otherwise, fetches all classes using `CommonBotFunctions.listSourceAllClasses`.
- Filters out duplicate class IDs and formats labels with source prefixes.
- The resulting class list is sorted alphabetically by label.
- Calls the callback with the formatted list or an error if the API call fails.

**Kind**: static method of [<code>MappingModeler</code>](#module_MappingModeler)  

| Param | Type | Description |
| --- | --- | --- |
| source | <code>string</code> | The source to retrieve classes from. Defaults to `self.currentSource` if not provided. |
| callback | <code>function</code> | Callback function to handle the result. Receives two arguments: error and result. |

<a name="module_MappingModeler.getAllProperties"></a>

### MappingModeler.getAllProperties(source, callback)
- If the properties are already cached in `self.allProperties`, returns the cached list.
- Otherwise, fetches all object properties using `CommonBotFunctions.listSourceAllObjectProperties`.
- Filters out duplicate property IDs and prepares labels for each property.
- Sorts the resulting property list alphabetically by label.
- Calls the callback with the formatted list or an error if the API call fails.

**Kind**: static method of [<code>MappingModeler</code>](#module_MappingModeler)  

| Param | Type | Description |
| --- | --- | --- |
| source | <code>string</code> | The source to retrieve properties from. Defaults to `self.currentSource` if not provided. |
| callback | <code>function</code> | Callback function to handle the result. Receives two arguments: error and result. |

**Example**  
```js
self.getAllProperties("mySource", function(err, properties) {
    if (err) {
        console.error(err);
    } else {
        console.log(properties);
    }
});
```
<a name="module_MappingModeler.hideLegendItems"></a>

### MappingModeler.hideLegendItems(hiddenNodes)
- Retrieves all legend node IDs from `Axiom_activeLegend.data.nodes`.
- Iterates through each node ID, marking them as `hidden` if they are not in the `hiddenNodes` list.
- Updates the visibility of legend items using `self.updateNode`.

**Kind**: static method of [<code>MappingModeler</code>](#module_MappingModeler)  

| Param | Type | Description |
| --- | --- | --- |
| hiddenNodes | <code>Array</code> | Array of node IDs to keep visible. If not provided, all legend items are hidden. |

**Example**  
```js
self.hideLegendItems(["node1", "node2"]);
```
<a name="module_MappingModeler.initResourcesMap"></a>

### MappingModeler.initResourcesMap(source, callback)
- Initializes `self.allResourcesMap` as an empty object.
- Resets `self.allClasses` and `self.allProperties` to `null`.
- Calls `self.getAllClasses` to fetch all classes, adding each to the `self.allResourcesMap` by ID.
- Calls `self.getAllProperties` to fetch all properties, adding each to the `self.allResourcesMap` by ID.
- If a callback is provided, it is invoked after all resources are processed.

**Kind**: static method of [<code>MappingModeler</code>](#module_MappingModeler)  

| Param | Type | Description |
| --- | --- | --- |
| source | <code>string</code> | The data source from which resources are fetched. |
| callback | <code>function</code> | Callback function invoked after resources are initialized. Receives two arguments: error and result. |

**Example**  
```js
self.initResourcesMap("mySource", function(err, result) {
    if (err) {
        console.error(err);
    } else {
        console.log("Resources initialized:", self.allResourcesMap);
    }
});
```
<a name="module_MappingModeler.clearMappings"></a>

### MappingModeler.clearMappings()
- Clears the `visjsGraph` object, which contains the graph visualization data.
- Removes all content from the graph's HTML container using its ID.
- Resets `self.visjsGraph` to `null`.
- Reinitializes an empty graph canvas using `self.drawGraphCanvas` with empty nodes and edges.

**Kind**: static method of [<code>MappingModeler</code>](#module_MappingModeler)  
**Example**  
```js
self.clearMappings();
```
<a name="module_MappingModeler.showCreateResourceBot"></a>

### MappingModeler.showCreateResourceBot(resourceType, filteredUris)
- Initializes the workflow for creating a new resource based on the resource type.
- If the resource type is "Class", it uses the `workflowNewClass` workflow, otherwise, if it's "ObjectProperty", it uses the `workflowNewObjectProperty` workflow.
- Updates internal data structures (`allClasses`, `allProperties`, `allResourcesMap`) with the newly created resource.
- Adds the new resource to a suggestion list displayed in a jsTree widget.
- If the resource type is invalid, it alerts the user.

**Kind**: static method of [<code>MappingModeler</code>](#module_MappingModeler)  

| Param | Type | Description |
| --- | --- | --- |
| resourceType | <code>string</code> | The type of resource to create ("Class" or "ObjectProperty"). |
| filteredUris | <code>Array</code> | The URIs to filter the resource creation process. |

**Example**  
```js
self.showCreateResourceBot("Class", filteredUris);
```
<a name="module_MappingModeler.viewSampleTriples"></a>

### MappingModeler.viewSampleTriples(mappings)
- Constructs a payload with the current source, data source, table name, and options.
- Sends a POST request to the server to generate sample triples based on the provided mappings.
- Displays the generated triples in a data table using `TripleFactory.showTriplesInDataTable`.
- Shows a dialog with the generated triples and allows the user to close the dialog.
- If an error occurs during the request, an alert is shown with the error message.

**Kind**: static method of [<code>MappingModeler</code>](#module_MappingModeler)  

| Param | Type | Description |
| --- | --- | --- |
| mappings | <code>Object</code> | The mappings to be applied as a filter when generating the sample triples. |

**Example**  
```js
self.viewSampleTriples(mappings);
```
<a name="module_MappingModeler.filterSuggestionTree"></a>

### MappingModeler.filterSuggestionTree()
- Retrieves the input keyword from the filter field and converts it to lowercase.
- Checks if the suggestion tree data exists and creates a copy of it if necessary.
- Filters the nodes in the suggestion tree, only including leaf nodes whose text contains the keyword.
- Updates the jstree with the filtered nodes using `JstreeWidget.updateJstree`.

**Kind**: static method of [<code>MappingModeler</code>](#module_MappingModeler)  
**Example**  
```js
self.filterSuggestionTree();
```
<a name="module_MappingModeler.predicateFunctionShowDialog"></a>

### MappingModeler.predicateFunctionShowDialog()
- Loads the HTML content from `functionDialog.html` into the `#smallDialogDiv` element.
- Opens the dialog to display the loaded content.

**Kind**: static method of [<code>MappingModeler</code>](#module_MappingModeler)  
**Example**  
```js
self.predicateFunctionShowDialog();
```
<a name="module_MappingModeler.addPredicateFunction"></a>

### MappingModeler.addPredicateFunction()
- Creates an edge with a label "_function_" and a diamond-shaped arrow pointing to the target node.
- The edge's data contains the function body retrieved from the `#MappingModeler_fnBody` input field.
- Adds the edge to the graph and then closes the dialog displaying the function input.

**Kind**: static method of [<code>MappingModeler</code>](#module_MappingModeler)  
**Example**  
```js
self.addPredicateFunction();
```
<a name="module_MappingModeler.loadSource"></a>

### MappingModeler.loadSource(callback)
- Uses `Lineage_sources.loadSources` to load the current source specified in `MainController.currentSource`.
- On success, hides the graph edition buttons and calls the provided callback function.
- If an error occurs during the loading process, an alert is displayed with the error message.

**Kind**: static method of [<code>MappingModeler</code>](#module_MappingModeler)  

| Param | Type | Description |
| --- | --- | --- |
| callback | <code>function</code> | The function to be executed once the source is loaded successfully. |

**Example**  
```js
self.loadSource(function() {
  console.log("Source loaded successfully");
});
```
<a name="module_MappingModeler.showSampleData"></a>

### MappingModeler.showSampleData(node, columns, callback)
- Checks if columns are specified and prepares the table accordingly.
- Fetches and displays sample data from either a database or CSV source.
- For a database source, it fetches the first 200 rows based on a predefined SQL query.
- Displays the data in a table with the specified columns.
- Alerts the user if the CSV source is not yet implemented.

**Kind**: static method of [<code>MappingModeler</code>](#module_MappingModeler)  

| Param | Type | Description |
| --- | --- | --- |
| node | <code>Object</code> | The selected node from which to fetch data. |
| columns | <code>Array</code> \| <code>string</code> | The specific columns to display, can be an array or a single column name. |
| callback | <code>function</code> | A callback function to be executed after showing the data (optional). |

**Example**  
```js
self.showSampleData(node, ['column1', 'column2'], function() {
  console.log("Sample data displayed");
});
```
<a name="module_MappingsDetails"></a>

## MappingsDetails : <code>Object</code>
MappingsDetails manages technical mappings (non structural mappings)

**See**: [Tutorial: Overview]{@tutorial overview}  

* [MappingsDetails](#module_MappingsDetails) : <code>Object</code>
    * [.transform](#module_MappingsDetails.transform) : <code>object</code>
        * [.showTansformDialog([column])](#module_MappingsDetails.transform.showTansformDialog) ⇒ <code>void</code>
        * [.createPrefixTransformFn()](#module_MappingsDetails.transform.createPrefixTransformFn) ⇒ <code>void</code>
        * [.testTransform()](#module_MappingsDetails.transform.testTransform) ⇒ <code>void</code>
    * [.showDetailsDialog([divId], [callback])](#module_MappingsDetails.showDetailsDialog) ⇒ <code>void</code>
    * [.showDetailedMappingsTree([column], [divId], [_options])](#module_MappingsDetails.showDetailedMappingsTree) ⇒ <code>void</code>
    * [.saveMappingsDetailsToVisjsGraph(columnId)](#module_MappingsDetails.saveMappingsDetailsToVisjsGraph) ⇒ <code>void</code>
    * [.deleteMappingInVisjsNode(treeNode)](#module_MappingsDetails.deleteMappingInVisjsNode) ⇒ <code>void</code>
    * [.showSpecificMappingsBot(columnId)](#module_MappingsDetails.showSpecificMappingsBot) ⇒ <code>void</code>
    * [.onSelectTreeNode(event, obj)](#module_MappingsDetails.onSelectTreeNode) ⇒ <code>void</code>
    * [.drawDetailedMappingsGraph([column])](#module_MappingsDetails.drawDetailedMappingsGraph) ⇒ <code>void</code>
    * [.onDetailedMappingsGraphClick(obj, event, options)](#module_MappingsDetails.onDetailedMappingsGraphClick) ⇒ <code>void</code>
    * [.getColumnType(nodeId)](#module_MappingsDetails.getColumnType) ⇒ <code>string</code> \| <code>null</code>
    * [.setDefinedInColumnNodesProperties()](#module_MappingsDetails.setDefinedInColumnNodesProperties) ⇒ <code>void</code>
    * [.setNodeAsMainColumn(nodeId)](#module_MappingsDetails.setNodeAsMainColumn) ⇒ <code>void</code>

<a name="module_MappingsDetails.transform"></a>

### MappingsDetails.transform : <code>object</code>
The transform module handles operations related to transforming columns in the mapping model.It includes functions for displaying a dialog, creating prefix transformation functions, testing the transformation, and saving the transformation.

**Kind**: static namespace of [<code>MappingsDetails</code>](#module_MappingsDetails)  

* [.transform](#module_MappingsDetails.transform) : <code>object</code>
    * [.showTansformDialog([column])](#module_MappingsDetails.transform.showTansformDialog) ⇒ <code>void</code>
    * [.createPrefixTransformFn()](#module_MappingsDetails.transform.createPrefixTransformFn) ⇒ <code>void</code>
    * [.testTransform()](#module_MappingsDetails.transform.testTransform) ⇒ <code>void</code>

<a name="module_MappingsDetails.transform.showTansformDialog"></a>

#### transform.showTansformDialog([column]) ⇒ <code>void</code>
Displays a dialog for transforming the selected column.If no column is provided, it defaults to the currently selected column.

**Kind**: static method of [<code>transform</code>](#module_MappingsDetails.transform)  

| Param | Type | Description |
| --- | --- | --- |
| [column] | <code>string</code> | The column to transform (optional). |

<a name="module_MappingsDetails.transform.createPrefixTransformFn"></a>

#### transform.createPrefixTransformFn() ⇒ <code>void</code>
Creates a prefix transformation function and applies it to the selected column.The user is prompted to enter a prefix, and the function is generated accordingly.

**Kind**: static method of [<code>transform</code>](#module_MappingsDetails.transform)  
<a name="module_MappingsDetails.transform.testTransform"></a>

#### transform.testTransform() ⇒ <code>void</code>
Tests the transformation function by applying it to a sample mapping.It checks for any errors in the transformation code and then creates triples using the mapping.

**Kind**: static method of [<code>transform</code>](#module_MappingsDetails.transform)  
<a name="module_MappingsDetails.showDetailsDialog"></a>

### MappingsDetails.showDetailsDialog([divId], [callback]) ⇒ <code>void</code>
Displays the details dialog for mappings.If no table is selected, an alert is shown. Otherwise, it loads the details dialog HTMLand activates the right panel in the UI. It also sets up the detailed mappings treeand graph, and binds the search input to search the mappings in the tree.

**Kind**: static method of [<code>MappingsDetails</code>](#module_MappingsDetails)  

| Param | Type | Default | Description |
| --- | --- | --- | --- |
| [divId] | <code>string</code> | <code>&quot;\&quot;mainDialogDiv\&quot;&quot;</code> | The ID of the dialog div to display the details in. Default is "mainDialogDiv". |
| [callback] | <code>function</code> |  | Optional callback function to execute after showing the dialog. |

<a name="module_MappingsDetails.showDetailedMappingsTree"></a>

### MappingsDetails.showDetailedMappingsTree([column], [divId], [_options]) ⇒ <code>void</code>
Displays the detailed mappings tree for the current table.It populates the tree with nodes and mappings related to the selected table and columns.The tree allows search and interaction with mapping nodes.

**Kind**: static method of [<code>MappingsDetails</code>](#module_MappingsDetails)  

| Param | Type | Default | Description |
| --- | --- | --- | --- |
| [column] | <code>Object</code> |  | Optional column data to filter the tree by. |
| [divId] | <code>string</code> | <code>&quot;\&quot;detailedMappings_jsTreeDiv\&quot;&quot;</code> | The ID of the div to display the tree in. Default is "detailedMappings_jsTreeDiv". |
| [_options] | <code>Object</code> | <code>{}</code> | Optional configuration options for the tree, such as context menu behavior. |
| [_options.withoutContextMenu] | <code>boolean</code> | <code>false</code> | If true, disables the context menu. |
| [_options.searchPlugin] | <code>boolean</code> | <code>true</code> | Enables or disables the search plugin. |
| [_options.openAll] | <code>boolean</code> | <code>true</code> | If true, expands all nodes by default. |
| [_options.selectTreeNodeFn] | <code>function</code> |  | Callback function for when a tree node is selected. |

<a name="module_MappingsDetails.saveMappingsDetailsToVisjsGraph"></a>

### MappingsDetails.saveMappingsDetailsToVisjsGraph(columnId) ⇒ <code>void</code>
Saves the mapping details to the Vis.js graph for a specific column.It updates the column's URI type, RDF type, and rdfs:label based on the user's selection,then saves the updated data to the graph and triggers any necessary transformations.

**Kind**: static method of [<code>MappingsDetails</code>](#module_MappingsDetails)  

| Param | Type | Description |
| --- | --- | --- |
| columnId | <code>string</code> | The ID of the column whose mapping details are to be saved. |

<a name="module_MappingsDetails.deleteMappingInVisjsNode"></a>

### MappingsDetails.deleteMappingInVisjsNode(treeNode) ⇒ <code>void</code>
Deletes a specific mapping from the Vis.js graph node.It identifies the mapping based on the node's ID and removes the corresponding propertyor predicate from the node's data. After deletion, the tree is updated and the graph is re-rendered.

**Kind**: static method of [<code>MappingsDetails</code>](#module_MappingsDetails)  

| Param | Type | Description |
| --- | --- | --- |
| treeNode | <code>Object</code> | The tree node representing the mapping to be deleted. |

<a name="module_MappingsDetails.showSpecificMappingsBot"></a>

### MappingsDetails.showSpecificMappingsBot(columnId) ⇒ <code>void</code>
Displays a button for configuring specific mappings for a column.The button initiates a workflow that allows the user to add various predicates (rdf:type, rdfs:subClassOf, non-object properties) to the column's data in the graph.The changes are applied and saved to the graph upon completion of the workflow.

**Kind**: static method of [<code>MappingsDetails</code>](#module_MappingsDetails)  

| Param | Type | Description |
| --- | --- | --- |
| columnId | <code>string</code> | The ID of the column for which the specific mappings are to be configured. |

<a name="module_MappingsDetails.onSelectTreeNode"></a>

### MappingsDetails.onSelectTreeNode(event, obj) ⇒ <code>void</code>
Handles the selection of a tree node and displays the corresponding column's technical details.If the selected node is a column node, it opens the column technical mappings dialog.

**Kind**: static method of [<code>MappingsDetails</code>](#module_MappingsDetails)  

| Param | Type | Description |
| --- | --- | --- |
| event | <code>Object</code> | The event object triggered by the tree node selection. |
| obj | <code>Object</code> | The selected tree node object containing node details. |

<a name="module_MappingsDetails.drawDetailedMappingsGraph"></a>

### MappingsDetails.drawDetailedMappingsGraph([column]) ⇒ <code>void</code>
Draws a detailed mappings graph based on the column's mappings.It visualizes the mappings in a graph format, with nodes representing the columns and edges representing the relationships between them.Optionally filters the graph to a specific column if provided.

**Kind**: static method of [<code>MappingsDetails</code>](#module_MappingsDetails)  

| Param | Type | Description |
| --- | --- | --- |
| [column] | <code>string</code> | The column to filter the mappings by (optional). |

<a name="module_MappingsDetails.onDetailedMappingsGraphClick"></a>

### MappingsDetails.onDetailedMappingsGraphClick(obj, event, options) ⇒ <code>void</code>
Handles the click event on the detailed mappings graph.Currently, it serves as a placeholder function for handling interactions with the graph.

**Kind**: static method of [<code>MappingsDetails</code>](#module_MappingsDetails)  

| Param | Type | Description |
| --- | --- | --- |
| obj | <code>Object</code> | The clicked object details from the graph. |
| event | <code>Object</code> | The event object triggered by the click. |
| options | <code>Object</code> | Additional options for handling the click event. |

<a name="module_MappingsDetails.getColumnType"></a>

### MappingsDetails.getColumnType(nodeId) ⇒ <code>string</code> \| <code>null</code>
Retrieves the RDF type of a column based on its connected edges in the graph.Searches through the edges to find the rdf:type and returns the type if it's a valid URI.

**Kind**: static method of [<code>MappingsDetails</code>](#module_MappingsDetails)  
**Returns**: <code>string</code> \| <code>null</code> - - The RDF type of the column if found, otherwise null.  

| Param | Type | Description |
| --- | --- | --- |
| nodeId | <code>string</code> | The ID of the node whose type is to be retrieved. |

<a name="module_MappingsDetails.setDefinedInColumnNodesProperties"></a>

### MappingsDetails.setDefinedInColumnNodesProperties() ⇒ <code>void</code>
Updates URI properties of nodes that reference other nodes via definedInColumn.For each node with data.definedInColumn, copies prefixURI, suffixURI, baseURI, and uriTypefrom the referenced node. Also processes edges' fromNode and toNode if they have definedInColumn.

**Kind**: static method of [<code>MappingsDetails</code>](#module_MappingsDetails)  
<a name="module_MappingsDetails.setNodeAsMainColumn"></a>

### MappingsDetails.setNodeAsMainColumn(nodeId) ⇒ <code>void</code>
Sets a node as the main column for its class.Removes definedInColumn reference, sets isMainColumn to true, and reapplies mapping logic.

**Kind**: static method of [<code>MappingsDetails</code>](#module_MappingsDetails)  

| Param | Type | Description |
| --- | --- | --- |
| nodeId | <code>string</code> | The ID of the node to set as main column |

<a name="module_MappingTransform"></a>

## MappingTransform
Module responsible for generating and managing mappings for the MappingTransform process.It interacts with the Vis.js graph to retrieve mappings and formats them as JSON for use in the application.It also provides functionality for generating SLS mappings and R2ML mappings (coming soon).

**See**: [Tutorial: Overview]{@tutorial overview}  

* [MappingTransform](#module_MappingTransform)
    * [.generateR2MLmappings()](#module_MappingTransform.generateR2MLmappings) ⇒ <code>void</code>
    * [.getSLSmappingsFromVisjsGraph([table])](#module_MappingTransform.getSLSmappingsFromVisjsGraph) ⇒ <code>Object</code>
    * [.nodeToKGcreatorColumnName(data)](#module_MappingTransform.nodeToKGcreatorColumnName) ⇒ <code>string</code>
    * [.mappingsToKGcreatorJson(columnsMap)](#module_MappingTransform.mappingsToKGcreatorJson) ⇒ <code>Array</code>
    * [.addMappingsRestrictions(allMappings)](#module_MappingTransform.addMappingsRestrictions) ⇒ <code>Array</code>
    * [.copyKGcreatorMappings()](#module_MappingTransform.copyKGcreatorMappings)

<a name="module_MappingTransform.generateR2MLmappings"></a>

### MappingTransform.generateR2MLmappings() ⇒ <code>void</code>
Placeholder function for generating R2ML mappings. Currently displays an alert.

**Kind**: static method of [<code>MappingTransform</code>](#module_MappingTransform)  
<a name="module_MappingTransform.getSLSmappingsFromVisjsGraph"></a>

### MappingTransform.getSLSmappingsFromVisjsGraph([table]) ⇒ <code>Object</code>
Retrieves the SLS mappings for the current table from the Vis.js graph.Filters nodes that belong to the specified table and exclude those with type "Class" or "table".

**Kind**: static method of [<code>MappingTransform</code>](#module_MappingTransform)  
**Returns**: <code>Object</code> - The generated JSON object containing the SLS mappings for the specified table.  

| Param | Type | Description |
| --- | --- | --- |
| [table] | <code>string</code> | The name of the table for which to retrieve the mappings. Defaults to the current table if not provided. |

<a name="module_MappingTransform.nodeToKGcreatorColumnName"></a>

### MappingTransform.nodeToKGcreatorColumnName(data) ⇒ <code>string</code>
Converts a node's data to a KGcreator-compatible column name based on its URI type and data type.It generates column names based on different conditions such as blankNode, randomIdentifier, or URI.Virtual columns and URI columns have specific suffixes added to the column name

**Kind**: static method of [<code>MappingTransform</code>](#module_MappingTransform)  
**Returns**: <code>string</code> - The generated column name in KGcreator format.  

| Param | Type | Description |
| --- | --- | --- |
| data | <code>Object</code> | The node's data containing the URI type and other properties. |

<a name="module_MappingTransform.mappingsToKGcreatorJson"></a>

### MappingTransform.mappingsToKGcreatorJson(columnsMap) ⇒ <code>Array</code>
Transforms a columns map into KGcreator-compatible JSON format, generating mappings between columns, predicates, and objects.This function handles RDF types, labels, transformations, and other predicates for each column.It also processes connections between nodes and generates appropriate triples for each mapping

**Kind**: static method of [<code>MappingTransform</code>](#module_MappingTransform)  
**Returns**: <code>Array</code> - An array of mapping objects in KGcreator JSON format.  

| Param | Type | Description |
| --- | --- | --- |
| columnsMap | <code>Object</code> | A map of nodes containing columns to be transformed. |

<a name="module_MappingTransform.addMappingsRestrictions"></a>

### MappingTransform.addMappingsRestrictions(allMappings) ⇒ <code>Array</code>
Adds restrictions to the mappings if both subject and object are classes and are different from each other.This function checks if the subject and object in a mapping are OWL classes, and if they are, it marks the mapping as a restriction.

**Kind**: static method of [<code>MappingTransform</code>](#module_MappingTransform)  
**Returns**: <code>Array</code> - The modified array of mappings with restrictions added where applicable.  

| Param | Type | Description |
| --- | --- | --- |
| allMappings | <code>Array</code> | The array of mappings to which restrictions will be added. |

<a name="module_MappingTransform.copyKGcreatorMappings"></a>

### MappingTransform.copyKGcreatorMappings()
Copies the KGcreator mappings from the textarea to the clipboard.It retrieves the current mappings as text from the UI and uses a common utility to copy the content to the clipboard.

**Kind**: static method of [<code>MappingTransform</code>](#module_MappingTransform)  
<a name="module_TripleFactory"></a>

## TripleFactory
The TripleFactory module handles the creation, filtering, and writing of RDF triples.It includes functions for generating sample triples, creating all mappings triples, and indexing the graph.

**See**: [Tutorial: Overview]{@tutorial overview}  

* [TripleFactory](#module_TripleFactory)
    * [.indexGraph()](#module_TripleFactory.indexGraph)
    * [.initFilterMappingDialog(isSample)](#module_TripleFactory.initFilterMappingDialog)
    * [.runSlsFilteredMappings()](#module_TripleFactory.runSlsFilteredMappings)
    * [.checkCurrentTable()](#module_TripleFactory.checkCurrentTable) ⇒ <code>boolean</code>
    * [.deleteTriples(all, [callback])](#module_TripleFactory.deleteTriples)
    * [.createTriples(sampleData, table, [options], callback)](#module_TripleFactory.createTriples)
    * [.createAllMappingsTriples()](#module_TripleFactory.createAllMappingsTriples)
    * [.showTriplesInDataTable(data, div)](#module_TripleFactory.showTriplesInDataTable)

<a name="module_TripleFactory.indexGraph"></a>

### TripleFactory.indexGraph()
Indexes the RDF graph using the KGcreator_run module.

**Kind**: static method of [<code>TripleFactory</code>](#module_TripleFactory)  
<a name="module_TripleFactory.initFilterMappingDialog"></a>

### TripleFactory.initFilterMappingDialog(isSample)
Displays a dialog for filtering mappings, allowing the user to choose between sample and actual triples.The dialog is populated with a tree view of detailed mappings that can be filtered by the user.

**Kind**: static method of [<code>TripleFactory</code>](#module_TripleFactory)  

| Param | Type | Description |
| --- | --- | --- |
| isSample | <code>boolean</code> | If true, the dialog is for displaying sample mappings; if false, for writing actual triples. |

<a name="module_TripleFactory.runSlsFilteredMappings"></a>

### TripleFactory.runSlsFilteredMappings()
Runs the filtered mappings for the SLS (Semantic Linked Set) based on the selected nodes in the tree view.It filters and creates unique mappings by checking the selected attributes and mapping nodes.

**Kind**: static method of [<code>TripleFactory</code>](#module_TripleFactory)  
<a name="module_TripleFactory.checkCurrentTable"></a>

### TripleFactory.checkCurrentTable() ⇒ <code>boolean</code>
Checks if the current table is valid and if its mappings details are loaded.Prompts the user to select a table or load the mappings details if they are not available.

**Kind**: static method of [<code>TripleFactory</code>](#module_TripleFactory)  
**Returns**: <code>boolean</code> - - Returns true if the current table is valid and its mappings details are loaded, otherwise false.  
<a name="module_TripleFactory.deleteTriples"></a>

### TripleFactory.deleteTriples(all, [callback])
Deletes triples created by KGCreator from the datasource.Confirms with the user before deleting triples, and sends a DELETE request to the API.

**Kind**: static method of [<code>TripleFactory</code>](#module_TripleFactory)  

| Param | Type | Description |
| --- | --- | --- |
| all | <code>boolean</code> | Indicates whether to delete all triples or just for the current table. |
| [callback] | <code>function</code> | A callback function to be executed after the deletion process. |

<a name="module_TripleFactory.createTriples"></a>

### TripleFactory.createTriples(sampleData, table, [options], callback)
Creates triples for a given table using the selected mappings.Confirms with the user before creating triples, and sends a POST request to the API.

**Kind**: static method of [<code>TripleFactory</code>](#module_TripleFactory)  

| Param | Type | Default | Description |
| --- | --- | --- | --- |
| sampleData | <code>boolean</code> |  | Indicates whether to create sample data triples or full triples. |
| table | <code>string</code> |  | The table for which to create triples. |
| [options] | <code>Object</code> |  | Options for creating triples, such as sample size and filter options. |
| [options.deleteOldGraph] | <code>boolean</code> | <code>false</code> | If true, deletes the existing graph before creating new triples. |
| [options.sampleSize] | <code>number</code> | <code>500</code> | The number of sample triples to create if `sampleData` is true. |
| [options.clientSocketId] | <code>string</code> |  | The client socket ID for real-time updates. |
| [options.mappingsFilter] | <code>Object</code> |  | Filters for selecting specific mappings. |
| [options.filteredMappings] | <code>Object</code> |  | Alternative mapping filter. |
| [options.deleteTriples] | <code>boolean</code> | <code>false</code> | If true, deletes existing triples before creation. |
| callback | <code>function</code> |  | A callback function to be executed after the triples creation process. |

<a name="module_TripleFactory.createAllMappingsTriples"></a>

### TripleFactory.createAllMappingsTriples()
Generates KGcreator triples for the entire datasource, deleting any previous triples before creating new ones.It proceeds with a series of steps: deleting old triples, creating new triples, and reindexing the graph.

**Kind**: static method of [<code>TripleFactory</code>](#module_TripleFactory)  
<a name="module_TripleFactory.showTriplesInDataTable"></a>

### TripleFactory.showTriplesInDataTable(data, div)
Displays the triples data in a table format within the specified div element.The table includes columns for subject, predicate, and object, and the data is escaped to prevent HTML injection.

**Kind**: static method of [<code>TripleFactory</code>](#module_TripleFactory)  

| Param | Type | Description |
| --- | --- | --- |
| data | <code>Array</code> | The triples data to display, each item should contain 's', 'p', and 'o' properties. |
| div | <code>string</code> | The ID of the div element where the table should be displayed. |

<a name="module_UIcontroller"></a>

## UIcontroller
UIcontroller module manages the display of panels in the mapping modeler interface,
handling tab activation and panel visibility for data sources, column mappings, technical mappings, and triples.

**See**: [Tutorial: Overview]{@tutorial overview}  

* [UIcontroller](#module_UIcontroller)
    * [.onActivateLeftPanelTab(tabId)](#module_UIcontroller.onActivateLeftPanelTab)
    * [.switchLeftPanel(target)](#module_UIcontroller.switchLeftPanel)
    * [.activateRightPanel(PanelLabel)](#module_UIcontroller.activateRightPanel)

<a name="module_UIcontroller.onActivateLeftPanelTab"></a>

### UIcontroller.onActivateLeftPanelTab(tabId)
Handles the activation of left panel tabs in the UI based on the provided tab ID.
It shows or hides the corresponding panels based on the selected tab.

**Kind**: static method of [<code>UIcontroller</code>](#module_UIcontroller)  

| Param | Type | Description |
| --- | --- | --- |
| tabId | <code>string</code> | The ID of the tab to activate. |

<a name="module_UIcontroller.switchLeftPanel"></a>

### UIcontroller.switchLeftPanel(target)
Switches the active left panel tab to the target tab.
It also performs necessary UI updates based on the target tab, such as loading columns or technical mappings.

**Kind**: static method of [<code>UIcontroller</code>](#module_UIcontroller)  

| Param | Type | Description |
| --- | --- | --- |
| target | <code>string</code> | The name of the target tab to activate. |

<a name="module_UIcontroller.activateRightPanel"></a>

### UIcontroller.activateRightPanel(PanelLabel)
Activates the specified right panel based on the provided panel label.
It controls the visibility of different right panels like "Data Sources", "Column Mappings", and "Technical Mappings".

**Kind**: static method of [<code>UIcontroller</code>](#module_UIcontroller)  

| Param | Type | Description |
| --- | --- | --- |
| PanelLabel | <code>string</code> | The label of the right panel to activate. |

<a name="saveVisjsModelGraph"></a>

## saveVisjsModelGraph([callback])
Saves the current Vis.js graph model.

**Kind**: global function  

| Param | Type | Description |
| --- | --- | --- |
| [callback] | <code>function</code> | Callback function called after saving |

