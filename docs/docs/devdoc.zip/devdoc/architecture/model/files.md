<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — model

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `blenderSources.js`
- `cleanUserData.js`
- `config.js`
- `databases.js`
- `index.js`
- `mainConfig.js`
- `prefixes.json`
- `profiles.js`
- `ProfileTypes.ts`
- `rdfData.js`
- `sources.js`
- `SourceTypes.ts`
- `tools.js`
- `ToolTypes.ts`
- `userData.js`
- `users.js`
- `UserTypes.ts`
- `utils.js`
