<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\yasguy

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `index.html`
- `sparql.ts`
- `yasgui.bootstrap.css`
- `yasgui.html`
- `yasgui.min.css`
- `yasgui.min.js`
- `yasgui.min.js.LICENSE`
- `yasgui.polyfill.min.js`
- `yasqe.html`
- `yasqe.min.css`
- `yasqe.min.js`
- `yasr.html`
- `yasr.min.css`
- `yasr.min.js`
