<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\modules\tools\KGquery

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `KGquery_controlPanel.js`
- `KGquery_filter.js`
- `KGquery_graph.js`
- `KGquery_myQueries.js`
- `KGquery_nodeSelector.js`
- `KGquery_paths.js`
- `KGquery_predicates.js`
- `KGquery_proxy.js`
- `KGquery.js`
- `KGqueryAggregateWidget.js`
- `KGqueryOld.js`
