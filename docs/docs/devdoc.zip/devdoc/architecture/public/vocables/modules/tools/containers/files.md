<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\modules\tools\containers

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `containers_graph.js`
- `containers_query.js`
- `containers_tree.js`
- `containers_widget.html`
- `containers_widget.js`
