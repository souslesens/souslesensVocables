<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — mainapp\src

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `Admin.tsx`
- `Config.ts`
- `Database.ts`
- `graph-management.tsx`
- `index.tsx`
- `kg-upload-app.tsx`
- `Log.ts`
- `mappingModeler-upload-app.tsx`
- `Plugins.ts`
- `Profile.ts`
- `Source.ts`
- `Tool.ts`
- `user-settings.tsx`
- `User.ts`
- `Utils.ts`
