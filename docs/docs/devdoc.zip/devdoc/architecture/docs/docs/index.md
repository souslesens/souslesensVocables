<!-- AUTO-GENERATED: do not edit by hand -->
# docs\docs

[⬅️ Retour](../index.md)

## Dossiers

- [admindoc](admindoc/index.md)
- [api](api/index.md)
- [devdoc](devdoc/index.md)
- [userdoc](userdoc/index.md)

## Fichiers

- [Voir la liste des fichiers](files.md)
