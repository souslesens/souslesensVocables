<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — public\vocables\icons\Draft (  unvalidated icons )

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `Classes 1 .png`
- `Classes 2 .png`
- `Classes.png`
- `Columns 1.png`
- `Columns.png`
- `Create.png`
- `DateSource X2.png`
- `DateSource.png`
- `Default .png`
- `Default 1.png`
- `Default 2.png`
- `Default 4.png`
- `File CSV.png`
- `File.png`
- `Individual 1  .png`
- `Individual 2 .png`
- `Individual.png`
- `Model 2 .png`
- `Model.png`
- `Model1.png`
- `OK.png`
- `Only Last 1 .png`
- `Only Last 2.png`
- `Only Last.png`
- `Property 1.png`
- `Property 2.png`
- `Property.png`
- `SaveIcon-TotalEnergies.png`
- `Sigma 1.png`
- `Sigma.png`
- `Table 1.png`
- `Table.png`
- `WhiteBoard 1   .png`
- `WhiteBoard 2  .png`
- `WhiteBoard.png`
