<!-- AUTO-GENERATED: do not edit by hand -->
# Fichiers — data\CSV\Data_Domains_Stake_Roles_TBOX

[⬅️ Retour](index.md)

Liste des fichiers présents dans ce dossier (aucune copie n’est créée, uniquement une référence documentaire).

- `20251006_DataDomains_stakeholders_and_roles.csv`
- `DataDomains_stakeholders_and_roles_20251006_camelcase.csv`
- `DataDomains_stakeholders_and_roles_20251006_clean.csv`
- `graph-management.csv`
